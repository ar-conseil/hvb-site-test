<?php
get_header();
while ( have_posts() ) :
	the_post();
	hvb_bandeau( get_the_title(), hvb_rubrique(), get_the_post_thumbnail_url( null, 'hvb-wide' ) );
	?>
	<?php if ( get_post_meta( get_the_ID(), 'hvb_large', true ) ) : ?>
		<article class="conteneur contenu contenu--large">
			<?php the_content(); ?>
		</article>
	<?php else : ?>
		<article class="contenu contenu--sections">
			<?php echo hvb_sections( apply_filters( 'the_content', get_the_content() ) ); // phpcs:ignore ?>
		</article>
	<?php endif; ?>
	<?php
endwhile;
get_footer();
