<?php
/**
 * Template Name: Effectif pro
 * Joueurs saisis dans « Effectif pro », regroupés par poste.
 */
get_header();
the_post();
hvb_bandeau( get_the_title(), 'Volstar Masculine 2 · 2026-2027', get_the_post_thumbnail_url( null, 'hvb-wide' ) );

$par_poste = array();
foreach ( hvb_joueurs() as $joueur ) {
	$par_poste[ get_post_meta( $joueur->ID, 'poste', true ) ][] = $joueur;
}
$pluriels = array(
	'Passeur'                 => 'Passeurs',
	'Central'                 => 'Centraux',
	'Pointu'                  => 'Pointus',
	'Réceptionneur-attaquant' => 'Réceptionneurs-attaquants',
	'Libéro'                  => 'Libéros',
);
?>
<div class="conteneur section">
	<?php foreach ( $par_poste as $poste => $joueurs ) : ?>
		<h2 class="titre-poste"><?php echo esc_html( $pluriels[ $poste ] ?? $poste ); ?></h2>
		<div class="grille-joueurs">
			<?php foreach ( $joueurs as $joueur ) : ?>
				<?php hvb_carte_joueur( $joueur ); ?>
			<?php endforeach; ?>
		</div>
	<?php endforeach; ?>
	<div class="contenu"><?php the_content(); ?></div>

	<section class="media-day">
		<div class="section-entete">
			<div>
				<p class="surtitre">Dans les coulisses</p>
				<h2 class="titre-section">Media Day <em>2026-2027</em></h2>
			</div>
		</div>
		<div class="mosaique">
			<?php
			$photos = array(
				'mediaday-1' => 'Nicolas Maréchal',
				'mediaday-6' => 'Samuel Quéva porte un coéquipier sur son dos',
				'mediaday-4' => 'Fous rires pendant la séance photo',
				'mediaday-2' => 'Plongeon en défense',
				'mediaday-5' => 'Sami Sadli et Juan Pablo Pereyra',
				'mediaday-7' => 'Sami Sadli, Nicolas Maréchal et Altan Demiryurek',
				'mediaday-8' => 'Tristan Sapet et Juan Pablo Pereyra',
			);
			foreach ( $photos as $nom => $legende ) :
				?>
				<figure class="mosaique__photo">
					<img src="<?php echo esc_url( hvb_photo( $nom, 'large' ) ); ?>" alt="<?php echo esc_attr( $legende ); ?>" loading="lazy">
				</figure>
			<?php endforeach; ?>
		</div>
	</section>
</div>
<?php
get_footer();
