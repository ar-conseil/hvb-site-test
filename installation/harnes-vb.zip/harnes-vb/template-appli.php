<?php
/**
 * Template Name: Application
 * Présentation de l'appli HVB Partenaires, avec ses liens App Store et Google Play.
 */
get_header();
the_post();

$club   = hvb_club();
$stores = array(
	array( 'apple', 'Télécharger dans', "l'App Store", $club['appli_ios'] ),
	array( 'play', 'Disponible sur', 'Google Play', $club['appli_android'] ),
);
$sortie = $club['appli_ios'] && $club['appli_android'];

$partenaires = array(
	array( 'calendrier', 'Réservez vos places VIP', 'Pour chaque match à domicile, en quelques secondes.' ),
	array( 'qr', 'Invitez vos clients', "Billets invités avec QR code, envoyés directement depuis l'application." ),
	array( 'tasse', 'Commandez à votre place', 'Boissons et en-cas servis pendant le match, offerts aux invités VIP.' ),
	array( 'graphique', 'Suivez votre pack', "Vos contreparties et votre visibilité, en un coup d'œil." ),
	array( 'groupe', 'Développez votre réseau', "L'annuaire du Business Club : trouvez et contactez les autres partenaires." ),
	array( 'etoile', 'Ne manquez aucun événement', 'Les événements du Business Club et les temps forts du club, annoncés dans l\'appli.' ),
);
$supporters = array(
	array( 'calendrier', 'Le calendrier', 'Tous les matchs de la Volstar M2 et les résultats.', home_url( '/calendrier-resultats/' ) ),
	array( 'billet', 'La billetterie', 'Vos places sur la billetterie officielle Billetweb du club.', $club['billetterie'] ),
	array( 'tasse', 'La buvette', 'Commandez depuis les tribunes, récupérez au bar et payez au comptoir.', '' ),
	array( 'etoile', 'Les événements', 'Les rendez-vous du club, à ne pas manquer.', '' ),
);
?>
<section class="appli">
	<div class="conteneur appli__grille">
		<div class="appli__texte">
			<nav class="ariane" aria-label="Fil d'Ariane">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Accueil</a>
				<span>Nouveauté 2026-2027</span>
			</nav>
			<img class="appli__icone" src="<?php echo esc_url( HVB_URI . '/assets/img/appli-icone.png' ); ?>" alt="" width="88" height="88">
			<h1 class="appli__titre">L'application <em>HVB Partenaires</em></h1>
			<p class="appli__intro">Votre partenariat dans votre poche : une application iPhone et Android dédiée aux partenaires du club, pour vivre chaque match et suivre votre visibilité toute la saison.</p>
			<div class="stores">
				<?php foreach ( $stores as list( $icone, $petit, $nom, $lien ) ) : ?>
					<?php if ( $lien ) : ?>
						<a class="store" href="<?php echo esc_url( $lien ); ?>" target="_blank" rel="noopener">
					<?php else : ?>
						<span class="store store--bientot" aria-disabled="true">
					<?php endif; ?>
						<?php echo hvb_icone( $icone ); // phpcs:ignore ?>
						<span class="store__texte"><small><?php echo esc_html( $lien ? $petit : 'Bientôt sur' ); ?></small><strong><?php echo esc_html( $nom ); ?></strong></span>
					<?php echo $lien ? '</a>' : '</span>'; ?>
				<?php endforeach; ?>
			</div>
			<?php if ( ! $sortie ) : ?>
				<p class="appli__lancement"><strong>Lancement prévu : janvier 2027</strong><span>iPhone · Android</span></p>
			<?php endif; ?>
		</div>
		<div class="appli__visuel">
			<img src="<?php echo esc_url( HVB_URI . '/assets/img/appli-telephones.jpg' ); ?>" alt="Écrans de l'application HVB Partenaires : accueil et commande en tribune VIP" width="900" height="1215">
		</div>
	</div>
	<a class="bandeau__suite" href="#suite" aria-label="Lire la suite"><?php echo hvb_icone( 'bas' ); // phpcs:ignore ?></a>
</section>
<span id="suite"></span>

<section class="section">
	<div class="conteneur">
		<div class="appli__entete">
			<p class="surtitre">Espace partenaires</p>
			<h2 class="titre-section">Tout votre partenariat <em>en un geste</em></h2>
		</div>
		<div class="atouts">
			<?php foreach ( $partenaires as list( $icone, $titre, $texte ) ) : ?>
				<article class="atout">
					<span class="atout__icone"><?php echo hvb_icone( $icone ); // phpcs:ignore ?></span>
					<h3><?php echo esc_html( $titre ); ?></h3>
					<p><?php echo esc_html( $texte ); ?></p>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section appli__supporters">
	<div class="conteneur">
		<div class="appli__entete">
			<p class="surtitre">Et pour les supporters</p>
			<h2 class="titre-section">Le HVB <em>au bout des doigts</em></h2>
		</div>
		<div class="atouts atouts--quatre">
			<?php foreach ( $supporters as list( $icone, $titre, $texte, $lien ) ) : ?>
				<article class="atout atout--clair">
					<span class="atout__icone"><?php echo hvb_icone( $icone ); // phpcs:ignore ?></span>
					<h3><?php echo esc_html( $titre ); ?></h3>
					<p><?php echo esc_html( $texte ); ?></p>
					<?php if ( $lien ) : ?>
						<a class="atout__lien" href="<?php echo esc_url( $lien ); ?>">Voir sur le site <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section appli-partenaire">
	<div class="conteneur appli-partenaire__grille">
		<div>
			<p class="surtitre">Pas encore partenaire ?</p>
			<h2 class="titre-section">Rejoignez <em>le Business Club</em></h2>
			<p>L'application accompagne les partenaires du club tout au long de la saison. Découvrez les quatre packs 2026-2027 et choisissez celui qui vous ressemble.</p>
		</div>
		<div class="appli-partenaire__actions">
			<a class="bouton bouton--rouge" href="<?php echo esc_url( home_url( '/devenir-partenaire/' ) ); ?>">Devenir partenaire <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
			<a class="appli-partenaire__confidentialite" href="<?php echo esc_url( home_url( '/confidentialite/' ) ); ?>">Politique de confidentialité de l'appli</a>
		</div>
	</div>
</section>

<?php
get_footer();
