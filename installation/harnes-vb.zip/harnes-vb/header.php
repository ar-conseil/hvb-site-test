<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="<?php echo esc_url( HVB_URI . '/assets/img/logo-hvb.png' ); ?>">
	<script>document.documentElement.classList.add('js');</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="lien-evitement" href="#contenu">Aller au contenu</a>

<div class="barre-haut">
	<div class="barre-haut__contenu">
		<p class="barre-haut__devise">Ensemble vers les sommets ! <strong>#TEAMOBUS</strong></p>
		<?php echo hvb_reseaux(); // phpcs:ignore ?>
	</div>
</div>

<header class="entete" id="entete">
	<div class="entete__barre">
		<a class="entete__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Harnes Volley-Ball, accueil">
			<img src="<?php echo esc_url( HVB_URI . '/assets/img/logo-hvb.png' ); ?>" alt="" width="56" height="56">
			<span class="entete__nom">Harnes<br><strong>Volley-Ball</strong></span>
		</a>

		<nav class="nav" id="nav" aria-label="Menu principal">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'principal',
				'container'      => false,
				'menu_class'     => 'nav__liste',
				'fallback_cb'    => false,
				'depth'          => 2,
			) );
			?>
			<div class="nav__mobile-pied">
				<a class="bouton bouton--rouge bouton--large" href="<?php echo esc_url( hvb_club()['billetterie'] ); ?>"><?php echo hvb_icone( 'billet' ); // phpcs:ignore ?> Billetterie</a>
				<div class="nav__actions">
					<a class="bouton bouton--blanc" href="<?php echo esc_url( hvb_club()['boutique'] ); ?>"><?php echo hvb_icone( 'sac' ); // phpcs:ignore ?> Boutique</a>
					<a class="bouton bouton--contour" href="<?php echo esc_url( home_url( '/devenir-partenaire/' ) ); ?>">Devenir partenaire</a>
				</div>
				<p class="nav__suivez">Suivez le HVB</p>
				<?php echo hvb_reseaux(); // phpcs:ignore ?>
			</div>
		</nav>

		<div class="entete__actions">
			<a class="bouton bouton--contour entete__boutique" href="<?php echo esc_url( hvb_club()['boutique'] ); ?>" aria-label="Boutique">
				<?php echo hvb_icone( 'sac' ); // phpcs:ignore ?> <span>Boutique</span>
			</a>
			<a class="bouton bouton--rouge entete__billetterie" href="<?php echo esc_url( hvb_club()['billetterie'] ); ?>" aria-label="Billetterie">
				<?php echo hvb_icone( 'billet' ); // phpcs:ignore ?> <span>Billetterie</span>
			</a>
			<button class="burger" id="burger" aria-controls="nav" aria-expanded="false" aria-label="Ouvrir le menu">
				<span></span><span></span><span></span>
			</button>
		</div>
	</div>
</header>

<main id="contenu">
