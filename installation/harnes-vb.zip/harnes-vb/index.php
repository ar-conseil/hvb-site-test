<?php
/**
 * Liste des actualités (page « Actus ») et archives de catégories.
 */
get_header();
$titre = is_home() ? 'Actualités' : wp_strip_all_tags( get_the_archive_title() );
hvb_bandeau( $titre, 'La vie du club' );
?>
<div class="conteneur section">
	<?php if ( have_posts() ) : ?>
		<div class="grille-actus">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'parts/carte-actu' );
			endwhile;
			?>
		</div>
		<?php the_posts_pagination( array( 'prev_text' => 'Précédent', 'next_text' => 'Suivant' ) ); ?>
	<?php else : ?>
		<p>Aucune actualité pour le moment.</p>
	<?php endif; ?>
</div>
<?php
get_footer();
