<?php
/**
 * Template Name: Billetterie
 * Boutique Billetweb du club intégrée au site : matchs à domicile et abonnement de saison.
 * Le prochain match en vente est présélectionné ; ?match=AAAA-MM-JJ (liens de l'accueil et du calendrier)
 * présélectionne un autre match et amène directement à la boutique.
 */
get_header();
the_post();
hvb_bandeau( get_the_title(), 'Volstar Masculine 2 · Salle Maréchal', get_the_post_thumbnail_url( null, 'hvb-wide' ) );

$club    = hvb_club();
$billets = array();
foreach ( hvb_matchs( 'ASC', -1, array(
	array( 'key' => 'domicile', 'value' => '1' ),
	array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
) ) as $match ) {
	$billets[] = array(
		'titre' => 'HVB – ' . get_post_meta( $match->ID, 'adversaire', true ),
		'info'  => ( get_post_meta( $match->ID, 'competition', true ) ? get_post_meta( $match->ID, 'competition', true ) . ' · ' : '' ) . hvb_date_match( $match->ID ),
		'lien'  => get_post_meta( $match->ID, 'billetterie', true ),
		'date'  => get_post_meta( $match->ID, 'date', true ),
	);
}

// Matchs en vente d'abord (le plus proche en premier), l'abonnement ensuite.
$en_vente   = array_values( array_filter( $billets, fn( $b ) => $b['lien'] ) );
$en_vente[] = array( 'titre' => 'Abonnement 2026-2027', 'info' => 'Tous les matchs à domicile', 'lien' => $club['abonnement'], 'date' => 'abonnement' );
$demande    = sanitize_key( $_GET['match'] ?? '' );
$actif      = $en_vente[0];
foreach ( $en_vente as $billet ) {
	if ( $demande && $demande === $billet['date'] ) {
		$actif = $billet;
	}
}
$boutique = fn( $lien ) => add_query_arg( array( 'color' => 'd01818', 'margin' => 'no_margin' ), $lien );
?>
<div class="conteneur section section--billetterie">
	<div class="contenu billetterie__intro"><?php the_content(); ?></div>
	<div class="billetterie"<?php echo $demande ? ' data-aller-boutique' : ''; ?>>
		<div class="billetterie__choix">
			<p class="billetterie__etape"><span>1</span> Votre match</p>
			<div class="billetterie__liste" role="group" aria-label="Choisir un match ou l'abonnement">
				<?php foreach ( $en_vente as $billet ) : ?>
					<button class="billet" type="button" data-match="<?php echo esc_attr( $billet['date'] ); ?>" data-boutique="<?php echo esc_url( $boutique( $billet['lien'] ) ); ?>" data-lien="<?php echo esc_url( $billet['lien'] ); ?>" aria-pressed="<?php echo $billet === $actif ? 'true' : 'false'; ?>">
						<strong><?php echo esc_html( $billet['titre'] ); ?></strong>
						<span><?php echo esc_html( $billet['info'] ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="billetterie__colonne" id="boutique-zone">
			<p class="billetterie__etape"><span>2</span> Vos places</p>
			<div class="billetterie__boutique est-en-chargement">
				<div class="billetterie__chargement" role="status"><span class="billetterie__roue" aria-hidden="true"></span> Chargement de la billetterie…</div>
				<iframe id="boutique" src="<?php echo esc_url( $boutique( $actif['lien'] ) ); ?>" title="Billetterie Billetweb du Harnes Volley-Ball"></iframe>
			</div>
			<div class="billetterie__pied">
				<p class="billetterie__note">Paiement sécurisé par Billetweb. Billets envoyés par e-mail.</p>
				<a class="lien-fleche" id="boutique-lien" href="<?php echo esc_url( $actif['lien'] ); ?>" target="_blank" rel="noopener">Ouvrir dans Billetweb <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
			</div>
		</div>
		<?php
		// Matchs pas encore en vente : en liste compacte, après la boutique sur téléphone.
		$a_venir = array_filter( $billets, fn( $b ) => ! $b['lien'] );
		if ( $a_venir ) :
			?>
			<div class="billetterie__avenir">
				<p class="billetterie__avenir-titre">Prochains matchs à domicile · mise en vente prochainement</p>
				<ul>
					<?php foreach ( $a_venir as $billet ) : ?>
						<li><strong><?php echo esc_html( $billet['titre'] ); ?></strong> <span><?php echo esc_html( $billet['info'] ); ?></span></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>
	</div>
</div>
<?php
get_footer();
