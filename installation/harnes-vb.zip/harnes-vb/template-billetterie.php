<?php
/**
 * Template Name: Billetterie
 * Boutique Billetweb du club intégrée au site : matchs à domicile et abonnement de saison.
 */
get_header();
the_post();
hvb_bandeau( get_the_title(), 'Volstar Masculine 2 · Salle Maréchal', get_the_post_thumbnail_url( null, 'hvb-wide' ) );

$club    = hvb_club();
$billets = array();
foreach ( hvb_matchs( 'ASC', -1, array(
	array( 'key' => 'domicile', 'value' => '1' ),
	array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
) ) as $match ) {
	$billets[] = array(
		'titre' => 'HVB – ' . get_post_meta( $match->ID, 'adversaire', true ),
		'info'  => hvb_date_match( $match->ID ),
		'lien'  => get_post_meta( $match->ID, 'billetterie', true ),
	);
}
array_unshift( $billets, array( 'titre' => 'Abonnement saison 2026-2027', 'info' => 'Tous les matchs à domicile', 'lien' => $club['abonnement'] ) );

// Boutique affichée à l'ouverture : le prochain match en vente, sinon l'abonnement.
$en_vente = array_values( array_filter( $billets, fn( $b ) => $b['lien'] ) );
$actif    = $en_vente[1] ?? $en_vente[0];
$boutique = fn( $lien ) => add_query_arg( array( 'color' => 'd01818', 'margin' => 'no_margin' ), $lien );
?>
<div class="conteneur section">
	<div class="contenu"><?php the_content(); ?></div>
	<div class="billetterie">
		<div class="billetterie__liste" role="group" aria-label="Choisir un match ou l'abonnement">
			<?php foreach ( $billets as $billet ) : ?>
				<?php if ( $billet['lien'] ) : ?>
					<button class="billet" type="button" data-boutique="<?php echo esc_url( $boutique( $billet['lien'] ) ); ?>" data-lien="<?php echo esc_url( $billet['lien'] ); ?>" aria-pressed="<?php echo $billet === $actif ? 'true' : 'false'; ?>">
						<strong><?php echo esc_html( $billet['titre'] ); ?></strong>
						<span><?php echo esc_html( $billet['info'] ); ?></span>
					</button>
				<?php else : ?>
					<div class="billet billet--a-venir">
						<strong><?php echo esc_html( $billet['titre'] ); ?></strong>
						<span><?php echo esc_html( $billet['info'] ); ?> · Mise en vente prochainement</span>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<div class="billetterie__colonne" id="boutique-zone">
			<div class="billetterie__boutique">
				<iframe id="boutique" src="<?php echo esc_url( $boutique( $actif['lien'] ) ); ?>" title="Billetterie Billetweb du Harnes Volley-Ball" loading="lazy"></iframe>
			</div>
			<div class="billetterie__pied">
				<p class="billetterie__note">Paiement sécurisé par Billetweb.</p>
				<a class="bouton bouton--rouge" id="boutique-lien" href="<?php echo esc_url( $actif['lien'] ); ?>" target="_blank" rel="noopener"><?php echo hvb_icone( 'billet' ); // phpcs:ignore ?> Ouvrir la billetterie Billetweb</a>
			</div>
		</div>
	</div>
</div>
<?php
get_footer();
