<?php
/**
 * Template Name: Billetterie
 * Billetterie officielle du club, présentée comme une billetterie dédiée : bandeau du prochain match, abonnement,
 * matchs à domicile en forme de billets. « Réserver » ouvre la boutique Billetweb dans une fenêtre, sans quitter la page.
 * ?match=AAAA-MM-JJ (liens de l'accueil et du calendrier) ou ?match=abonnement ouvre directement la bonne boutique.
 */
get_header();
the_post();

$club     = hvb_club();
$boutique = fn( $lien ) => add_query_arg( array( 'color' => 'd01818', 'margin' => 'no_margin' ), $lien );
$matchs   = hvb_matchs( 'ASC', -1, array(
	array( 'key' => 'domicile', 'value' => '1' ),
	array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
	array( 'relation' => 'OR',
		array( 'key' => 'score_hvb', 'compare' => 'NOT EXISTS' ),
		array( 'key' => 'score_hvb', 'value' => '' ),
	),
) );
$en_vente = array_values( array_filter( $matchs, fn( $m ) => get_post_meta( $m->ID, 'billetterie', true ) ) );
$vedette  = $en_vente[0] ?? null;
$demande  = sanitize_key( $_GET['match'] ?? '' );

/** Attributs du bouton « Réserver » : la boutique s'ouvre dans la fenêtre de la page. */
$reserver = function ( $titre, $lien, $cle ) use ( $boutique ) {
	return sprintf( 'data-reserver data-titre="%s" data-boutique="%s" data-lien="%s" data-match="%s"',
		esc_attr( $titre ), esc_url( $boutique( $lien ) ), esc_url( $lien ), esc_attr( $cle ) );
};
$prix = fn( $m ) => str_replace( '.00', '', hvb_prix_billet( $m->ID ) );
?>
<div class="billetterie-hvb"<?php echo $demande ? ' data-ouvrir="' . esc_attr( $demande ) . '"' : ''; ?>>
	<div class="conteneur">

		<section class="bh-hero">
			<img class="bh-hero__filigrane" src="<?php echo esc_url( HVB_URI . '/assets/img/logo-hvb.png' ); ?>" alt="">
			<div class="bh-hero__texte">
				<p class="bh-hero__surtitre">Saison 2026-2027 · Salle Régionale Maréchal</p>
				<h1 class="bh-hero__titre">Billetterie officielle<br><span>Harnes Volley-Ball</span></h1>
				<?php if ( $vedette ) : ?>
					<?php list( $dom, $ext ) = hvb_equipes( $vedette->ID ); ?>
					<div class="bh-hero__match">
						<p class="bh-hero__etiquette">Prochain match · <?php echo esc_html( hvb_nom_rencontre( $vedette->ID ) ); ?></p>
						<p class="bh-hero__affiche"><?php echo esc_html( "$dom – $ext" ); ?></p>
						<p class="bh-hero__date"><?php echo esc_html( hvb_date_courte( $vedette->ID ) ); ?></p>
					</div>
					<div class="bh-hero__boutons">
						<button type="button" class="bouton bouton--rouge" <?php echo $reserver( "$dom – $ext", get_post_meta( $vedette->ID, 'billetterie', true ), get_post_meta( $vedette->ID, 'date', true ) ); // phpcs:ignore ?>>Réserver</button>
						<button type="button" class="bouton bouton--contour" <?php echo $reserver( 'Abonnement 2026-2027', $club['abonnement'], 'abonnement' ); // phpcs:ignore ?>>Abonnement</button>
					</div>
				<?php else : ?>
					<p class="bh-hero__date">Les prochains matchs à domicile seront bientôt en vente.</p>
					<div class="bh-hero__boutons">
						<button type="button" class="bouton bouton--rouge" <?php echo $reserver( 'Abonnement 2026-2027', $club['abonnement'], 'abonnement' ); // phpcs:ignore ?>>Prendre l'abonnement</button>
					</div>
				<?php endif; ?>
			</div>
		</section>

		<div class="bh-grille">
			<section class="bh-colonne bh-colonne--moment">
				<h2 class="bh-titre">En ce moment</h2>
				<article class="bh-abonnement">
					<div class="bh-abonnement__visuel" style="background-image:url('<?php echo esc_url( hvb_photo( 'equipe-2026-2027', 'hvb-wide' ) ); ?>')">
						<p><span>Harnes Volley-Ball</span>Abonnement<br>2026-2027</p>
					</div>
					<div class="bh-abonnement__carte">
						<h3>Abonnement de saison</h3>
						<p>Tous les matchs de championnat à domicile de la Volstar Masculine 2, à la Salle Régionale Maréchal.</p>
						<button type="button" class="bouton bouton--rouge" <?php echo $reserver( 'Abonnement 2026-2027', $club['abonnement'], 'abonnement' ); // phpcs:ignore ?>>Réserver</button>
					</div>
				</article>
			</section>

			<section class="bh-colonne">
				<div class="bh-entete">
					<h2 class="bh-titre">Matchs à domicile</h2>
					<a class="lien-fleche" href="<?php echo esc_url( home_url( '/calendrier-resultats/' ) ); ?>">Tout le calendrier <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
				</div>
				<?php foreach ( array_slice( $matchs, 0, 6 ) as $m ) : // Les 6 prochains ; la suite est au calendrier. ?>
					<?php
					list( $dom, $ext ) = hvb_equipes( $m->ID );
					$lien              = get_post_meta( $m->ID, 'billetterie', true );
					?>
					<article class="bh-billet<?php echo $lien ? '' : ' bh-billet--bientot'; ?>">
						<div class="bh-billet__souche">
							<?php echo hvb_blason( $dom ); // phpcs:ignore ?><span>vs</span><?php echo hvb_blason( $ext ); // phpcs:ignore ?>
						</div>
						<div class="bh-billet__corps">
							<h3 class="bh-billet__titre">Harnes <i></i> <?php echo esc_html( $ext ); ?></h3>
							<p class="bh-billet__competition"><?php echo esc_html( hvb_nom_rencontre( $m->ID ) ); ?></p>
							<p class="bh-billet__pastilles"><span><?php echo esc_html( hvb_date_courte( $m->ID ) ); ?></span><span>Salle Maréchal</span></p>
							<?php if ( $lien ) : ?>
								<div class="bh-billet__offres" id="offres-<?php echo (int) $m->ID; ?>" hidden>
									<ul>
										<li><span>Tarif normal</span><b><?php echo esc_html( $prix( $m ) ); ?> €</b></li>
										<li><span>Étudiant</span><b>3 €</b></li>
										<li><span>Moins de 12 ans</span><b>Gratuit</b></li>
										<li><span>Licenciés HVB</span><b>Gratuit, avec le code du club</b></li>
									</ul>
								</div>
							<?php endif; ?>
						</div>
						<div class="bh-billet__actions">
							<?php if ( $lien ) : ?>
								<button type="button" class="bouton bouton--rouge" <?php echo $reserver( "$dom – $ext", $lien, get_post_meta( $m->ID, 'date', true ) ); // phpcs:ignore ?>>Réserver</button>
								<button type="button" class="bh-billet__offres-lien" aria-expanded="false" aria-controls="offres-<?php echo (int) $m->ID; ?>">Voir les offres</button>
							<?php else : ?>
								<span class="bh-billet__bientot">Bientôt en vente</span>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
				<?php if ( ! $matchs ) : ?>
					<p class="bh-vide">Le calendrier des prochains matchs à domicile sera publié bientôt.</p>
				<?php endif; ?>
			</section>
		</div>

		<section class="bh-infos">
			<div><?php echo hvb_icone( 'billet' ); // phpcs:ignore ?><p><strong>Billets par e-mail</strong>À présenter sur téléphone ou imprimés.</p></div>
			<div><span class="bh-infos__pastille" aria-hidden="true">€</span><p><strong>Paiement sécurisé</strong>Réservation et paiement par Billetweb.</p></div>
			<div><span class="bh-infos__pastille" aria-hidden="true">HVB</span><p><strong>Salle Régionale Maréchal</strong><?php echo esc_html( $club['adresse'] ); ?></p></div>
		</section>
		<p class="bh-cgv">En réservant, vous acceptez les <a href="<?php echo esc_url( home_url( '/conditions-generales-de-vente/' ) ); ?>">conditions générales de vente</a>.</p>
	</div>

	<dialog class="bh-fenetre" aria-labelledby="bh-fenetre-titre">
		<div class="bh-fenetre__entete">
			<p id="bh-fenetre-titre">Réservation</p>
			<a class="bh-fenetre__externe" id="boutique-lien" href="#" target="_blank" rel="noopener">Ouvrir dans Billetweb</a>
			<button type="button" class="bh-fenetre__fermer" aria-label="Fermer">×</button>
		</div>
		<div class="bh-fenetre__corps">
			<div class="billetterie__boutique est-en-chargement">
				<div class="billetterie__chargement" role="status"><span class="billetterie__roue" aria-hidden="true"></span> Chargement de la billetterie…</div>
				<iframe id="boutique" title="Billetterie Billetweb du Harnes Volley-Ball"></iframe>
			</div>
		</div>
	</dialog>
</div>
<?php
get_footer();
