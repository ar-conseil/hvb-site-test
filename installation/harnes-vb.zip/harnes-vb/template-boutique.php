<?php
/**
 * Template Name: Boutique
 * Vitrine du merch : pas d'achat en ligne, les articles sont en vente au stand du club
 * les soirs de match à domicile.
 */
get_header();
the_post();

$produits = array(
	array( 'boutique-maillot-noir', 'Maillot officiel noir', 'Le maillot de la Volstar M2, aux couleurs charbon du club.' ),
	array( 'boutique-maillot-blanc', 'Maillot officiel blanc', 'La version claire, avec les bandes rouges et noires du HVB.' ),
);
$goodies = array(
	array( 'goodies-echarpe', 'Écharpe', 'Pour donner de la voix en tribune.' ),
	array( 'goodies-sweat', 'Sweat à capuche', 'Noir, logo du club sur le cœur.' ),
	array( 'goodies-tshirt', 'T-shirt #TEAMOBUS', 'Le rouge des supporters.' ),
	array( 'goodies-casquette', 'Casquette', 'Brodée du blason HVB.' ),
	array( 'goodies-bonnet', 'Bonnet', 'Rouge et noir, avec pompon.' ),
	array( 'goodies-mug', 'Mug', "Le café aux couleurs du club." ),
	array( 'goodies-gourde', 'Gourde', "Pour l'entraînement et le match." ),
	array( 'goodies-tote-bag', 'Tote bag', 'Ensemble vers les sommets !' ),
);
$portes = array( 'mediaday-8', 'mediaday-5', 'mediaday-4' );

// Prochain match à domicile : c'est là que le stand est ouvert.
$domicile = hvb_matchs( 'ASC', 1, array(
	array( 'key' => 'domicile', 'value' => '1' ),
	array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
) );
$prochain = $domicile ? $domicile[0] : null;
?>
<section class="vitrine">
	<div class="conteneur vitrine__grille">
		<div class="vitrine__texte">
			<nav class="ariane" aria-label="Fil d'Ariane">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Accueil</a>
				<span>Saison 2026-2027</span>
			</nav>
			<h1 class="vitrine__titre">Boutique <em>officielle</em></h1>
			<p class="vitrine__intro">Porte les couleurs du HVB : les maillots 2026-2027 de la Volstar M2 sont en vente au stand du club, à chaque match à domicile.</p>
			<div class="vitrine__actions">
				<a class="bouton bouton--rouge vitrine__bouton" href="#collection"><?php echo hvb_icone( 'sac' ); // phpcs:ignore ?> Voir la collection</a>
				<a class="vitrine__lien" href="#goodies">Goodies <?php echo hvb_icone( 'bas' ); // phpcs:ignore ?></a>
				<a class="vitrine__lien" href="#stand">Où acheter ? <?php echo hvb_icone( 'bas' ); // phpcs:ignore ?></a>
			</div>
		</div>
		<div class="vitrine__photo">
			<img src="<?php echo esc_url( hvb_photo( 'mediaday-3', 'large' ) ); ?>" alt="Trois joueurs du HVB présentent les maillots 2026-2027" width="819" height="1024">
		</div>
	</div>
</section>
<span id="suite"></span>

<section class="section" id="collection">
	<div class="conteneur">
		<div class="appli__entete">
			<p class="surtitre">Collection 2026-2027</p>
			<h2 class="titre-section">Les maillots <em>officiels</em></h2>
		</div>
		<div class="produits">
			<?php foreach ( $produits as list( $photo, $nom, $texte ) ) : ?>
				<article class="produit">
					<div class="produit__photo"><img src="<?php echo esc_url( hvb_photo( $photo, 'large' ) ); ?>" alt="<?php echo esc_attr( $nom ); ?>" loading="lazy"></div>
					<div class="produit__texte">
						<h3 class="produit__nom"><?php echo esc_html( $nom ); ?></h3>
						<p><?php echo esc_html( $texte ); ?></p>
						<span class="produit__dispo"><?php echo hvb_icone( 'lieu' ); // phpcs:ignore ?> En vente au stand les soirs de match</span>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section goodies-section" id="goodies">
	<div class="conteneur">
		<div class="appli__entete">
			<p class="surtitre">Collection supporters</p>
			<h2 class="titre-section">Les goodies <em>du HVB</em></h2>
		</div>
		<div class="goodies">
			<?php foreach ( $goodies as list( $photo, $nom, $texte ) ) : ?>
				<article class="goodie">
					<div class="goodie__photo"><img src="<?php echo esc_url( hvb_photo( $photo, 'large' ) ); ?>" alt="<?php echo esc_attr( $nom . ' HVB' ); ?>" loading="lazy"></div>
					<h3 class="goodie__nom"><?php echo esc_html( $nom ); ?></h3>
					<p><?php echo esc_html( $texte ); ?></p>
				</article>
			<?php endforeach; ?>
		</div>
		<p class="goodies__note"><?php echo hvb_icone( 'lieu' ); // phpcs:ignore ?> Au stand du club les soirs de match, selon les stocks · visuels non contractuels</p>
	</div>
</section>

<section class="portes" aria-label="Les maillots portés par les joueurs">
	<?php foreach ( $portes as $photo ) : ?>
		<figure class="portes__photo"><img src="<?php echo esc_url( hvb_photo( $photo, 'large' ) ); ?>" alt="Joueurs du HVB en maillot 2026-2027" loading="lazy"></figure>
	<?php endforeach; ?>
	<p class="portes__titre">Portés par <em>nos joueurs</em></p>
</section>

<section class="section stand" id="stand">
	<div class="conteneur stand__grille">
		<div class="stand__texte">
			<p class="surtitre">Où acheter ?</p>
			<h2 class="titre-section">Au stand <em>du club</em></h2>
			<p>Pas de vente en ligne pour le moment : retrouvez la boutique au stand du HVB, à la Salle Régionale Maréchal, lors de chaque match à domicile de la Volstar M2.</p>
		</div>
		<?php if ( $prochain ) : ?>
			<div class="stand__match">
				<span class="stand__etiquette">Prochain match à domicile</span>
				<strong class="stand__affiche">HVB – <?php echo esc_html( get_post_meta( $prochain->ID, 'adversaire', true ) ); ?></strong>
				<span class="stand__date"><?php echo hvb_icone( 'calendrier' ); // phpcs:ignore ?> <?php echo esc_html( hvb_date_match( $prochain->ID ) ); ?></span>
				<span class="stand__date"><?php echo hvb_icone( 'lieu' ); // phpcs:ignore ?> Salle Régionale Maréchal, Harnes</span>
				<a class="bouton bouton--rouge" href="<?php echo esc_url( hvb_club()['billetterie'] ); ?>"><?php echo hvb_icone( 'billet' ); // phpcs:ignore ?> Réserver mes places</a>
			</div>
		<?php endif; ?>
	</div>
</section>

<?php
get_footer();
