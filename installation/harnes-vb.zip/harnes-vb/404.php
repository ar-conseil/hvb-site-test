<?php
get_header();
hvb_bandeau( 'Page introuvable', 'Erreur 404' );
?>
<div class="conteneur conteneur--texte contenu">
	<p>Cette page n'existe pas ou a été déplacée.</p>
	<p><a class="bouton bouton--rouge" href="<?php echo esc_url( home_url( '/' ) ); ?>">Retour à l'accueil</a></p>
</div>
<?php
get_footer();
