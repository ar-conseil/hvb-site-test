</main>

<?php $club = hvb_club(); ?>

<?php if ( ! is_front_page() ) : ?>
<section class="appel">
	<div class="conteneur appel__grille">
		<div>
			<p class="surtitre">Saison 2026-2027</p>
			<h2 class="appel__titre">Venez vous entraîner<br><em>dans un club de haut niveau</em></h2>
		</div>
		<div class="appel__actions">
			<a class="bouton bouton--blanc" href="<?php echo esc_url( home_url( '/inscription/' ) ); ?>">Je m'inscris</a>
			<a class="bouton bouton--contour" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Nous contacter</a>
		</div>
	</div>
</section>
<?php endif; ?>

<?php $logos = hvb_logos_partenaires(); ?>
<?php if ( $logos ) : ?>
	<section class="partenaires" aria-label="Nos partenaires">
		<div class="partenaires__piste">
			<?php foreach ( array_merge( $logos, $logos ) as $i => $logo ) : ?>
				<a class="partenaires__logo" href="<?php echo esc_url( $logo['lien'] ); ?>"<?php echo $i >= count( $logos ) ? ' aria-hidden="true" tabindex="-1"' : ''; ?>>
					<img src="<?php echo esc_url( $logo['src'] ); ?>" alt="<?php echo esc_attr( $logo['nom'] ); ?>" loading="lazy">
				</a>
			<?php endforeach; ?>
		</div>
	</section>
<?php endif; ?>

<footer class="pied">
	<div class="conteneur pied__grille">
		<div class="pied__club">
			<img src="<?php echo esc_url( HVB_URI . '/assets/img/logo-hvb.png' ); ?>" alt="Harnes Volley-Ball" width="96" height="96" loading="lazy">
			<p class="pied__devise">Ensemble vers les sommets !<br><strong>#TEAMOBUS</strong></p>
		</div>
		<div>
			<h2 class="pied__titre">Nous trouver</h2>
			<p class="pied__ligne"><?php echo hvb_icone( 'lieu' ); // phpcs:ignore ?> <span><?php echo esc_html( $club['salle'] ); ?><br><?php echo esc_html( $club['adresse'] ); ?></span></p>
			<p class="pied__ligne"><?php echo hvb_icone( 'tel' ); // phpcs:ignore ?> <a href="tel:<?php echo esc_attr( str_replace( ' ', '', $club['telephone'] ) ); ?>"><?php echo esc_html( $club['telephone'] ); ?></a></p>
			<p class="pied__ligne"><?php echo hvb_icone( 'mail' ); // phpcs:ignore ?> <a href="mailto:<?php echo esc_attr( $club['email'] ); ?>"><?php echo esc_html( $club['email'] ); ?></a></p>
		</div>
		<div>
			<h2 class="pied__titre">Le club</h2>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'pied',
				'container'      => false,
				'menu_class'     => 'pied__menu',
				'fallback_cb'    => false,
				'depth'          => 1,
			) );
			?>
		</div>
		<div>
			<h2 class="pied__titre">Suivez le HVB</h2>
			<?php echo hvb_reseaux(); // phpcs:ignore ?>
			<div class="pied__labels">
				<img src="<?php echo esc_url( HVB_URI . '/assets/img/ffvb-blanc.svg' ); ?>" alt="Fédération française de volley" loading="lazy">
				<img src="<?php echo esc_url( HVB_URI . '/assets/img/volstar-m2.png' ); ?>" alt="Volstar Masculine 2" loading="lazy">
			</div>
		</div>
	</div>
	<div class="pied__bas">
		<div class="conteneur">
			<span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Harnes Volley-Ball</span>
			<span class="pied__liens-legaux">
				<a href="<?php echo esc_url( home_url( '/mentions-legales/' ) ); ?>">Mentions légales</a>
				<a href="<?php echo esc_url( home_url( '/politique-de-confidentialite/' ) ); ?>">Confidentialité et cookies</a>
				<a href="<?php echo esc_url( home_url( '/conditions-generales-de-vente/' ) ); ?>">CGV</a>
				<a href="<?php echo esc_url( home_url( '/droit-de-retractation/' ) ); ?>">Droit de rétractation</a>
				<a href="<?php echo esc_url( home_url( '/confidentialite/' ) ); ?>">Confidentialité de l'appli HVB Partenaires</a>
			</span>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
