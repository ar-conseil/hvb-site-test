<?php
/**
 * Thème Harnes Volley-Ball.
 */

define( 'HVB_VERSION', '1.0.11' );
define( 'HVB_URI', get_template_directory_uri() );

require get_template_directory() . '/inc/types.php';
require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/seo.php';
require get_template_directory() . '/inc/classement.php';
require get_template_directory() . '/inc/resultats-pro.php';
require get_template_directory() . '/inc/annonce-match.php';
require get_template_directory() . '/inc/ffvb.php';
require get_template_directory() . '/inc/redirections.php';

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'harnes-vb' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/editor.css' );

	add_image_size( 'hvb-card', 640, 800, true );
	add_image_size( 'hvb-wide', 1600, 900, true );

	register_nav_menus( array(
		'principal' => 'Menu principal',
		'pied'      => 'Menu de pied de page',
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	// Polices hébergées avec le site : même rendu partout, sans dépendre de Google Fonts.
	wp_enqueue_style( 'hvb-fonts', HVB_URI . '/assets/fonts/polices.css', array(), filemtime( get_template_directory() . '/assets/fonts/polices.css' ) );
	wp_enqueue_style( 'hvb', get_stylesheet_uri(), array( 'hvb-fonts' ), filemtime( get_stylesheet_directory() . '/style.css' ) );
	wp_enqueue_script( 'hvb', HVB_URI . '/assets/js/main.js', array(), filemtime( get_template_directory() . '/assets/js/main.js' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
} );

// Les blocs du site n'ont pas besoin des styles globaux de thème bloc.
add_action( 'wp_enqueue_scripts', function () {
	wp_dequeue_style( 'global-styles' );
}, 100 );

add_filter( 'excerpt_length', fn() => 22 );
add_filter( 'excerpt_more', fn() => '…' );

/**
 * Coordonnées du club, utilisées dans l'en-tête, le pied de page et la page Contact.
 */
function hvb_club() {
	return array(
		'nom'         => 'Harnes Volley-Ball',
		'salle'       => 'Salle Régionale Maréchal',
		'adresse'     => '128 Chemin Valois, 62440 Harnes',
		'telephone'   => '03 21 18 65 02',
		'email'       => 'contact@harnes-volleyball.fr',
		// Page Billetterie du site, qui intègre la boutique Billetweb du club.
		'billetterie' => home_url( '/billetterie/' ),
		'abonnement'  => 'https://www.billetweb.fr/shop.php?event=abonnement-saison-lbm-2026-2027',
		'prix_billet' => '7.00', // Tarif normal d'un match à domicile depuis le 14/11/2026 ; un match peut avoir son propre prix (champ « Prix »).
		// Vitrine du merch (vente au stand les soirs de match) ; à remplacer par la boutique en ligne quand elle existera.
		'boutique'      => home_url( '/boutique/' ),
		// Fiches de l'appli HVB Partenaires sur les stores : à remplir le jour de la sortie (vide = « bientôt disponible »).
		'appli_ios'     => '',
		'appli_android' => '',
		// Réseau => array( adresse, compte affiché ).
		'reseaux'     => array(
			'facebook'  => array( 'https://www.facebook.com/harnes.volleyball62', 'harnes.volleyball62' ),
			'instagram' => array( 'https://www.instagram.com/harnesvb', '@harnesvb' ),
			'x'         => array( 'https://x.com/harnesvb', '@harnesvb' ),
			'youtube'   => array( 'https://www.youtube.com/c/hvbtv', 'HVB TV' ),
			'tiktok'    => array( 'https://www.tiktok.com/@hvb.and.co', '@hvb.and.co' ),
			'linkedin'  => array( 'https://www.linkedin.com/in/harnes-volley-ball-ab2b63164/', 'Harnes Volley-Ball' ),
		),
	);
}

// Classe « page-<slug> » sur le body, pour les réglages propres à certaines pages.
add_filter( 'body_class', function ( $classes ) {
	if ( is_page() ) {
		$classes[] = 'page-' . get_post_field( 'post_name', get_queried_object_id() );
	}
	return $classes;
} );
