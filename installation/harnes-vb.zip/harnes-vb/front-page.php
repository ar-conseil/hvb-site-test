<?php
/**
 * Page d'accueil, sur le modèle de tourcoing-volley.com : carrousel « à la une » (prochain match, abonnement,
 * partenariat, section féminine, école de volley), matchs à domicile en forme de billets, scores et classement,
 * actualités, boutique et partenariat, bannière LNV TV et réseaux sociaux.
 */
get_header();

$prochain = hvb_prochain_match();
$club     = hvb_club();
/** Première photo de la médiathèque trouvée parmi ces noms (le site en ligne et la copie locale diffèrent parfois). */
$photo = function ( ...$noms ) {
	foreach ( $noms as $nom ) {
		if ( hvb_photo_id( $nom ) ) {
			return hvb_photo_id( $nom );
		}
	}
	return 0;
};

// Diapositives « à la une » : prochain match, puis les grands sujets du club.
$diapos = array();
if ( $prochain ) {
	list( $dom, $ext ) = hvb_equipes( $prochain->ID );
	$domicile          = get_post_meta( $prochain->ID, 'domicile', true );
	$heure             = get_post_meta( $prochain->ID, 'heure', true );
	$jour              = wp_date( 'l j F Y', strtotime( get_post_meta( $prochain->ID, 'date', true ) . ' 12:00' ) );
	$diapos[]          = array(
		'photo'     => $photo( 'salle-marechal-min-scaled-1' ),
		'alt'       => 'La Salle Régionale Maréchal pleine un soir de match',
		'etiquette' => hvb_nom_rencontre( $prochain->ID ) . ' · ' . ( $domicile ? 'Salle Maréchal' : 'Extérieur' ),
		'titre'     => 'Prochain match',
		'texte'     => str_replace( 'Harnes VB', 'Harnes', "$dom vs $ext" ) . " le $jour" . ( $heure ? ' à ' . preg_replace( '#^(\d+):00$|^(\d+):(\d+)$#', '$1$2h$3', $heure ) : '' ),
		'compte'    => hvb_coup_envoi( $prochain->ID ),
		'boutons'   => array(
			$domicile
				? array( get_post_meta( $prochain->ID, 'billetterie', true ) ? 'Réserver ma place' : 'Billetterie', hvb_lien_billetterie( $prochain->ID ) )
				: array( 'Suivre le match sur LNV TV', 'https://www.lnvtv.com/' ),
			array( 'Calendrier et résultats', home_url( '/calendrier-resultats/' ) ),
		),
	);
}
$diapos[] = array(
	'photo'     => $photo( 'equipe-2026-2027' ),
	'alt'       => "L'équipe Volstar Masculine 2 du Harnes Volley-Ball, saison 2026-2027",
	'etiquette' => 'Saison 2026-2027',
	'titre'     => 'Abonnement',
	'texte'     => 'Tous les matchs de championnat à domicile à la Salle Régionale Maréchal, au plus près de l\'équipe.',
	'boutons'   => array( array( 'Prendre mon abonnement', $club['reserver'] ) ),
);
$diapos[] = array(
	'photo'     => $photo( 'champions2025' ),
	'alt'       => 'Les joueurs du Harnes Volley-Ball fêtent le titre de champion de France Elite 2025',
	'etiquette' => 'Entreprises',
	'titre'     => 'Devenez partenaire',
	'texte'     => 'Associez votre entreprise au HVB : visibilité, salon VIP les soirs de match et réseau du Business Club.',
	'boutons'   => array( array( 'Découvrir les packs', home_url( '/devenir-partenaire/' ) ) ),
);
$diapos[] = array(
	'photo'     => $photo( 'feminine-1' ),
	'alt'       => "L'équipe de la section féminine du HVB en tenue noire et rose, salle Maréchal",
	'etiquette' => 'Nouveau au HVB',
	'titre'     => 'Section féminine',
	'texte'     => "Le volley loisir au féminin, porté par d'anciennes joueuses de haut niveau. Venez faire un essai !",
	'boutons'   => array( array( 'Découvrir la section', home_url( '/section-feminine/' ) ) ),
);
$diapos[] = array(
	'photo'     => $photo( 'img_9476-2', 'img_9476', 'img_9477-2', 'img_9477' ),
	'alt'       => 'Les jeunes de l\'école de volley du HVB à l\'entraînement',
	'etiquette' => '7-11 ans',
	'titre'     => 'École de volley',
	'texte'     => 'Apprendre les gestes, jouer des tournois et progresser en s\'amusant, le mercredi et le samedi à Harnes.',
	'boutons'   => array(
		array( "Découvrir l'école de volley", home_url( '/ecole-de-volley/' ) ),
		array( 'Inscription', home_url( '/inscription/' ) ),
	),
);
$diapos = array_values( array_filter( $diapos, fn( $d ) => $d['photo'] ) );
?>

<section class="acc-hero" data-carrousel-une aria-roledescription="carrousel" aria-label="À la une">
	<h1 class="visuellement-cache">Harnes Volley-Ball : club de volley à Harnes (Pas-de-Calais)</h1>
	<div class="acc-hero__diapos" aria-live="off">
		<?php foreach ( $diapos as $i => $d ) : ?>
			<article class="acc-diapo<?php echo 0 === $i ? ' is-active' : ''; ?>" role="group" aria-roledescription="diapositive" aria-label="<?php echo esc_attr( ( $i + 1 ) . ' sur ' . count( $diapos ) . ' : ' . $d['titre'] ); ?>"<?php echo 0 === $i ? '' : ' aria-hidden="true" inert'; ?>>
				<?php
				echo wp_get_attachment_image( $d['photo'], 'full', false, array( // phpcs:ignore
					'class'         => 'acc-hero__image',
					'sizes'         => '100vw',
					'alt'           => $d['alt'],
					'loading'       => 0 === $i ? 'eager' : 'lazy',
					'fetchpriority' => 0 === $i ? 'high' : 'auto',
				) );
				?>
				<div class="acc-hero__texte">
					<p class="acc-hero__etiquette"><?php echo esc_html( $d['etiquette'] ); ?></p>
					<p class="acc-hero__titre"><?php echo esc_html( $d['titre'] ); ?></p>
					<p class="acc-hero__match"><?php echo esc_html( $d['texte'] ); ?></p>
					<?php if ( ! empty( $d['compte'] ) ) : ?>
						<div class="compte acc-hero__compte" data-compte="<?php echo esc_attr( $d['compte'] ); ?>">
							<div><strong data-j>--</strong><span>jours</span></div>
							<div><strong data-h>--</strong><span>heures</span></div>
							<div><strong data-m>--</strong><span>min</span></div>
							<div><strong data-s>--</strong><span>sec</span></div>
						</div>
					<?php endif; ?>
					<div class="acc-hero__boutons">
						<?php foreach ( $d['boutons'] as $j => list( $libelle, $url ) ) : ?>
							<a class="bouton <?php echo 0 === $j ? 'bouton--rouge' : 'bouton--contour'; ?>" href="<?php echo esc_url( $url ); ?>"<?php echo 0 === strpos( $url, home_url() ) || $club['reserver'] === $url ? '' : ' target="_blank" rel="noopener"'; ?>><?php echo esc_html( $libelle ); ?></a>
						<?php endforeach; ?>
					</div>
				</div>
			</article>
		<?php endforeach; ?>
	</div>
	<?php if ( count( $diapos ) > 1 ) : ?>
		<button type="button" class="acc-hero__fleche acc-hero__fleche--prec" data-une-prec aria-label="Diapositive précédente"><?php echo hvb_icone( 'gauche' ); // phpcs:ignore ?></button>
		<button type="button" class="acc-hero__fleche acc-hero__fleche--suiv" data-une-suiv aria-label="Diapositive suivante"><?php echo hvb_icone( 'droite' ); // phpcs:ignore ?></button>
		<div class="acc-hero__points" role="group" aria-label="Choisir la diapositive">
			<?php foreach ( $diapos as $i => $d ) : ?>
				<button type="button" data-diapo="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr( $d['titre'] ); ?>"<?php echo 0 === $i ? ' aria-current="true"' : ''; ?>></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<a class="acc-hero__suite" href="#accueil-suite" aria-label="Découvrir la suite"><?php echo hvb_icone( 'bas' ); // phpcs:ignore ?></a>
</section>

<?php
$a_domicile = hvb_matchs( 'ASC', 3, array(
	array( 'key' => 'domicile', 'value' => '1' ),
	array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
	array( 'relation' => 'OR',
		array( 'key' => 'score_hvb', 'compare' => 'NOT EXISTS' ),
		array( 'key' => 'score_hvb', 'value' => '' ),
	),
) );
?>
<section class="acc-vibrer" id="accueil-suite">
	<div class="conteneur">
		<h2 class="acc-titre">Venez vibrer avec le HVB</h2>
		<div class="acc-vibrer__boite">
			<div class="bh-entete">
				<h3 class="bh-titre">Matchs à domicile</h3>
				<a class="lien-fleche" href="<?php echo esc_url( hvb_club()['billetterie'] ); ?>">Toute la billetterie <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
			</div>
			<?php foreach ( $a_domicile as $m ) : ?>
				<?php
				list( $dom, $ext ) = hvb_equipes( $m->ID );
				$lien              = get_post_meta( $m->ID, 'billetterie', true );
				?>
				<article class="bh-billet<?php echo $lien ? '' : ' bh-billet--bientot'; ?>">
					<div class="bh-billet__souche">
						<?php echo hvb_blason( $dom ); // phpcs:ignore ?><span>vs</span><?php echo hvb_blason( $ext ); // phpcs:ignore ?>
					</div>
					<div class="bh-billet__corps">
						<h4 class="bh-billet__titre">Harnes <i></i> <?php echo esc_html( $ext ); ?></h4>
						<p class="bh-billet__competition"><?php echo esc_html( hvb_nom_rencontre( $m->ID ) ); ?></p>
						<p class="bh-billet__pastilles"><span><?php echo esc_html( hvb_date_courte( $m->ID ) ); ?></span><span>Salle Maréchal</span></p>
					</div>
					<div class="bh-billet__actions">
						<?php if ( $lien ) : ?>
							<a class="bouton bouton--rouge" href="<?php echo esc_url( hvb_lien_billetterie( $m->ID ) ); ?>">Réserver</a>
							<a class="bh-billet__offres-lien" href="<?php echo esc_url( hvb_club()['billetterie'] ); ?>">Voir les offres</a>
						<?php else : ?>
							<span class="bh-billet__bientot">Bientôt en vente</span>
						<?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
			<?php if ( ! $a_domicile ) : ?>
				<p class="bh-vide">Le calendrier des prochains matchs à domicile sera publié bientôt.</p>
			<?php endif; ?>
		</div>
	</div>
</section>

<?php
// Journées : les derniers résultats puis les prochains matchs, toutes compétitions.
$joues    = array_reverse( hvb_matchs( 'DESC', 3, array( array( 'key' => 'score_hvb', 'value' => '', 'compare' => '!=' ) ) ) );
$suivants = hvb_matchs( 'ASC', 3, array(
	array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
	array( 'relation' => 'OR',
		array( 'key' => 'score_hvb', 'compare' => 'NOT EXISTS' ),
		array( 'key' => 'score_hvb', 'value' => '' ),
	),
) );
?>
<section class="acc-scores">
	<div class="conteneur">
		<h2 class="acc-titre">Scores et classement saison 2026-2027</h2>
		<div class="acc-scores__grille">
			<div class="acc-carte">
				<h3 class="acc-carte__titre">Journées</h3>
				<ul class="acc-journees">
					<?php foreach ( array_merge( $joues, $suivants ) as $m ) : ?>
						<?php
						list( $dom, $ext ) = hvb_equipes( $m->ID );
						$score             = hvb_score( $m->ID );
						$heure             = get_post_meta( $m->ID, 'heure', true );
						?>
						<li class="acc-journee<?php echo $score ? ' acc-journee--jouee' : ''; ?>">
							<p class="acc-journee__info"><span><?php echo esc_html( hvb_nom_rencontre( $m->ID ) ); ?></span><span><?php echo esc_html( wp_date( 'd/m/Y', strtotime( get_post_meta( $m->ID, 'date', true ) . ' 12:00' ) ) ); ?></span></p>
							<p class="acc-journee__match">
								<span class="acc-journee__equipe"><?php echo esc_html( $dom ); ?></span>
								<?php echo hvb_blason( $dom ); // phpcs:ignore ?>
								<strong class="acc-journee__score"><?php echo esc_html( $score ?: ( $heure ? str_replace( ':', 'h', $heure ) : 'vs' ) ); ?></strong>
								<?php echo hvb_blason( $ext ); // phpcs:ignore ?>
								<span class="acc-journee__equipe"><?php echo esc_html( $ext ); ?></span>
							</p>
						</li>
					<?php endforeach; ?>
				</ul>
				<a class="lien-fleche" href="<?php echo esc_url( home_url( '/calendrier-resultats/' ) ); ?>">Calendrier et résultats <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
			</div>
			<div class="acc-carte">
				<div class="carte__entete">
					<h3 class="acc-carte__titre">Classement</h3>
					<img src="<?php echo esc_url( HVB_URI . '/assets/img/volstar-m2.png' ); ?>" alt="Volstar Masculine 2" width="48" height="46">
				</div>
				<div class="classement"><?php echo hvb_tableau_classement( false ); // phpcs:ignore ?></div>
				<a class="lien-fleche" href="<?php echo esc_url( home_url( '/classement/' ) ); ?>">Classement complet <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
			</div>
		</div>
	</div>
</section>

<?php $actus = get_posts( array( 'posts_per_page' => 5 ) ); ?>
<?php if ( $actus ) : ?>
	<section class="actus-une" aria-label="Actualités">
		<div class="carrousel" data-carrousel>
			<?php foreach ( $actus as $i => $actu ) : ?>
				<article class="carrousel__diapo<?php echo 0 === $i ? ' is-active' : ''; ?>">
					<a class="carrousel__visuel" href="<?php echo esc_url( get_permalink( $actu ) ); ?>" tabindex="-1" aria-hidden="true">
						<?php echo get_the_post_thumbnail( $actu, 'large', array( 'class' => 'carrousel__image', 'loading' => 'lazy', 'alt' => get_the_title( $actu ) ) ); ?>
					</a>
					<div class="carrousel__texte">
						<p class="surtitre"><?php echo esc_html( get_the_category( $actu->ID )[0]->name ?? 'Actualité' ); ?> · <?php echo esc_html( get_the_date( 'j F Y', $actu ) ); ?></p>
						<h2 class="carrousel__titre"><a href="<?php echo esc_url( get_permalink( $actu ) ); ?>"><?php echo esc_html( get_the_title( $actu ) ); ?></a></h2>
						<p class="carrousel__extrait"><?php echo esc_html( wp_trim_words( get_the_excerpt( $actu ), 22 ) ); ?></p>
						<a class="bouton bouton--rouge carrousel__bouton" href="<?php echo esc_url( get_permalink( $actu ) ); ?>">Lire l'article <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
					</div>
				</article>
			<?php endforeach; ?>
			<button class="carrousel__fleche carrousel__fleche--prec" data-prec aria-label="Actualité précédente"><?php echo hvb_icone( 'gauche' ); // phpcs:ignore ?></button>
			<button class="carrousel__fleche carrousel__fleche--suiv" data-suiv aria-label="Actualité suivante"><?php echo hvb_icone( 'droite' ); // phpcs:ignore ?></button>
			<div class="carrousel__points" data-points></div>
		</div>
	</section>
<?php endif; ?>

<?php hvb_actions_cles(); ?>

<section class="acc-lnvtv">
	<div class="conteneur">
		<a class="acc-lnvtv__bandeau" href="https://www.lnvtv.com/" target="_blank" rel="noopener" aria-label="Regarder les matchs du HVB sur LNV TV">
			<img class="acc-lnvtv__joueur acc-lnvtv__joueur--gauche" src="<?php echo esc_url( HVB_URI . '/assets/img/joueurs/joueur-12.webp' ); ?>" alt="" loading="lazy">
			<span class="acc-lnvtv__texte">
				<span class="acc-lnvtv__surtitre">Volstar Masculine 2 · Saison 2026-2027</span>
				<strong class="acc-lnvtv__titre">100 % des matchs</strong>
				<span class="acc-lnvtv__soustitre">en direct et en replay sur</span>
				<img class="acc-lnvtv__logo" src="<?php echo esc_url( HVB_URI . '/assets/img/lnv-tv.png' ); ?>" alt="LNV TV" width="230" height="90" loading="lazy">
				<span class="bouton bouton--rouge acc-lnvtv__bouton">Regarder sur LNV TV</span>
			</span>
			<img class="acc-lnvtv__joueur acc-lnvtv__joueur--droite" src="<?php echo esc_url( HVB_URI . '/assets/img/joueurs/joueur-60.webp' ); ?>" alt="" loading="lazy">
		</a>
	</div>
</section>

<section class="suivez">
	<div class="conteneur">
		<p class="surtitre">#TEAMOBUS</p>
		<h2 class="suivez__titre">Suivez le HVB</h2>
		<ul class="suivez__liste">
			<?php foreach ( hvb_club()['reseaux'] as $reseau => list( $url, $compte ) ) : ?>
				<li>
					<a class="suivez__lien suivez__lien--<?php echo esc_attr( $reseau ); ?>" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">
						<?php echo hvb_icone( $reseau ); // phpcs:ignore ?>
						<strong><?php echo esc_html( HVB_NOMS_RESEAUX[ $reseau ] ); ?></strong>
						<span><?php echo esc_html( $compte ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<?php
get_footer();
