<?php
/**
 * Page d'accueil, sur le modèle épuré de snvba.fr :
 * titre plein écran, photo d'équipe et devise, actualités, matchs et classement.
 */
get_header();

$dernier  = hvb_dernier_match();
$prochain = hvb_prochain_match();
?>

<section class="ouverture">
	<?php // Défilé en filigrane : joueurs du Media Day détourés, en noir et blanc, qui traversent l'écran en boucle. ?>
	<div class="ouverture__defile" aria-hidden="true">
		<div class="ouverture__piste">
			<?php foreach ( array( 1, 2 ) as $tour ) : ?>
				<?php foreach ( array( 3, 1, 5, 6, 4, 8, 7 ) as $n ) : ?>
					<?php list( $l, $h ) = getimagesize( get_template_directory() . "/assets/img/defile/joueurs-$n.webp" ); ?>
					<img src="<?php echo esc_url( HVB_URI . "/assets/img/defile/joueurs-$n.webp" ); ?>" alt="" width="<?php echo (int) $l; ?>" height="<?php echo (int) $h; ?>" decoding="async"<?php echo 2 === $tour ? ' loading="lazy"' : ( 3 === $n ? ' fetchpriority="high"' : '' ); ?>>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</div>
	</div>
	<div class="ouverture__texte">
		<img class="ouverture__logo" src="<?php echo esc_url( HVB_URI . '/assets/img/logo-hvb.png' ); ?>" alt="" width="132" height="132">
		<h1 class="ouverture__titre">Harnes<br>Volley-Ball<span class="visuellement-cache"> : club de volley à Harnes (Pas-de-Calais)</span></h1>
		<span class="ouverture__trait" aria-hidden="true"></span>
	</div>
	<a class="ouverture__suite" href="#accueil-suite" aria-label="Découvrir la suite"><?php echo hvb_icone( 'bas' ); // phpcs:ignore ?></a>
</section>

<section class="devise" id="accueil-suite">
	<?php $id_equipe = hvb_photo_id( 'equipe-2026-2027' ); ?>
	<img class="devise__photo" src="<?php echo esc_url( hvb_photo( 'equipe-2026-2027', 'large' ) ); ?>" srcset="<?php echo esc_attr( wp_get_attachment_image_srcset( $id_equipe, 'full' ) ); ?>" sizes="100vw" alt="L'équipe Volstar Masculine 2 du Harnes Volley-Ball, saison 2026-2027" loading="lazy">
	<div class="devise__texte">
		<h2 class="devise__titre">La passion du volley<br>pour tous</h2>
		<a class="lien-fleche lien-fleche--clair" href="<?php echo esc_url( home_url( '/presentation-du-club/' ) ); ?>">Le club <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
	</div>
</section>

<?php $actus = get_posts( array( 'posts_per_page' => 5 ) ); ?>
<?php if ( $actus ) : ?>
	<section class="actus-une" aria-label="Actualités">
		<div class="carrousel" data-carrousel>
			<?php foreach ( $actus as $i => $actu ) : ?>
				<article class="carrousel__diapo<?php echo 0 === $i ? ' is-active' : ''; ?>">
					<a class="carrousel__visuel" href="<?php echo esc_url( get_permalink( $actu ) ); ?>" tabindex="-1" aria-hidden="true">
						<?php echo get_the_post_thumbnail( $actu, 'large', array( 'class' => 'carrousel__image', 'loading' => 0 === $i ? 'eager' : 'lazy', 'alt' => get_the_title( $actu ), 'fetchpriority' => 0 === $i ? 'high' : 'auto' ) ); ?>
					</a>
					<div class="carrousel__texte">
						<p class="surtitre"><?php echo esc_html( get_the_category( $actu->ID )[0]->name ?? 'Actualité' ); ?> · <?php echo esc_html( get_the_date( 'j F Y', $actu ) ); ?></p>
						<h2 class="carrousel__titre"><a href="<?php echo esc_url( get_permalink( $actu ) ); ?>"><?php echo esc_html( get_the_title( $actu ) ); ?></a></h2>
						<p class="carrousel__extrait"><?php echo esc_html( wp_trim_words( get_the_excerpt( $actu ), 22 ) ); ?></p>
						<a class="bouton bouton--rouge carrousel__bouton" href="<?php echo esc_url( get_permalink( $actu ) ); ?>">Lire l'article <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
					</div>
				</article>
			<?php endforeach; ?>
			<button class="carrousel__fleche carrousel__fleche--prec" data-prec aria-label="Actualité précédente"><?php echo hvb_icone( 'gauche' ); // phpcs:ignore ?></button>
			<button class="carrousel__fleche carrousel__fleche--suiv" data-suiv aria-label="Actualité suivante"><?php echo hvb_icone( 'droite' ); // phpcs:ignore ?></button>
			<div class="carrousel__points" data-points></div>
		</div>
	</section>
<?php endif; ?>

<?php // Fond flouté : défini ici pour que l'adresse de l'image se résolve depuis la page. ?>
<style>.centre-match::before { background-image: url('<?php echo esc_url( hvb_photo( 'equipe-2026-2027', 'large' ) ); ?>'); }</style>
<section class="centre-match">
	<div class="conteneur centre-match__grille">
		<div class="carte carte--match">
			<h2 class="carte__titre">Dernier et prochain match</h2>

			<?php if ( $dernier ) : ?>
				<?php list( $dom, $ext ) = hvb_equipes( $dernier->ID ); ?>
				<div class="affiche affiche--passe">
					<p class="affiche__etiquette">Dernier match · <?php echo esc_html( hvb_date_match( $dernier->ID, false ) ); ?></p>
					<div class="affiche__equipes">
						<div class="affiche__equipe"><?php echo hvb_blason( $dom ); // phpcs:ignore ?><span><?php echo esc_html( $dom ); ?></span></div>
						<?php $score = hvb_score( $dernier->ID ); ?>
						<div class="affiche__score<?php echo 'Forfait' === $score ? ' affiche__score--forfait' : ''; ?>"><?php echo esc_html( $score ); ?></div>
						<div class="affiche__equipe"><?php echo hvb_blason( $ext ); // phpcs:ignore ?><span><?php echo esc_html( $ext ); ?></span></div>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( $prochain ) : ?>
				<?php
				list( $dom, $ext ) = hvb_equipes( $prochain->ID );
				$lien              = get_post_meta( $prochain->ID, 'billetterie', true );
				$domicile          = get_post_meta( $prochain->ID, 'domicile', true );
				?>
				<div class="affiche affiche--prochain">
					<p class="affiche__etiquette">Prochain match · J<?php echo esc_html( get_post_meta( $prochain->ID, 'journee', true ) ); ?> · <?php echo $domicile ? 'Salle Maréchal' : 'Extérieur'; ?></p>
					<div class="affiche__equipes">
						<div class="affiche__equipe"><?php echo hvb_blason( $dom ); // phpcs:ignore ?><span><?php echo esc_html( $dom ); ?></span></div>
						<div class="affiche__date"><?php echo esc_html( hvb_date_match( $prochain->ID ) ); ?></div>
						<div class="affiche__equipe"><?php echo hvb_blason( $ext ); // phpcs:ignore ?><span><?php echo esc_html( $ext ); ?></span></div>
					</div>
					<div class="compte" data-compte="<?php echo esc_attr( hvb_coup_envoi( $prochain->ID ) ); ?>">
						<div><strong data-j>--</strong><span>jours</span></div>
						<div><strong data-h>--</strong><span>heures</span></div>
						<div><strong data-m>--</strong><span>min</span></div>
						<div><strong data-s>--</strong><span>sec</span></div>
					</div>
					<?php if ( $domicile ) : ?>
						<a class="bouton bouton--rouge bouton--large" href="<?php echo esc_url( hvb_lien_billetterie( $prochain->ID ) ); ?>">
							<?php echo hvb_icone( 'billet' ); // phpcs:ignore ?> <?php echo $lien ? 'Réserver ma place' : 'Billetterie & abonnements'; ?>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<a class="lien-fleche" href="<?php echo esc_url( home_url( '/calendrier-resultats/' ) ); ?>">Calendrier et résultats <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
		</div>

		<div class="carte carte--classement">
			<div class="carte__entete">
				<h2 class="carte__titre">Classement</h2>
				<img src="<?php echo esc_url( HVB_URI . '/assets/img/volstar-m2.png' ); ?>" alt="Volstar Masculine 2" width="48" height="46">
			</div>
			<div class="classement"><?php echo hvb_tableau_classement( false ); // phpcs:ignore ?></div>
			<a class="lien-fleche" href="<?php echo esc_url( home_url( '/classement/' ) ); ?>">Classement complet <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a>
		</div>
	</div>
</section>

<?php hvb_actions_cles(); ?>

<section class="suivez">
	<div class="conteneur">
		<p class="surtitre">#TEAMOBUS</p>
		<h2 class="suivez__titre">Suivez le HVB</h2>
		<ul class="suivez__liste">
			<?php foreach ( hvb_club()['reseaux'] as $reseau => list( $url, $compte ) ) : ?>
				<li>
					<a class="suivez__lien suivez__lien--<?php echo esc_attr( $reseau ); ?>" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">
						<?php echo hvb_icone( $reseau ); // phpcs:ignore ?>
						<strong><?php echo esc_html( HVB_NOMS_RESEAUX[ $reseau ] ); ?></strong>
						<span><?php echo esc_html( $compte ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<?php
get_footer();
