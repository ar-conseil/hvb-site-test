<?php
get_header();
while ( have_posts() ) :
	the_post();
	$categorie = get_the_category()[0]->name ?? 'Actualité';
	hvb_bandeau( get_the_title(), $categorie . ' · ' . get_the_date( 'j F Y' ), get_the_post_thumbnail_url( null, 'hvb-wide' ) );
	?>
	<article class="conteneur conteneur--texte contenu">
		<?php the_content(); ?>
		<p><a class="lien-fleche" href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>">Toutes les actualités <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></a></p>
	</article>
	<?php
endwhile;
get_footer();
