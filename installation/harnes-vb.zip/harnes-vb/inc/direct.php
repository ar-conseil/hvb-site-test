<?php
/**
 * Score en direct des matchs pro, tenu dans l'appli Harnes Volleyball par le staff ou un licencié vérifié.
 *
 * [hvb_direct] : le navigateur relit toutes les 10 secondes la table publique « matchs » de l'appli (Supabase,
 * clé publique faite pour un navigateur) et affiche le score le jour du match, à partir de 30 minutes avant
 * le coup d'envoi : sets gagnés, détail des sets, set en cours, « En direct » puis « Terminé ».
 * [hvb_direct prochain="1"] : hors jour de match, affiche le prochain match (date, heure) au lieu de rien.
 * Aperçu d'un match passé : ajouter ?direct=2026-10-23 à l'adresse de la page.
 * Seules les colonnes publiques du match sont lues (jamais l'identité de celui qui tient le score).
 */

const HVB_SUPABASE_URL = 'https://xuqnajwjigknnrwtmwmw.supabase.co';
// Clé publique (rôle anon) de l'appli, la même que dans l'appli : lecture seule de ce qui est public.
const HVB_SUPABASE_CLE = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh1cW5handqaWdrbm5yd3Rtd213Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMwNDM3NDIsImV4cCI6MjEwODYxOTc0Mn0.2aoXG_ZH4Pr_ePQlNKJziJDy3cKhd72zUBDzAdRJn08';

/** Blason de chaque adversaire du calendrier, pour que le score en direct les affiche comme le reste du site. */
function hvb_direct_blasons() {
	$blasons = array( 'Harnes VB' => hvb_blason( 'Harnes VB' ) );
	foreach ( hvb_matchs() as $match ) {
		$adversaire = get_post_meta( $match->ID, 'adversaire', true );
		if ( $adversaire && ! isset( $blasons[ $adversaire ] ) ) {
			$blasons[ $adversaire ] = hvb_blason( $adversaire );
		}
	}
	return $blasons;
}

add_shortcode( 'hvb_direct', function ( $atts ) {
	$atts = shortcode_atts( array( 'prochain' => '0' ), $atts );
	$club = hvb_club();
	wp_enqueue_script( 'hvb-direct', HVB_URI . '/assets/js/direct.js', array(), filemtime( get_template_directory() . '/assets/js/direct.js' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
	$stores = array_filter( array( 'iPhone' => $club['appli_ios'], 'Android' => $club['appli_android'] ) );
	ob_start();
	?>
	<section class="direct" data-direct hidden
		data-url="<?php echo esc_attr( HVB_SUPABASE_URL ); ?>"
		data-cle="<?php echo esc_attr( HVB_SUPABASE_CLE ); ?>"
		data-prochain="<?php echo esc_attr( $atts['prochain'] ); ?>"
		data-blasons="<?php echo esc_attr( wp_json_encode( hvb_direct_blasons() ) ); ?>"
		aria-label="Score en direct">
		<div class="score-match direct__tableau" aria-live="polite">
			<p class="direct__etat"><span data-etat></span><span data-rencontre></span></p>
			<div class="score-match__equipes">
				<div class="score-match__equipe" data-equipe="0"></div>
				<div class="score-match__score" data-score></div>
				<div class="score-match__equipe" data-equipe="1"></div>
			</div>
			<ol class="score-match__sets" data-sets></ol>
			<p class="score-match__infos" data-infos></p>
			<div class="direct__appli">
				<img src="<?php echo esc_url( HVB_URI . '/assets/img/appli-icone.png' ); ?>" alt="" width="44" height="44">
				<p>Suivez le match et votez pour le MVP dans l'appli <strong>Harnes Volleyball</strong>
					<?php if ( $stores ) : ?>
						<span class="direct__stores">
							<?php foreach ( $stores as $systeme => $lien ) : ?>
								<a href="<?php echo esc_url( $lien ); ?>" target="_blank" rel="noopener">Télécharger sur <?php echo esc_html( $systeme ); ?></a>
							<?php endforeach; ?>
						</span>
					<?php else : ?>
						<span class="direct__stores"><a href="<?php echo esc_url( home_url( '/application/' ) ); ?>">Bientôt sur iPhone et Android</a></span>
					<?php endif; ?>
				</p>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
} );
