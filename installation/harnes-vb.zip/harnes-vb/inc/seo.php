<?php
/**
 * Référencement : titres et descriptions travaillés page par page, partage sur les réseaux
 * (Open Graph, X), données structurées (club, matchs, articles, fil d'Ariane), textes
 * alternatifs des images et en-tête allégé.
 *
 * Le site de test reste non indexé (réglage « blog_public » à 0, et la copie en ligne ajoute
 * son propre noindex) : passer « Visibilité pour les moteurs de recherche » à oui à la mise en ligne.
 */

/** Titres (balise <title>) par page : mots-clés recherchés + nom du club. */
const HVB_SEO_TITRES = array(
	'accueil'              => 'Harnes Volley-Ball (HVB) · Club de volley à Harnes, Volstar M2',
	'effectif'             => 'Effectif 2026-2027 de la Volstar M2 · Harnes Volley-Ball',
	'calendrier-resultats' => 'Calendrier et résultats Volstar M2 · Harnes Volley-Ball',
	'classement'           => 'Classement Volstar Masculine 2 · Harnes Volley-Ball',
	'billetterie'          => 'Billetterie : places pour les matchs à Harnes · HVB',
	'boutique'             => 'Boutique officielle : maillots et goodies du HVB',
	'devenir-partenaire'   => 'Devenir partenaire du Harnes Volley-Ball · Packs 2026-2027',
	'partenaires-prives'   => 'Partenaires privés et Business Club · Harnes Volley-Ball',
	'partenaires-publics'  => 'Partenaires institutionnels · Harnes Volley-Ball',
	'inscription'          => 'Inscription, licences et tarifs · Harnes Volley-Ball',
	'contact'              => 'Contact et accès salle Maréchal · Harnes Volley-Ball',
	'baby-volley'          => 'Baby volley à Harnes (2-6 ans) · Harnes Volley-Ball',
	'ecole-de-volley'      => 'École de volley à Harnes (7-11 ans) · Harnes Volley-Ball',
	'categorie-m13'        => 'Volley M13 (12-13 ans) à Harnes · Harnes Volley-Ball',
	'categorie-m15'        => 'Volley M15 (14-15 ans) à Harnes · Harnes Volley-Ball',
	'stages'               => 'Stages de volley à Harnes · Harnes Volley-Ball',
	'volley-loisir'        => 'Volley loisir adultes à Harnes · Harnes Volley-Ball',
	'volley-sante'         => 'Volley santé et Fit Volley à Harnes · Harnes Volley-Ball',
	'section-feminine'     => 'Section féminine de volley à Harnes · Harnes Volley-Ball',
	'nationale-2'          => 'Équipe de Nationale 2 · Harnes Volley-Ball',
	'pre-nationale'        => 'Équipe de Pré-nationale · Harnes Volley-Ball',
	'application'          => 'Application HVB Partenaires (iPhone et Android) · Harnes Volley-Ball',
	'histoire-du-club'     => 'Histoire du club depuis 1949 · Harnes Volley-Ball',
	'presentation-du-club' => 'Présentation du club · Harnes Volley-Ball',
	'infrastructures'      => 'Salle Régionale Maréchal et infrastructures · Harnes Volley-Ball',
);

/** Descriptions (≈ 150 caractères) affichées sous le titre dans Google. */
const HVB_SEO_DESCRIPTIONS = array(
	'accueil'              => 'Club de volley de Harnes (Pas-de-Calais) depuis 1949 : Volstar Masculine 2, formation des jeunes, loisir et volley santé. Matchs, billetterie, actus.',
	'effectif'             => "Découvrez les joueurs de la Volstar Masculine 2 du Harnes Volley-Ball pour la saison 2026-2027 : postes, numéros et photos du Media Day.",
	'calendrier-resultats' => 'Tous les matchs de la Volstar M2 du Harnes Volley-Ball : dates, horaires, matchs à domicile à la salle Maréchal et résultats de la saison.',
	'classement'           => 'Le classement à jour de la Volstar Masculine 2 et la place du Harnes Volley-Ball cette saison.',
	'billetterie'          => "Réservez vos places pour les matchs à domicile du Harnes Volley-Ball à la salle Maréchal, ou prenez l'abonnement pour toute la saison.",
	'boutique'             => 'Maillots officiels 2026-2027, écharpes, sweats et goodies du Harnes Volley-Ball, en vente au stand du club lors de chaque match à domicile.',
	'devenir-partenaire'   => 'Associez votre entreprise au Harnes Volley-Ball : 4 packs dès 3 000 €, 70 % mécénat, salon VIP, visibilité et réseau du Business Club.',
	'inscription'          => 'Licences volley à Harnes : tarifs par catégorie, du baby volley aux seniors, et documents à fournir pour s\'inscrire au Harnes Volley-Ball.',
	'contact'              => 'Contactez le Harnes Volley-Ball : salle Régionale Maréchal, 128 chemin Valois à Harnes, téléphone 03 21 18 65 02 et e-mail du club.',
	'baby-volley'          => 'Baby volley pour les 2-6 ans le samedi matin à Harnes : découverte ludique du volley, motricité et jeux avec les animatrices du HVB.',
	'ecole-de-volley'      => "École de volley du HVB pour les 7-11 ans (M7, M9, M11) : apprentissage des gestes, tournois et stages, le mercredi et le samedi à Harnes.",
	'volley-loisir'        => 'Volley loisir adultes à Harnes : jouer sans pression le lundi soir à la salle Maréchal, dans une ambiance conviviale. 90 € la saison.',
	'volley-sante'         => 'Fit Volley et volley santé à Harnes : reprise du sport en douceur, renforcement et plaisir du jeu, le mercredi et le samedi.',
	'section-feminine'     => "La section féminine du Harnes Volley-Ball : du volley loisir porté par d'anciennes joueuses de haut niveau, à la salle Maréchal.",
	'application'          => "HVB Partenaires, l'application iPhone et Android des partenaires du club : places VIP, billets invités, commande en tribune et réseau.",
	'histoire-du-club'     => "L'histoire du Harnes Volley-Ball depuis 1949 : titres, grandes dates et générations de joueurs qui ont fait le club.",
	'mentions-legales'     => "Mentions légales du site du Harnes Volley-Ball : éditeur, directeur de la publication, hébergement et propriété intellectuelle.",
	'politique-de-confidentialite' => "Politique de confidentialité du Harnes Volley-Ball : données du site et de la billetterie, cookies, durées de conservation et vos droits.",
	'conditions-generales-de-vente' => "Conditions générales de vente du Harnes Volley-Ball : billets, abonnements, tarifs réduits, accès à la salle, report et annulation des matchs.",
	'droit-de-retractation' => "Droit de rétractation au Harnes Volley-Ball : billets et abonnements de match, achats au stand et partenariats.",
);

/** Clé de la page courante dans les tableaux ci-dessus. */
function hvb_seo_cle() {
	if ( is_front_page() ) {
		return 'accueil';
	}
	return is_singular() ? get_post_field( 'post_name', get_queried_object_id() ) : '';
}

function hvb_seo_description() {
	$cle = hvb_seo_cle();
	if ( isset( HVB_SEO_DESCRIPTIONS[ $cle ] ) ) {
		return HVB_SEO_DESCRIPTIONS[ $cle ];
	}
	if ( is_singular() ) {
		$post  = get_queried_object();
		$texte = $post->post_excerpt ?: wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
		$texte = trim( preg_replace( '/\s+/', ' ', html_entity_decode( $texte, ENT_QUOTES, 'UTF-8' ) ) );
		if ( mb_strlen( $texte ) > 40 ) {
			return mb_strlen( $texte ) > 158 ? rtrim( mb_substr( $texte, 0, 155 ), ' ,;:.' ) . '…' : $texte;
		}
		return get_the_title( $post ) . ' : ' . HVB_SEO_DESCRIPTIONS['accueil'];
	}
	return HVB_SEO_DESCRIPTIONS['accueil'];
}

/** Image de partage : image à la une de la page, sinon la photo d'équipe. */
function hvb_seo_image() {
	if ( is_singular() && has_post_thumbnail() ) {
		$image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'hvb-wide' );
		if ( $image ) {
			return $image;
		}
	}
	$id = attachment_url_to_postid( hvb_photo( 'equipe-2026-2027' ) );
	return $id ? wp_get_attachment_image_src( $id, 'hvb-wide' ) : array( hvb_photo( 'equipe-2026-2027' ), 1600, 900 );
}

add_filter( 'pre_get_document_title', function ( $titre ) {
	$cle = hvb_seo_cle();
	return HVB_SEO_TITRES[ $cle ] ?? $titre;
} );
add_filter( 'document_title_separator', fn() => '·' );

/** Balises description, partage et couleur du navigateur. */
add_action( 'wp_head', function () {
	$titre       = wp_get_document_title();
	$description = hvb_seo_description();
	$url         = is_singular() || is_front_page() ? ( is_front_page() ? home_url( '/' ) : get_permalink() ) : home_url( add_query_arg( array() ) );
	list( $image, $largeur, $hauteur ) = hvb_seo_image();
	$balises = array(
		array( 'name', 'description', $description ),
		array( 'property', 'og:type', is_singular( 'post' ) ? 'article' : 'website' ),
		array( 'property', 'og:site_name', 'Harnes Volley-Ball' ),
		array( 'property', 'og:locale', 'fr_FR' ),
		array( 'property', 'og:title', $titre ),
		array( 'property', 'og:description', $description ),
		array( 'property', 'og:url', $url ),
		array( 'property', 'og:image', $image ),
		array( 'property', 'og:image:width', $largeur ),
		array( 'property', 'og:image:height', $hauteur ),
		array( 'name', 'twitter:card', 'summary_large_image' ),
		array( 'name', 'twitter:site', '@harnesvb' ),
		array( 'name', 'theme-color', '#0e0e0f' ),
	);
	if ( is_singular( 'post' ) ) {
		$balises[] = array( 'property', 'article:published_time', get_the_date( 'c' ) );
		$balises[] = array( 'property', 'article:modified_time', get_the_modified_date( 'c' ) );
	}
	foreach ( $balises as list( $attribut, $nom, $valeur ) ) {
		printf( '<meta %s="%s" content="%s">' . "\n", esc_attr( $attribut ), esc_attr( $nom ), esc_attr( $valeur ) );
	}
	printf( '<link rel="apple-touch-icon" href="%s">' . "\n", esc_url( HVB_URI . '/assets/img/logo-hvb.png' ) );
}, 1 );

/** Polices principales préchargées : le texte s'affiche plus vite, sans saut de police. */
add_action( 'wp_head', function () {
	foreach ( array( 'barlow-400-latin', 'barlow-condensed-800-italic-latin', 'barlow-condensed-700-latin' ) as $police ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( HVB_URI . "/assets/fonts/$police.woff2" ) );
	}
}, 2 );

/* ---------- Données structurées (schema.org) ---------- */

function hvb_seo_club() {
	$club = hvb_club();
	return array(
		'@type'         => 'SportsOrganization',
		'@id'           => home_url( '/#club' ),
		'name'          => 'Harnes Volley-Ball',
		'alternateName' => 'HVB',
		'url'           => home_url( '/' ),
		'logo'          => HVB_URI . '/assets/img/logo-hvb.png',
		'image'         => hvb_photo( 'equipe-2026-2027', 'hvb-wide' ),
		'sport'         => 'Volley-ball',
		'foundingDate'  => '1949',
		'slogan'        => 'Ensemble vers les sommets !',
		'telephone'     => '+33 3 21 18 65 02',
		'email'         => $club['email'],
		'address'       => hvb_seo_adresse(),
		'location'      => hvb_seo_salle(),
		'sameAs'        => array_values( array_map( fn( $r ) => $r[0], $club['reseaux'] ) ),
	);
}

function hvb_seo_adresse() {
	return array(
		'@type'           => 'PostalAddress',
		'streetAddress'   => '128 chemin Valois',
		'postalCode'      => '62440',
		'addressLocality' => 'Harnes',
		'addressRegion'   => 'Hauts-de-France',
		'addressCountry'  => 'FR',
	);
}

function hvb_seo_salle() {
	return array(
		'@type'   => 'SportsActivityLocation',
		'name'    => 'Salle Régionale Maréchal',
		'address' => hvb_seo_adresse(),
	);
}

/** Matchs à domicile à venir : peuvent apparaître comme événements dans Google. */
function hvb_seo_matchs( $nombre = 3 ) {
	$evenements = array();
	foreach ( hvb_matchs( 'ASC', $nombre, array(
		array( 'key' => 'domicile', 'value' => '1' ),
		array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
	) ) as $match ) {
		$adversaire = get_post_meta( $match->ID, 'adversaire', true );
		$debut      = get_post_meta( $match->ID, 'date', true ) . 'T' . ( get_post_meta( $match->ID, 'heure', true ) ?: '20:00' ) . ':00' . wp_date( 'P', strtotime( get_post_meta( $match->ID, 'date', true ) ) );
		$billets    = get_post_meta( $match->ID, 'billetterie', true );
		$evenement  = array(
			'@type'               => 'SportsEvent',
			'name'                => 'Harnes Volley-Ball – ' . $adversaire . ' (' . hvb_competition( $match->ID ) . ')',
			'sport'               => 'Volley-ball',
			'startDate'           => $debut,
			'eventStatus'         => 'https://schema.org/EventScheduled',
			'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode',
			'location'            => hvb_seo_salle() + array( '@type' => 'Place' ),
			'image'               => hvb_photo( 'equipe-2026-2027', 'hvb-wide' ),
			'description'         => 'Match de ' . hvb_competition( $match->ID ) . ' à la salle Régionale Maréchal de Harnes.',
			'homeTeam'            => array( '@type' => 'SportsTeam', 'name' => 'Harnes Volley-Ball' ),
			'awayTeam'            => array( '@type' => 'SportsTeam', 'name' => $adversaire ),
			'organizer'           => array( '@id' => home_url( '/#club' ) ),
		);
		if ( $billets ) {
			// Tarif normal ; les places gratuites (moins de 12 ans, licenciés) donnent la fourchette basse.
			// Mise en vente : date de publication du match sur le site.
			$evenement['offers'] = array(
				'@type'         => 'Offer',
				'url'           => $billets,
				'availability'  => 'https://schema.org/InStock',
				'price'         => hvb_club()['prix_billet'],
				'priceCurrency' => 'EUR',
				'validFrom'     => get_post_time( 'c', true, $match ),
				'priceSpecification' => array(
					'@type'         => 'PriceSpecification',
					'minPrice'      => '0',
					'maxPrice'      => hvb_club()['prix_billet'],
					'priceCurrency' => 'EUR',
				),
			);
		}
		$evenements[] = $evenement;
	}
	return $evenements;
}

function hvb_seo_ariane() {
	$elements = array( array( 'Accueil', home_url( '/' ) ) );
	$page     = get_queried_object();
	if ( is_singular( 'post' ) ) {
		$elements[] = array( 'Actualités', get_permalink( get_option( 'page_for_posts' ) ) );
	} elseif ( $page && $page->post_parent ) {
		$elements[] = array( get_the_title( $page->post_parent ), get_permalink( $page->post_parent ) );
	}
	$elements[] = array( wp_strip_all_tags( get_the_title( $page ) ), get_permalink( $page ) );
	return array(
		'@type'           => 'BreadcrumbList',
		'itemListElement' => array_map( fn( $i, $e ) => array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $e[0], 'item' => $e[1] ), array_keys( $elements ), $elements ),
	);
}

add_action( 'wp_head', function () {
	$graphe = array(
		hvb_seo_club(),
		array(
			'@type'      => 'WebSite',
			'@id'        => home_url( '/#site' ),
			'url'        => home_url( '/' ),
			'name'       => 'Harnes Volley-Ball',
			'inLanguage' => 'fr-FR',
			'publisher'  => array( '@id' => home_url( '/#club' ) ),
		),
	);
	if ( is_singular() && ! is_front_page() ) {
		$graphe[] = hvb_seo_ariane();
	}
	if ( is_singular( 'post' ) ) {
		list( $image ) = hvb_seo_image();
		$graphe[]      = array(
			'@type'            => 'NewsArticle',
			'headline'         => wp_strip_all_tags( get_the_title() ),
			'description'      => hvb_seo_description(),
			'image'            => array( $image ),
			'datePublished'    => get_the_date( 'c' ),
			'dateModified'     => get_the_modified_date( 'c' ),
			'author'           => array( '@id' => home_url( '/#club' ) ),
			'publisher'        => array( '@id' => home_url( '/#club' ) ),
			'mainEntityOfPage' => get_permalink(),
		);
	}
	if ( is_front_page() || is_page( array( 'billetterie', 'calendrier-resultats', 'boutique' ) ) ) {
		$graphe = array_merge( $graphe, hvb_seo_matchs() );
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graphe ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
}, 3 );

/* ---------- Images : jamais sans texte alternatif ---------- */

function hvb_seo_alt_par_defaut() {
	return wp_strip_all_tags( get_the_title() ) . ' – Harnes Volley-Ball';
}

add_filter( 'wp_get_attachment_image_attributes', function ( $attributs ) {
	if ( empty( $attributs['alt'] ) && in_the_loop() ) {
		$attributs['alt'] = hvb_seo_alt_par_defaut();
	}
	return $attributs;
} );

add_filter( 'the_content', function ( $html ) {
	$n = 0;
	return preg_replace_callback( '/<img\b([^>]*?)\salt=""/', function ( $m ) use ( &$n ) {
		$n++;
		return '<img' . $m[1] . ' alt="' . esc_attr( hvb_seo_alt_par_defaut() . ( $n > 1 ? " ($n)" : '' ) ) . '"';
	}, $html );
}, 20 );

/* ---------- En-tête allégé : rien d'inutile pour les moteurs ni pour la vitesse ---------- */

remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
remove_action( 'wp_head', 'rest_output_link_wp_head' );
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
add_filter( 'wp_sitemaps_add_provider', fn( $provider, $nom ) => 'users' === $nom ? false : $provider, 10, 2 );

/**
 * Fichier de validation Google Search Console (méthode « Fichier HTML ») servi par le thème,
 * le site n'ayant pas d'accès FTP. À garder : Google revérifie régulièrement la propriété.
 */
const HVB_GOOGLE_VALIDATION = 'googlea729bf8ee6d1472b';
add_action( 'init', function () {
	if ( '/' . HVB_GOOGLE_VALIDATION . '.html' === wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ) {
		header( 'Content-Type: text/html; charset=utf-8' );
		echo 'google-site-verification: ' . HVB_GOOGLE_VALIDATION . '.html';
		exit;
	}
}, 0 );
