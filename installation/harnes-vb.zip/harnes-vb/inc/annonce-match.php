<?php
/**
 * Mise en avant des matchs pro : tableau de score, prochains matchs, affiche du prochain match à domicile.
 *
 * - [hvb_score match="ID"] : tableau de score d'un match joué (comptes rendus).
 * - [hvb_prochains nombre="2"] : cartes des prochains matchs.
 * - [hvb_affiche match="ID"] : affiche d'un match à venir, avec compte à rebours et réservation.
 * - Fenêtre d'annonce du prochain match à domicile, une fois par visite (pas sur la page Billetterie).
 * - Article d'annonce publié automatiquement quand le prochain match à domicile est en vente, à 14 jours au plus.
 */

/** Prochain match à domicile pas encore joué. */
function hvb_prochain_match_domicile() {
	$a_venir = hvb_matchs( 'ASC', 1, array(
		array( 'key' => 'domicile', 'value' => '1' ),
		array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
		array( 'relation' => 'OR',
			array( 'key' => 'score_hvb', 'compare' => 'NOT EXISTS' ),
			array( 'key' => 'score_hvb', 'value' => '' ),
		),
	) );
	return $a_venir[0] ?? null;
}

/** « Coupe de France » ou « Volstar Masculine 2 · J3 ». */
function hvb_nom_rencontre( $id ) {
	$competition = get_post_meta( $id, 'competition', true );
	return $competition ?: 'Volstar Masculine 2 · J' . get_post_meta( $id, 'journee', true );
}

/** Date courte du match : « Mardi 3 novembre · 20h ». */
function hvb_date_courte( $id ) {
	$heure = get_post_meta( $id, 'heure', true );
	$texte = ucfirst( wp_date( 'l j F', strtotime( get_post_meta( $id, 'date', true ) . ' 12:00' ) ) );
	return $texte . ( $heure ? ' · ' . preg_replace( '#^(\d+):00$|^(\d+):(\d+)$#', '$1$2h$3', $heure ) : '' );
}

/** Points de chaque set dans l'ordre domicile / extérieur, depuis le champ « sets » (côté Harnes). */
function hvb_sets_match( $id ) {
	$sets = array();
	foreach ( array_filter( explode( ' ', get_post_meta( $id, 'sets', true ) ) ) as $set ) {
		$points = array_map( 'intval', explode( '-', $set ) );
		if ( 2 === count( $points ) ) {
			$sets[] = get_post_meta( $id, 'domicile', true ) ? $points : array_reverse( $points );
		}
	}
	return $sets;
}

add_shortcode( 'hvb_score', function ( $atts ) {
	$id = (int) shortcode_atts( array( 'match' => 0 ), $atts )['match'];
	if ( ! $id || 'hvb_match' !== get_post_type( $id ) ) {
		return '';
	}
	list( $dom, $ext ) = hvb_equipes( $id );
	$score             = hvb_score( $id );
	$sets_dom          = (int) get_post_meta( $id, get_post_meta( $id, 'domicile', true ) ? 'score_hvb' : 'score_adv', true );
	$sets_ext          = (int) get_post_meta( $id, get_post_meta( $id, 'domicile', true ) ? 'score_adv' : 'score_hvb', true );
	ob_start();
	?>
	<div class="score-match">
		<p class="score-match__etiquette"><?php echo esc_html( hvb_nom_rencontre( $id ) ); ?></p>
		<div class="score-match__equipes">
			<div class="score-match__equipe<?php echo $sets_dom > $sets_ext ? ' est-gagnant' : ''; ?>"><?php echo hvb_blason( $dom ); // phpcs:ignore ?><span><?php echo esc_html( $dom ); ?></span></div>
			<div class="score-match__score"><?php echo esc_html( $score ?: 'vs' ); ?></div>
			<div class="score-match__equipe<?php echo $sets_ext > $sets_dom ? ' est-gagnant' : ''; ?>"><?php echo hvb_blason( $ext ); // phpcs:ignore ?><span><?php echo esc_html( $ext ); ?></span></div>
		</div>
		<?php if ( hvb_sets_match( $id ) ) : ?>
			<ol class="score-match__sets">
				<?php foreach ( hvb_sets_match( $id ) as $i => list( $a, $b ) ) : ?>
					<li><span>Set <?php echo (int) $i + 1; ?></span><b class="<?php echo $a > $b ? 'est-gagne' : ''; ?>"><?php echo (int) $a; ?></b><i>-</i><b class="<?php echo $b > $a ? 'est-gagne' : ''; ?>"><?php echo (int) $b; ?></b></li>
				<?php endforeach; ?>
			</ol>
		<?php endif; ?>
		<p class="score-match__infos"><?php echo esc_html( hvb_date_match( $id ) ); ?> · <?php echo get_post_meta( $id, 'domicile', true ) ? 'Salle Régionale Maréchal' : 'Extérieur'; ?></p>
	</div>
	<?php
	return ob_get_clean();
} );

add_shortcode( 'hvb_prochains', function ( $atts ) {
	$nombre  = (int) shortcode_atts( array( 'nombre' => 2 ), $atts )['nombre'];
	$a_venir = hvb_matchs( 'ASC', $nombre, array(
		array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
		array( 'relation' => 'OR',
			array( 'key' => 'score_hvb', 'compare' => 'NOT EXISTS' ),
			array( 'key' => 'score_hvb', 'value' => '' ),
		),
	) );
	if ( ! $a_venir ) {
		return '';
	}
	ob_start();
	?>
	<div class="prochains-matchs">
		<?php foreach ( $a_venir as $match ) : ?>
			<?php
			list( $dom, $ext ) = hvb_equipes( $match->ID );
			$domicile          = get_post_meta( $match->ID, 'domicile', true );
			?>
			<div class="prochain-match<?php echo $domicile ? ' prochain-match--domicile' : ''; ?>">
				<p class="prochain-match__etiquette"><?php echo esc_html( hvb_nom_rencontre( $match->ID ) ); ?></p>
				<p class="prochain-match__equipes"><?php echo hvb_blason( $dom ); // phpcs:ignore ?><span><?php echo esc_html( $dom ); ?> – <?php echo esc_html( $ext ); ?></span><?php echo hvb_blason( $ext ); // phpcs:ignore ?></p>
				<p class="prochain-match__date"><?php echo esc_html( hvb_date_courte( $match->ID ) ); ?> · <?php echo $domicile ? 'Salle Maréchal' : 'Extérieur'; ?></p>
				<?php if ( $domicile && get_post_meta( $match->ID, 'billetterie', true ) ) : ?>
					<a class="bouton bouton--rouge bouton--petit" href="<?php echo esc_url( hvb_lien_billetterie( $match->ID ) ); ?>">Réserver ma place</a>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
	return ob_get_clean();
} );

/** Affiche d'un match à venir : visuel (s'il existe), équipes, date, compte à rebours et réservation. */
function hvb_affiche_match( $id, $titre_id = '' ) {
	list( $dom, $ext ) = hvb_equipes( $id );
	$affiche           = get_post_meta( $id, 'affiche', true );
	$lien              = get_post_meta( $id, 'billetterie', true );
	ob_start();
	?>
	<div class="affiche-match<?php echo $affiche ? ' affiche-match--visuel' : ''; ?>">
		<?php if ( $affiche ) : ?>
			<img class="affiche-match__visuel" src="<?php echo esc_url( $affiche ); ?>" alt="<?php echo esc_attr( "Affiche du match $dom – $ext" ); ?>">
		<?php endif; ?>
		<div class="affiche-match__infos">
			<p class="affiche-match__etiquette">Prochain match à domicile<span><?php echo esc_html( hvb_nom_rencontre( $id ) ); ?></span></p>
			<p class="affiche-match__equipes"<?php echo $titre_id ? ' id="' . esc_attr( $titre_id ) . '"' : ''; ?>>
				<span class="affiche-match__equipe"><?php echo hvb_blason( $dom ); // phpcs:ignore ?><b><?php echo esc_html( $dom ); ?></b></span>
				<span class="affiche-match__vs">vs</span>
				<span class="affiche-match__equipe"><?php echo hvb_blason( $ext ); // phpcs:ignore ?><b><?php echo esc_html( $ext ); ?></b></span>
			</p>
			<p class="affiche-match__date"><?php echo esc_html( hvb_date_courte( $id ) ); ?><span>Salle Régionale Maréchal · Harnes</span></p>
			<div class="compte affiche-match__compte" data-compte="<?php echo esc_attr( hvb_coup_envoi( $id ) ); ?>">
				<div><strong data-j>--</strong><span>jours</span></div>
				<div><strong data-h>--</strong><span>heures</span></div>
				<div><strong data-m>--</strong><span>min</span></div>
				<div><strong data-s>--</strong><span>sec</span></div>
			</div>
			<a class="bouton bouton--rouge bouton--large affiche-match__bouton" href="<?php echo esc_url( hvb_lien_billetterie( $id ) ); ?>"><?php echo hvb_icone( 'billet' ); // phpcs:ignore ?> <?php echo $lien ? 'Réserver ma place' : 'Billetterie & abonnements'; ?></a>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

add_shortcode( 'hvb_affiche', function ( $atts ) {
	$id = (int) shortcode_atts( array( 'match' => 0 ), $atts )['match'];
	return $id && 'hvb_match' === get_post_type( $id ) ? hvb_affiche_match( $id ) : '';
} );

// Fenêtre d'annonce du prochain match à domicile (affichée une fois par visite par le script du thème).
add_action( 'wp_footer', function () {
	if ( is_admin() || is_page_template( 'template-billetterie.php' ) ) {
		return;
	}
	$match = hvb_prochain_match_domicile();
	if ( ! $match ) {
		return;
	}
	?>
	<dialog class="annonce-match" data-annonce="<?php echo esc_attr( $match->ID . '-' . get_post_meta( $match->ID, 'date', true ) ); ?>" aria-labelledby="annonce-match-titre">
		<button type="button" class="annonce-match__fermer" aria-label="Fermer">×</button>
		<?php echo hvb_affiche_match( $match->ID, 'annonce-match-titre' ); // phpcs:ignore ?>
		<button type="button" class="annonce-match__plus-tard">Continuer sur le site</button>
	</dialog>
	<?php
}, 5 );

/** Article d'annonce du prochain match à domicile, publié une fois quand le match est en vente (14 jours avant au plus). */
function hvb_annonce_match_auto() {
	$match = hvb_prochain_match_domicile();
	if ( ! $match || get_post_meta( $match->ID, 'annonce', true ) || ! get_post_meta( $match->ID, 'billetterie', true )
		|| strtotime( get_post_meta( $match->ID, 'date', true ) ) - time() > 14 * DAY_IN_SECONDS ) {
		return 0;
	}
	$id          = $match->ID;
	$adversaire  = get_post_meta( $id, 'adversaire', true );
	$competition = get_post_meta( $id, 'competition', true );
	$jour        = wp_date( 'l j F', strtotime( get_post_meta( $id, 'date', true ) . ' 12:00' ) );
	$heure       = preg_replace( '#^(\d+):00$|^(\d+):(\d+)$#', '$1$2h$3', get_post_meta( $id, 'heure', true ) ?: '20:00' );
	$cadre       = $competition ? "en $competition" : 'pour la ' . hvb_rang( (int) get_post_meta( $id, 'journee', true ) ) . ' journée de Volstar Masculine 2';

	$titre = ucfirst( $jour ) . ", le HVB reçoit $adversaire" . ( $competition ? " en $competition" : '' );
	$intro = "Rendez-vous $jour à $heure à la salle Régionale Maréchal : le Harnes Volley-Ball reçoit $adversaire $cadre. Toute la salle compte sur vous pour pousser derrière l'équipe !";
	$prix  = number_format( (float) hvb_club()['prix_billet'], 0 );

	$blocs   = array();
	$blocs[] = "<!-- wp:paragraph -->\n<p><strong>" . esc_html( $intro ) . "</strong></p>\n<!-- /wp:paragraph -->";
	$blocs[] = "<!-- wp:shortcode -->\n[hvb_affiche match=\"$id\"]\n<!-- /wp:shortcode -->";
	$blocs[] = "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Infos pratiques</h2>\n<!-- /wp:heading -->";
	$blocs[] = "<!-- wp:list -->\n<ul class=\"wp-block-list\">"
		. '<li><strong>Quand :</strong> ' . esc_html( "$jour à $heure" ) . '</li>'
		. '<li><strong>Où :</strong> ' . esc_html( hvb_club()['salle'] . ', ' . hvb_club()['adresse'] ) . '</li>'
		. '<li><strong>Tarifs :</strong> ' . esc_html( "$prix €, étudiants 3 €, gratuit pour les moins de 12 ans" ) . '</li>'
		. "</ul>\n<!-- /wp:list -->";
	$blocs[] = "<!-- wp:paragraph -->\n<p><a href=\"" . esc_url( hvb_lien_billetterie( $id ) ) . "\">Réservez vos places sur la billetterie du club</a>, c'est rapide et vos billets arrivent par e-mail.</p>\n<!-- /wp:paragraph -->";

	$article = wp_insert_post( array(
		'post_type'     => 'post',
		'post_status'   => 'publish',
		'post_title'    => $titre,
		'post_content'  => implode( "\n\n", $blocs ),
		'post_excerpt'  => $intro,
		'post_category' => array_filter( array( hvb_categorie_pro() ) ),
		'post_author'   => hvb_auteur_articles(),
	) );
	if ( ! $article || is_wp_error( $article ) ) {
		return 0;
	}
	$visuel = attachment_url_to_postid( (string) get_post_meta( $id, 'banniere', true ) ) ?: hvb_photo_id( 'equipe-2026-2027' );
	if ( $visuel ) {
		set_post_thumbnail( $article, $visuel );
	}
	update_post_meta( $id, 'annonce', $article );
	do_action( 'wpfc_clear_all_cache' );
	return $article;
}

add_action( 'hvb_maj_classement', 'hvb_annonce_match_auto', 30 );
// Aussi dès qu'un match est enregistré (lien de billetterie ajouté, affiche…), sans attendre la tâche horaire.
add_action( 'save_post_hvb_match', function () {
	add_action( 'shutdown', 'hvb_annonce_match_auto' );
}, 20 );
