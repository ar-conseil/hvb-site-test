<?php
/**
 * Classements et résultats des équipes amateurs, repris automatiquement du site de résultats de la FFvolley
 * (ffvbbeach.org, une page par poule). Relus chaque lundi matin (les matchs amateurs et jeunes se jouent le week-end) ;
 * la dernière version valide est gardée si le site de la fédération ne répond pas.
 */

/**
 * Page du site => poule FFvolley de l'équipe (saison, entité organisatrice, code de poule, nom exact de l'équipe,
 * ou liste de noms quand plusieurs équipes du club jouent dans la même poule).
 * Jeunes et loisir : comité du Nord (PTFL59). Leurs codes de poule changent à chaque phase (phase 2 en janvier).
 */
const HVB_EQUIPES_FFVB = array(
	'nationale-2'      => array( 'saison' => '2026/2027', 'codent' => 'ABCCS', 'poule' => '2MD', 'equipe' => 'HARNES VOLLEY-BALL 2', 'competition' => 'Nationale 2 masculine · Poule D' ),
	'pre-nationale'    => array( 'saison' => '2026/2027', 'codent' => 'LIFL', 'poule' => 'PMA', 'equipe' => 'HARNES VB 3', 'competition' => 'Pré-nationale masculine · Poule A' ),
	'departementale-4' => array( 'saison' => '2026/2027', 'codent' => 'PTFL62', 'poule' => 'AMA', 'equipe' => 'HARNES VB 4', 'competition' => 'Accession régionale masculine · Poule A' ),
	'categorie-m15'    => array( 'saison' => '2026/2027', 'codent' => 'PTFL59', 'poule' => 'MMQ', 'equipe' => 'HARNES VB 1', 'competition' => 'M15 masculins · Excellence · Poule A' ),
	'categorie-m13'    => array( 'saison' => '2026/2027', 'codent' => 'PTFL59', 'poule' => 'BMO', 'equipe' => array( 'HARNES VB 1', 'HARNES VB 2' ), 'competition' => 'M13 masculins · Excellence · Poule B' ),
	'volley-loisir'    => array( 'saison' => '2026/2027', 'codent' => 'PTFL59', 'poule' => 'DLB', 'equipe' => 'HARNES VB 1', 'competition' => 'Détente loisir Nord · Excellence · Poule B' ),
);

/** Vrai si l'équipe fait partie de celles du club suivies sur cette page. */
function hvb_ffvb_est_hvb( $nom, $e ) {
	return in_array( $nom, (array) $e['equipe'], true );
}

/** Nom affiché : « Harnes » (ou « Harnes 1 », « Harnes 2 » quand le club a deux équipes dans la poule), sinon le nom adverse lisible. */
function hvb_ffvb_libelle( $nom, $e ) {
	if ( ! hvb_ffvb_est_hvb( $nom, $e ) ) {
		return hvb_ffvb_nom( $nom );
	}
	return count( (array) $e['equipe'] ) > 1 && preg_match( '/(\d+)$/', $nom, $n ) ? 'Harnes ' . $n[1] : 'Harnes';
}

/** Vrai si la salle est à Harnes (les plateaux jeunes se jouent souvent en salle neutre). */
function hvb_ffvb_salle_harnes( $salle ) {
	return (bool) preg_match( '/MAR[EÉ]CHAL|\(HARNES|BIGOTTE/iu', $salle );
}

function hvb_ffvb_url( $e ) {
	return 'https://www.ffvbbeach.org/ffvbapp/resu/vbspo_calendrier.php?' . http_build_query( array( 'saison' => $e['saison'], 'codent' => $e['codent'], 'poule' => $e['poule'], 'calend' => 'COMPLET' ) );
}

/** Nom d'équipe lisible : « VC MICHELET HALLUIN » → « VC Michelet Halluin ». */
function hvb_ffvb_nom( $nom ) {
	$nom = preg_replace( '/ 1$/', '', trim( $nom ) ); // « 1 » = équipe première, inutile à l'affichage
	$nom = mb_convert_case( mb_strtolower( $nom ), MB_CASE_TITLE );
	$nom = preg_replace( '/ (Lez|Les|Sur|En) /u', '-$1-', $nom ); // Lys-lez-Lannoy, Marquette-lez-Lille
	$nom = preg_replace_callback( '/-(Lez|Les|Sur|En)-/u', fn( $m ) => '-' . mb_strtolower( $m[1] ) . '-', $nom );
	return preg_replace_callback( '/\b(Vb|Vc|Vcm|Ac|As|Asl|Us|Uc|Ec|Cs|Sc|Sj|Lm|Lis|Gpso|Mcsv|Vbc|Hvb|Asv|Al|Cfc|Bouc)\b/u', fn( $m ) => mb_strtoupper( $m[1] ), $nom );
}

/** Salle lisible, avec les accents que la base fédérale omet souvent. */
function hvb_ffvb_salle( $salle ) {
	$salle = mb_convert_case( mb_strtolower( $salle ), MB_CASE_TITLE );
	$salle = preg_replace( '/\s*\([^)]*$/', '', $salle ); // parenthèse coupée par la base fédérale
	return strtr( $salle, array( 'Regionale' => 'Régionale', 'Marechal' => 'Maréchal', 'College' => 'Collège', 'Gymnase' => 'Gymnase' ) );
}

/** Lit la page de poule : classement et matchs de l'équipe du HVB. Renvoie null si la page est illisible. */
function hvb_ffvb_lire( $e ) {
	$reponse = wp_remote_get( hvb_ffvb_url( $e ), array( 'timeout' => 20, 'user-agent' => 'Mozilla/5.0 (site du Harnes Volley-Ball)' ) );
	if ( is_wp_error( $reponse ) || 200 !== wp_remote_retrieve_response_code( $reponse ) ) {
		return null;
	}
	$html = mb_convert_encoding( wp_remote_retrieve_body( $reponse ), 'UTF-8', 'Windows-1252' );
	preg_match_all( '#<tr[^>]*>(.*?)</tr>#si', $html, $lignes );
	$classement = array();
	$matchs     = array();
	foreach ( $lignes[1] as $ligne ) {
		preg_match_all( '#<td[^>]*>(.*?)</td>#si', $ligne, $c );
		$c = array_map( fn( $v ) => trim( html_entity_decode( wp_strip_all_tags( $v ), ENT_QUOTES, 'UTF-8' ) ), $c[1] );
		if ( count( $c ) >= 19 && preg_match( '/^\d+\.$/', $c[0] ) ) {
			$classement[] = array(
				'nom'    => $c[1],
				'points' => (int) $c[2],
				'joues'  => (int) $c[3],
				'gagnes' => (int) $c[4],
				'perdus' => (int) $c[5],
				'sets_g' => (int) $c[13],
				'sets_p' => (int) $c[14],
			);
		} elseif ( count( $c ) >= 8 && preg_match( '/^' . preg_quote( $e['poule'], '/' ) . '\d{3}$/', $c[0] ) && ( hvb_ffvb_est_hvb( $c[3], $e ) || hvb_ffvb_est_hvb( $c[5], $e ) ) && 'xxxxx' !== $c[3] && 'xxxxx' !== $c[5] ) {
			$date = DateTime::createFromFormat( 'd/m/y H:i', $c[1] . ' ' . ( $c[2] ?: '00:00' ) );
			if ( ! $date ) {
				continue;
			}
			$joue     = '' !== $c[6] && is_numeric( $c[6] );
			$matchs[] = array(
				'date'       => $date->format( 'Y-m-d H:i' ),
				'equipe_1'   => $c[3],
				'equipe_2'   => $c[5],
				'score'      => $joue ? array( (int) $c[6], (int) $c[7] ) : null,
				'sets'       => $joue ? $c[8] : '',
				'salle'      => $joue ? '' : ( $c[7] ?? '' ),
			);
		}
	}
	// Avant la première journée, la poule n'a pas encore de classement : le calendrier suffit.
	return ( count( $classement ) >= 4 || $matchs ) ? array( 'classement' => $classement, 'matchs' => $matchs, 'maj' => time() ) : null;
}

/** Relit les poules (toutes, ou seulement celle d'une page) et enregistre celles qui sont lisibles. */
function hvb_ffvb_mettre_a_jour( $seulement = null ) {
	$donnees = get_option( 'hvb_resultats_ffvb', array() );
	$ok      = 0;
	foreach ( HVB_EQUIPES_FFVB as $page => $e ) {
		if ( $seulement && $seulement !== $page ) {
			continue;
		}
		$lu = hvb_ffvb_lire( $e );
		if ( $lu ) {
			$donnees[ $page ] = $lu;
			$ok++;
		}
	}
	update_option( 'hvb_resultats_ffvb', $donnees, false );
	if ( ! $seulement ) {
		update_option( 'hvb_resultats_ffvb_relu', current_time( 'Y-m-d' ), false );
	}
	return $ok;
}

/** Tâche horaire : relit toutes les poules une fois le lundi à partir de 8 h. */
function hvb_ffvb_maj_auto() {
	$lundi = '1' === current_time( 'N' ) && (int) current_time( 'G' ) >= 8;
	return $lundi && get_option( 'hvb_resultats_ffvb_relu' ) !== current_time( 'Y-m-d' ) ? hvb_ffvb_mettre_a_jour() : 0;
}
add_action( 'hvb_maj_classement', 'hvb_ffvb_maj_auto' );

/** Données d'une page ; lues à la volée seulement la première fois (nouvelle équipe suivie). */
function hvb_ffvb_donnees( $page ) {
	$donnees = get_option( 'hvb_resultats_ffvb', array() );
	if ( isset( HVB_EQUIPES_FFVB[ $page ] ) && empty( $donnees[ $page ] ) ) {
		hvb_ffvb_mettre_a_jour( $page );
		$donnees = get_option( 'hvb_resultats_ffvb', array() );
	}
	return $donnees[ $page ] ?? null;
}

/** Section « Classement et résultats » d'une page d'équipe (vide si l'équipe n'est pas suivie). */
function hvb_bloc_resultats( $page ) {
	$e = HVB_EQUIPES_FFVB[ $page ] ?? null;
	$d = $e ? hvb_ffvb_donnees( $page ) : null;
	if ( ! $d ) {
		return '';
	}
	$joues    = array_values( array_filter( $d['matchs'], fn( $m ) => $m['score'] ) );
	$a_venir  = array_values( array_filter( $d['matchs'], fn( $m ) => ! $m['score'] && $m['date'] >= current_time( 'Y-m-d' ) ) );
	$derniers = array_slice( array_reverse( $joues ), 0, 3 );
	$prochain = array_slice( $a_venir, 0, 3 );
	ob_start();
	?>
	<section class="bloc bloc--resultats">
		<div class="bloc__inner">
			<header class="bloc__entete"><h2>Classement et résultats</h2></header>
			<p class="resultats__competition"><?php echo esc_html( $e['competition'] ); ?> · saison <?php echo esc_html( str_replace( '/', '-', $e['saison'] ) ); ?></p>
			<div class="resultats">
				<div class="resultats__classement">
					<?php if ( ! $d['classement'] ) : ?>
						<p class="resultats__vide resultats__vide--classement">Le classement s'affichera après la première journée.</p>
					<?php else : ?>
					<table class="cl cl--compact cl--ffvb">
						<thead><tr><th class="cl__rang">#</th><th class="cl__equipe">Équipe</th><th class="cl__points">Pts</th><th title="Matchs joués">J</th><th title="Gagnés">G</th><th title="Perdus">P</th></tr></thead>
						<tbody>
						<?php foreach ( $d['classement'] as $i => $eq ) : ?>
							<tr class="<?php echo hvb_ffvb_est_hvb( $eq['nom'], $e ) ? 'is-hvb' : ''; ?>">
								<td class="cl__rang"><span><?php echo (int) $i + 1; ?></span></td>
								<td class="cl__equipe"><span class="cl__nom"><?php echo esc_html( hvb_ffvb_libelle( $eq['nom'], $e ) ); ?></span></td>
								<td class="cl__points"><?php echo (int) $eq['points']; ?></td>
								<td><?php echo (int) $eq['joues']; ?></td>
								<td><?php echo (int) $eq['gagnes']; ?></td>
								<td><?php echo (int) $eq['perdus']; ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<?php endif; ?>
				</div>
				<div class="resultats__matchs">
					<h3>Derniers résultats</h3>
					<?php if ( ! $derniers ) : ?><p class="resultats__vide">Pas encore de match joué.</p><?php endif; ?>
					<?php foreach ( $derniers as $m ) : ?>
						<?php
						$gagne = hvb_ffvb_est_hvb( $m['equipe_1'], $e ) ? $m['score'][0] > $m['score'][1] : $m['score'][1] > $m['score'][0];
						?>
						<div class="resultat <?php echo $gagne ? 'resultat--gagne' : 'resultat--perdu'; ?>">
							<span class="resultat__date"><?php echo esc_html( wp_date( 'j M', strtotime( $m['date'] ) ) ); ?></span>
							<span class="resultat__affiche"><?php echo esc_html( hvb_ffvb_libelle( $m['equipe_1'], $e ) . ' – ' . hvb_ffvb_libelle( $m['equipe_2'], $e ) ); ?></span>
							<strong class="resultat__score"><?php echo (int) $m['score'][0] . '-' . (int) $m['score'][1]; ?></strong>
							<span class="resultat__sets"><?php echo esc_html( str_replace( ':', '-', $m['sets'] ) ); ?></span>
						</div>
					<?php endforeach; ?>
					<h3>Prochains matchs</h3>
					<?php if ( ! $prochain ) : ?><p class="resultats__vide">Calendrier à venir.</p><?php endif; ?>
					<?php foreach ( $prochain as $m ) : ?>
						<div class="resultat resultat--a-venir">
							<span class="resultat__date"><?php echo esc_html( wp_date( 'j M', strtotime( $m['date'] ) ) ); ?><?php echo '00:00' !== substr( $m['date'], 11 ) ? '<small>' . esc_html( str_replace( ':', 'h', substr( $m['date'], 11 ) ) ) . '</small>' : ''; ?></span>
							<?php $chez_nous = $m['salle'] ? hvb_ffvb_salle_harnes( $m['salle'] ) : hvb_ffvb_est_hvb( $m['equipe_1'], $e ); ?>
							<span class="resultat__affiche"><?php echo esc_html( hvb_ffvb_libelle( $m['equipe_1'], $e ) . ' – ' . hvb_ffvb_libelle( $m['equipe_2'], $e ) ); ?></span>
							<span class="resultat__lieu"><?php echo $chez_nous ? 'À Harnes' : 'À l\'extérieur'; ?><?php echo $m['salle'] ? esc_html( ' · ' . hvb_ffvb_salle( $m['salle'] ) ) : ''; ?></span>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<p class="resultats__source">Source : <a href="<?php echo esc_url( hvb_ffvb_url( $e ) ); ?>" target="_blank" rel="noopener">FFvolley</a> · mis à jour automatiquement le <?php echo esc_html( wp_date( 'j F Y à H\hi', $d['maj'] ) ); ?></p>
		</div>
	</section>
	<?php
	return ob_get_clean();
}
