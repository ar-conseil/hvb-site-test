<?php
/**
 * Redirections permanentes des adresses de l'ancien site (thème Elementor, 2019-2026) qui n'existent plus,
 * pour que les liens déjà partagés et le référencement Google mènent à la bonne page.
 * N'agit que sur les pages introuvables : une page existante n'est jamais redirigée.
 */

/** Ancienne adresse (premier segment ou chemin complet) => nouvelle page (slug, vide = accueil). */
const HVB_REDIRECTIONS = array(
	'volstar-masculine-2-saison-2026-2027' => 'effectif',
	'resultats-vm2'                        => 'calendrier-resultats',
	'classement-elite'                     => 'classement',
	'categorie-m13-2'                      => 'categorie-m13',
	'stage-volley-jeune'                   => 'stages',
	'privacy-policy'                       => 'politique-de-confidentialite',
	'cgv'                                  => 'conditions-generales-de-vente',
	'le-hvb-a-un-nouveau-manager-general'  => 'antonin-rouzier-nouveau-manager-general',
	'site-construction'                    => '',
	'events'                               => 'calendrier-resultats',
	'event'                                => 'stages',
	'team'                                 => 'effectif',
	'team_group'                           => 'staff-technique',
	'layouts'                              => '',
	'author'                               => 'actus',
	'tag'                                  => 'actus',
	'agenda'                               => 'calendrier-resultats',
	'contact-2'                            => 'contact',
	'accueil-harnes-volley-ball'           => '',
);

add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	$chemin = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	// Ancien plan du site (extension Yoast) : remplacé par celui de WordPress.
	if ( preg_match( '#^[a-z_-]*sitemap[a-z0-9_-]*\.xml$#', $chemin ) ) {
		wp_safe_redirect( home_url( '/wp-sitemap.xml' ), 301 );
		exit;
	}
	$premier = strtok( $chemin, '/' );
	if ( false === $premier ) {
		return;
	}
	// Pages « Elite M » des saisons passées : leur histoire est sur la page Histoire du club.
	if ( preg_match( '/^elite-m-\d{4}/', $premier ) ) {
		$cible = 'histoire-du-club';
	} elseif ( preg_match( '/^(19|20)\d{2}$/', $premier ) ) {
		// Anciens articles datés (/2021/07/titre/) non repris sur le nouveau site : vers les actualités.
		$cible = 'actus';
	} elseif ( array_key_exists( $premier, HVB_REDIRECTIONS ) ) {
		$cible = HVB_REDIRECTIONS[ $premier ];
	} else {
		return;
	}
	wp_safe_redirect( home_url( $cible ? "/$cible/" : '/' ), 301 );
	exit;
}, 1 ); // Avant redirect_canonical, qui « devine » sinon une page voisine (ex. /team/nom/ vers une photo).

// La page Billetterie du site (template-billetterie.php, gardé sur le disque) n'est plus utilisée : son adresse,
// avec ou sans ?match= (liens déjà partagés, articles d'annonce), mène à la billetterie Billetweb du club.
add_action( 'template_redirect', function () {
	if ( is_page( 'billetterie' ) ) {
		wp_redirect( hvb_club()['billetterie'], 302 ); // phpcs:ignore WordPress.Security.SafeRedirect -- adresse fixe du club.
		exit;
	}
}, 1 );

// Les entrées « Billetterie » des menus pointent directement vers Billetweb, sans passer par la redirection.
add_filter( 'nav_menu_link_attributes', function ( $attributs, $element ) {
	if ( 'page' === $element->object && 'billetterie' === get_post_field( 'post_name', $element->object_id ) ) {
		$attributs['href'] = hvb_club()['billetterie'];
	}
	return $attributs;
}, 10, 2 );
