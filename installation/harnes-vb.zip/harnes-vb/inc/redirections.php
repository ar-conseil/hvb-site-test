<?php
/**
 * Redirections permanentes des adresses de l'ancien site (thème Elementor, 2019-2026) qui n'existent plus,
 * pour que les liens déjà partagés et le référencement Google mènent à la bonne page.
 * N'agit que sur les pages introuvables : une page existante n'est jamais redirigée.
 */

/** Ancienne adresse (premier segment ou chemin complet) => nouvelle page (slug, vide = accueil). */
const HVB_REDIRECTIONS = array(
	'volstar-masculine-2-saison-2026-2027' => 'effectif',
	'resultats-vm2'                        => 'calendrier-resultats',
	'classement-elite'                     => 'classement',
	'categorie-m13-2'                      => 'categorie-m13',
	'stage-volley-jeune'                   => 'stages',
	'privacy-policy'                       => 'politique-de-confidentialite',
	'cgv'                                  => 'conditions-generales-de-vente',
	'le-hvb-a-un-nouveau-manager-general'  => 'antonin-rouzier-nouveau-manager-general',
	'site-construction'                    => '',
	'events'                               => 'calendrier-resultats',
	'event'                                => 'stages',
	'team'                                 => 'effectif',
	'team_group'                           => 'staff-technique',
	'layouts'                              => '',
	'author'                               => 'actus',
	'tag'                                  => 'actus',
);

add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	$chemin = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	// Ancien plan du site (extension Yoast) : remplacé par celui de WordPress.
	if ( preg_match( '#^[a-z_-]*sitemap[a-z0-9_-]*\.xml$#', $chemin ) ) {
		wp_safe_redirect( home_url( '/wp-sitemap.xml' ), 301 );
		exit;
	}
	$premier = strtok( $chemin, '/' );
	if ( false === $premier ) {
		return;
	}
	// Pages « Elite M » des saisons passées : leur histoire est sur la page Histoire du club.
	if ( preg_match( '/^elite-m-\d{4}/', $premier ) ) {
		$cible = 'histoire-du-club';
	} elseif ( array_key_exists( $premier, HVB_REDIRECTIONS ) ) {
		$cible = HVB_REDIRECTIONS[ $premier ];
	} else {
		return;
	}
	wp_safe_redirect( home_url( $cible ? "/$cible/" : '/' ), 301 );
	exit;
} );
