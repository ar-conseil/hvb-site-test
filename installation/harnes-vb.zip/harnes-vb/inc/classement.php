<?php
/**
 * Classement de la Volstar Masculine 2, repris automatiquement de la LNV.
 *
 * La LNV publie son classement via DataProject (page intégrée sur lnv.fr/competitions/volstar-masculine-2).
 * Le site le relit toutes les heures (tâche WordPress planifiée) et garde la dernière version valide :
 * il se met donc à jour seul après chaque journée, et reste affiché si la LNV est momentanément injoignable.
 * Les logos des clubs sont copiés une fois dans le site.
 */

const HVB_LNV_CLASSEMENT = 'https://lnv-web.dataproject.com/CompetitionStandings.aspx?ID=139';
const HVB_LNV_PAGE       = 'https://www.lnv.fr/competitions/volstar-masculine-2';
const HVB_ID_HARNES      = 720;

/** Noms courts affichés, par identifiant d'équipe DataProject (le reste : nom LNV mis en forme). */
const HVB_NOMS_EQUIPES = array(
	714 => "Saint-Jean-d'Illac",
	715 => 'Fréjus',
	716 => 'France Avenir 2024',
	717 => 'Cambrai',
	718 => 'Ajaccio',
	719 => 'Grand Nancy',
	720 => 'Harnes',
	721 => 'Martigues',
	722 => 'Reims',
	723 => 'Rennes',
	724 => 'Saint-Quentin',
	739 => 'Chalon-sur-Saône',
);

/** Lit le classement sur la page LNV / DataProject. Renvoie null si la page est illisible. */
function hvb_lnv_lire() {
	$reponse = wp_remote_get( HVB_LNV_CLASSEMENT, array( 'timeout' => 15, 'user-agent' => 'Mozilla/5.0 (site du Harnes Volley-Ball)' ) );
	if ( is_wp_error( $reponse ) || 200 !== wp_remote_retrieve_response_code( $reponse ) ) {
		return null;
	}
	$html = wp_remote_retrieve_body( $reponse );
	preg_match_all( '#<tr class="RG_Standing_Main_(?:Alt)?BackColor[^"]*" id="__\d+">(.*?)</tr>\s*(?=<tr class="RG_Standing_Main|</tbody>)#s', $html, $lignes );
	$equipes = array();
	foreach ( $lignes[1] as $ligne ) {
		preg_match_all( '#<span id="(\w+)"[^>]*>(.*?)</span>#s', $ligne, $champs );
		$d = array_combine( $champs[1], array_map( fn( $v ) => trim( html_entity_decode( wp_strip_all_tags( $v ), ENT_QUOTES, 'UTF-8' ) ), $champs[2] ) );
		if ( ! isset( $d['TeamName'], $d['Points'] ) || ! preg_match( '#TeamLogo_(\d+)\.jpg#', $ligne, $id ) ) {
			continue;
		}
		$id        = (int) $id[1];
		$equipes[] = array(
			'id'       => $id,
			'nom'      => HVB_NOMS_EQUIPES[ $id ] ?? ucwords( strtolower( $d['TeamName'] ) ),
			'nom_lnv'  => $d['TeamName'],
			'points'   => (int) $d['Points'],
			'joues'    => (int) $d['MatchesPlayed'],
			'gagnes'   => (int) $d['WonMatches'],
			'perdus'   => (int) $d['LostMatches'],
			'sets_g'   => (int) $d['SetsWon'],
			'sets_p'   => (int) $d['SetsLost'],
			'pts_g'    => (int) $d['PuntiFatti'],
			'pts_p'    => (int) $d['PuntiSubiti'],
			'penalite' => is_numeric( $d['Penalty'] ?? '' ) ? (int) $d['Penalty'] : 0,
		);
	}
	// Un classement complet compte au moins 8 équipes : sinon la page a changé, on garde l'ancien.
	return count( $equipes ) >= 8 ? $equipes : null;
}

/** Logos transparents (PNG) publiés sur la page de la compétition LNV, par nom d'équipe simplifié. */
function hvb_lnv_logos_png() {
	$reponse = wp_remote_get( HVB_LNV_PAGE, array( 'timeout' => 15, 'user-agent' => 'Mozilla/5.0 (site du Harnes Volley-Ball)' ) );
	if ( is_wp_error( $reponse ) ) {
		return array();
	}
	preg_match_all( '#href="d2m/equipes/([a-z0-9-]+?)-\d+">\s*<img src="([^"]+\.png)"#', wp_remote_retrieve_body( $reponse ), $m, PREG_SET_ORDER );
	return array_column( $m, 2, 1 );
}

/** Logo d'un club, copié dans le site au premier passage (PNG transparent de la LNV, sinon logo DataProject). */
function hvb_lnv_logo( $id, $nom = '', $pngs = null ) {
	$dossier = wp_upload_dir();
	foreach ( array( 'png', 'jpg' ) as $format ) {
		if ( file_exists( $dossier['basedir'] . "/hvb-logos/equipe-$id.$format" ) ) {
			return $dossier['baseurl'] . "/hvb-logos/equipe-$id.$format";
		}
	}
	if ( null === $pngs ) {
		return '';
	}
	$source = "https://images.dataproject.com/lnv/TeamLogo/200/200/TeamLogo_$id.jpg";
	$format = 'jpg';
	foreach ( $pngs as $slug => $png ) {
		if ( $nom && 0 === strpos( str_replace( '-', '', sanitize_title( $nom ) ), str_replace( '-', '', $slug ) ) ) {
			$source = $png;
			$format = 'png';
		}
	}
	$reponse = wp_remote_get( $source, array( 'timeout' => 10 ) );
	if ( is_wp_error( $reponse ) || 200 !== wp_remote_retrieve_response_code( $reponse ) ) {
		return '';
	}
	wp_mkdir_p( $dossier['basedir'] . '/hvb-logos' );
	$fichier = $dossier['basedir'] . "/hvb-logos/equipe-$id.$format";
	file_put_contents( $fichier, wp_remote_retrieve_body( $reponse ) );
	// Logo affiché en 40 px au plus : réduit à 160 px pour rester léger (la LNV fournit des fichiers de plusieurs centaines de Ko).
	$editeur = wp_get_image_editor( $fichier );
	if ( ! is_wp_error( $editeur ) ) {
		$editeur->resize( 160, 160 );
		$editeur->save( $fichier );
	}
	return $dossier['baseurl'] . "/hvb-logos/equipe-$id.$format";
}

/** Relit la LNV et enregistre le classement s'il est valide. */
function hvb_lnv_mettre_a_jour() {
	$equipes = hvb_lnv_lire();
	if ( ! $equipes ) {
		return false;
	}
	$pngs = null;
	foreach ( $equipes as $equipe ) {
		if ( ! hvb_lnv_logo( $equipe['id'] ) ) {
			$pngs = $pngs ?? hvb_lnv_logos_png();
			hvb_lnv_logo( $equipe['id'], $equipe['nom'], $pngs );
		}
	}
	update_option( 'hvb_classement_lnv', array( 'equipes' => $equipes, 'maj' => time() ), false );
	return true;
}

/** Classement enregistré ; lu à la volée seulement s'il n'existe pas encore. */
function hvb_classement_lnv() {
	$classement = get_option( 'hvb_classement_lnv' );
	if ( ! $classement ) {
		hvb_lnv_mettre_a_jour();
		$classement = get_option( 'hvb_classement_lnv' );
	}
	return $classement ?: array( 'equipes' => array(), 'maj' => 0 );
}

/**
 * Faut-il relire la LNV maintenant ? Oui le soir d'un match de l'équipe pro, de la fin probable du match
 * (coup d'envoi + 2 h) jusqu'à minuit, pour attraper le score dès qu'il est saisi.
 * Oui aussi une fois le lundi, pour rattraper les matchs des autres équipes joués après celui de Harnes.
 */
function hvb_lnv_a_relire() {
	$maj        = (int) ( get_option( 'hvb_classement_lnv' )['maj'] ?? 0 );
	$aujourdhui = current_time( 'Y-m-d' );
	if ( '1' === current_time( 'N' ) && (int) current_time( 'G' ) >= 8 && wp_date( 'Y-m-d', $maj ) !== $aujourdhui ) {
		return true;
	}
	$matchs = get_posts( array( 'post_type' => 'hvb_match', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => 'date', 'meta_value' => $aujourdhui ) );
	foreach ( $matchs as $id ) {
		$coup_envoi = new DateTime( $aujourdhui . ' ' . ( get_post_meta( $id, 'heure', true ) ?: '20:00' ), wp_timezone() );
		if ( time() >= $coup_envoi->getTimestamp() + 2 * HOUR_IN_SECONDS ) {
			return true;
		}
	}
	return false;
}

/** Tâche horaire : ne relit la LNV qu'aux moments utiles (voir hvb_lnv_a_relire). */
function hvb_lnv_maj_auto() {
	return hvb_lnv_a_relire() ? hvb_lnv_mettre_a_jour() : false;
}

// Vérification toutes les heures ; les sources ne sont relues qu'au bon moment (pros : soir de match, amateurs : lundi).
add_action( 'hvb_maj_classement', 'hvb_lnv_maj_auto' );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'hvb_maj_classement' ) ) {
		wp_schedule_event( time() + 60, 'hourly', 'hvb_maj_classement' );
	}
} );

/** Ligne de classement : rang, logo, nom, puis les chiffres. */
function hvb_ligne_classement( $rang, $equipe, $complet = true ) {
	$hvb  = HVB_ID_HARNES === $equipe['id'];
	$logo  = hvb_lnv_logo( $equipe['id'] );
	$sets = $equipe['sets_g'] . '-' . $equipe['sets_p'];
	ob_start();
	?>
	<tr class="<?php echo $hvb ? 'is-hvb' : ''; ?>">
		<td class="cl__rang"><span><?php echo (int) $rang; ?></span></td>
		<td class="cl__equipe"><div class="cl__club">
			<?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( 'Logo ' . $equipe['nom'] ); ?>" width="40" height="40" loading="lazy"><?php endif; ?>
			<span class="cl__nom"><?php echo esc_html( $equipe['nom'] ); ?></span>
			<?php if ( $equipe['penalite'] ) : ?><span class="cl__penalite" title="Pénalité de points appliquée par la LNV"><?php echo (int) $equipe['penalite']; ?> pts</span><?php endif; ?>
		</div></td>
		<td class="cl__points"><?php echo (int) $equipe['points']; ?></td>
		<td><?php echo (int) $equipe['joues']; ?></td>
		<td><?php echo (int) $equipe['gagnes']; ?></td>
		<td><?php echo (int) $equipe['perdus']; ?></td>
		<?php if ( $complet ) : ?>
			<td class="cl__secondaire"><?php echo esc_html( $sets ); ?></td>
			<td class="cl__secondaire"><?php echo esc_html( sprintf( '%+d', $equipe['pts_g'] - $equipe['pts_p'] ) ); ?></td>
		<?php endif; ?>
	</tr>
	<?php
	return ob_get_clean();
}

/** Tableau de classement (complet sur la page Classement, compact sur l'accueil). */
function hvb_tableau_classement( $complet = true ) {
	$classement = hvb_classement_lnv();
	if ( ! $classement['equipes'] ) {
		return '<p class="cl__vide">Classement momentanément indisponible. <a href="' . esc_url( HVB_LNV_PAGE ) . '" target="_blank" rel="noopener">Voir sur le site de la LNV</a>.</p>';
	}
	$html = '<table class="cl' . ( $complet ? ' cl--complet' : ' cl--compact' ) . '"><thead><tr>'
		. '<th class="cl__rang">#</th><th class="cl__equipe">Équipe</th><th class="cl__points">Pts</th>'
		. '<th title="Matchs joués">J</th><th title="Gagnés">G</th><th title="Perdus">P</th>'
		. ( $complet ? '<th class="cl__secondaire" title="Sets gagnés-perdus">Sets</th><th class="cl__secondaire" title="Différence de points">Diff.</th>' : '' )
		. '</tr></thead><tbody>';
	foreach ( $classement['equipes'] as $i => $equipe ) {
		$html .= hvb_ligne_classement( $i + 1, $equipe, $complet );
	}
	return $html . '</tbody></table>';
}

/** Date de la dernière mise à jour, pour l'afficher sous le classement. */
function hvb_classement_maj() {
	$maj = hvb_classement_lnv()['maj'];
	return $maj ? wp_date( 'j F Y à H\hi', $maj ) : '';
}

/** Place et chiffres du HVB, pour la carte mise en avant. */
function hvb_classement_hvb() {
	foreach ( hvb_classement_lnv()['equipes'] as $i => $equipe ) {
		if ( HVB_ID_HARNES === $equipe['id'] ) {
			return $equipe + array( 'rang' => $i + 1 );
		}
	}
	return null;
}
