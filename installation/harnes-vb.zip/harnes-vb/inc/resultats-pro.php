<?php
/**
 * Résultats de l'équipe pro, repris automatiquement de la LNV le soir du match.
 *
 * Toutes les heures (tâche hvb_maj_classement), le site regarde s'il reste un match pro des trois derniers jours
 * sans score, dont le coup d'envoi date de plus de 2 h. Si oui, il relit la page des matchs DataProject de la
 * compétition : dès que la LNV a saisi le résultat, le score est inscrit dans le match (calendrier, accueil)
 * et un article est publié dans les actus. Rien n'est relu quand aucun match n'attend de score.
 */

/** Page des matchs DataProject selon le champ « Compétition » du match (vide = championnat). */
const HVB_LNV_MATCHS = array(
	''                => 139,
	'Coupe de France' => 141,
);

/** Matchs de Harnes d'une compétition DataProject, indexés par date (Y-m-d). */
function hvb_lnv_matchs_harnes( $competition ) {
	$reponse = wp_remote_get( "https://lnv-web.dataproject.com/CompetitionMatches.aspx?ID=$competition", array( 'timeout' => 20, 'user-agent' => 'Mozilla/5.0 (site du Harnes Volley-Ball)' ) );
	if ( is_wp_error( $reponse ) || 200 !== wp_remote_retrieve_response_code( $reponse ) ) {
		return array();
	}
	$blocs = preg_split( '#(?=<input type="hidden" name="[^"]*RADLIST_Matches\$ctrl\d+\$HF_WonSetHome")#', wp_remote_retrieve_body( $reponse ) );
	array_shift( $blocs );
	$matchs = array();
	foreach ( $blocs as $bloc ) {
		$texte  = fn( $cle ) => preg_match( '#_' . $cle . '"[^>]*>([^<]*)<#', $bloc, $m ) ? trim( html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' ) ) : '';
		$valeur = fn( $cle ) => preg_match( '#_' . $cle . '" value="([^"]*)"#', $bloc, $m ) ? $m[1] : '';
		// Deux mises en page selon les journées : noms dans LBL_HomeTeamName / LBL_GuestTeamName, ou dans Label2 / Label4.
		$dom = $texte( 'LBL_HomeTeamName' ) ?: $texte( 'Label2' );
		$ext = $texte( 'LBL_GuestTeamName' ) ?: $texte( 'Label4' );
		if ( false === stripos( $dom . $ext, 'harnes' ) || ! preg_match( '#^(\d\d)/(\d\d)/(\d{4})#', $valeur( 'HF_MatchDatetime' ), $date ) ) {
			continue;
		}
		$matchs[ "$date[3]-$date[2]-$date[1]" ] = array(
			'mid'      => preg_match( '#mID=(\d+)#', $bloc, $m ) ? (int) $m[1] : 0,
			'domicile' => false !== stripos( $dom, 'harnes' ),
			'sets'     => array( (int) $valeur( 'HF_WonSetHome' ), (int) $valeur( 'HF_WonSetGuest' ) ),
		);
	}
	return $matchs;
}

/** Points de chaque set (équipe à domicile, équipe à l'extérieur), lus sur la feuille de statistiques du match. */
function hvb_lnv_sets( $mid, $competition ) {
	$reponse = wp_remote_get( "https://lnv-web.dataproject.com/MatchStatistics.aspx?mID=$mid&ID=$competition", array( 'timeout' => 20, 'user-agent' => 'Mozilla/5.0 (site du Harnes Volley-Ball)' ) );
	if ( is_wp_error( $reponse ) || ! preg_match( '#_SetsPartials"[^>]*>([^<]*)<#', wp_remote_retrieve_body( $reponse ), $m ) ) {
		return array();
	}
	preg_match_all( '#(\d+)/(\d+)#', $m[1], $sets, PREG_SET_ORDER );
	return array_map( fn( $s ) => array( (int) $s[1], (int) $s[2] ), $sets );
}

/** Matchs pro des trois derniers jours encore sans score, coup d'envoi passé de 2 h. */
function hvb_resultats_pro_attendus() {
	$attendus = array();
	foreach ( hvb_matchs( 'ASC', -1, array(
		array( 'key' => 'date', 'value' => array( wp_date( 'Y-m-d', time() - 3 * DAY_IN_SECONDS ), current_time( 'Y-m-d' ) ), 'compare' => 'BETWEEN' ),
	) ) as $match ) {
		$coup_envoi = new DateTime( get_post_meta( $match->ID, 'date', true ) . ' ' . ( get_post_meta( $match->ID, 'heure', true ) ?: '20:00' ), wp_timezone() );
		if ( '' === get_post_meta( $match->ID, 'score_hvb', true ) && time() >= $coup_envoi->getTimestamp() + 2 * HOUR_IN_SECONDS ) {
			$attendus[] = $match->ID;
		}
	}
	return $attendus;
}

/** Inscrit les scores saisis par la LNV et publie les articles. Renvoie le nombre de matchs mis à jour. */
function hvb_resultats_pro_maj() {
	$lnv   = array();
	$joues = array();
	foreach ( hvb_resultats_pro_attendus() as $id ) {
		$competition = get_post_meta( $id, 'competition', true );
		if ( ! isset( HVB_LNV_MATCHS[ $competition ] ) ) {
			continue;
		}
		$lnv[ $competition ] = $lnv[ $competition ] ?? hvb_lnv_matchs_harnes( HVB_LNV_MATCHS[ $competition ] );
		$match               = $lnv[ $competition ][ get_post_meta( $id, 'date', true ) ] ?? null;
		if ( ! $match || 3 !== max( $match['sets'] ) ) {
			continue; // Résultat pas encore saisi par la LNV.
		}
		$sets = hvb_lnv_sets( $match['mid'], HVB_LNV_MATCHS[ $competition ] );
		if ( $match['domicile'] ) {
			list( $hvb, $adv ) = $match['sets'];
		} else {
			list( $adv, $hvb ) = $match['sets'];
			$sets              = array_map( 'array_reverse', $sets );
		}
		// Forfait : la LNV enregistre des sets à 25-0.
		if ( $sets && ! array_filter( $sets, fn( $s ) => min( $s ) > 0 ) ) {
			update_post_meta( $id, 'score_hvb', 'FP' );
			update_post_meta( $id, 'score_adv', 'FP' );
			continue;
		}
		update_post_meta( $id, 'score_hvb', (string) $hvb );
		update_post_meta( $id, 'score_adv', (string) $adv );
		update_post_meta( $id, 'sets', implode( ' ', array_map( fn( $s ) => implode( '-', $s ), $sets ) ) );
		$joues[] = $id;
	}
	if ( ! $joues ) {
		return 0;
	}
	hvb_lnv_mettre_a_jour(); // Classement à jour pour l'article.
	foreach ( $joues as $id ) {
		hvb_article_match( $id );
	}
	do_action( 'wpfc_clear_all_cache' ); // WP Fastest Cache : calendrier et accueil à jour tout de suite.
	return count( $joues );
}

add_action( 'hvb_maj_classement', function () {
	if ( hvb_resultats_pro_attendus() ) {
		hvb_resultats_pro_maj();
	}
}, 20 );

/** Rang en toutes lettres courtes : 1er, 2e… */
function hvb_rang( $rang ) {
	return 1 === $rang ? '1er' : $rang . 'e';
}

/** Phrase qui résume le match selon le score (et le set le plus serré pour une défaite nette). */
function hvb_resume_match( $hvb, $adv, $sets, $coupe ) {
	if ( $hvb > $adv ) {
		if ( 3 === $hvb && 0 === $adv ) {
			return 'Une victoire nette, sans concéder le moindre set.';
		}
		if ( 2 === $adv ) {
			return $coupe ? 'Une victoire arrachée au tie-break.' : 'Une victoire arrachée au tie-break, qui rapporte 2 points au classement.';
		}
		return $coupe ? 'Le HVB n\'a laissé filer qu\'un set.' : 'Le HVB n\'a laissé filer qu\'un set et empoche les 3 points.';
	}
	if ( 2 === $hvb ) {
		return $coupe ? 'Une défaite au tie-break, au terme d\'un match très disputé.' : 'Une défaite au tie-break, qui rapporte tout de même un point au classement.';
	}
	$ecarts = array_map( fn( $s ) => $s[1] - $s[0], array_filter( $sets, fn( $s ) => $s[1] > $s[0] ) );
	$texte  = 1 === $hvb ? 'Le HVB a remporté un set mais n\'a pas pu inverser la tendance.' : 'Le HVB n\'a pas réussi à prendre de set à son adversaire.';
	if ( $ecarts && min( $ecarts ) <= 3 ) {
		$numero = array_search( min( $ecarts ), $ecarts, true ) + 1;
		$texte .= ' Le ' . ( 1 === $numero ? '1er' : $numero . 'e' ) . ' set s\'est pourtant joué à ' . min( $ecarts ) . ' point' . ( min( $ecarts ) > 1 ? 's' : '' ) . '.';
	}
	return $texte;
}

/** Article de compte rendu d'un match pro, publié une seule fois par match. */
function hvb_article_match( $id ) {
	if ( get_post_meta( $id, 'article', true ) ) {
		return 0;
	}
	$hvb         = (int) get_post_meta( $id, 'score_hvb', true );
	$adv         = (int) get_post_meta( $id, 'score_adv', true );
	$adversaire  = get_post_meta( $id, 'adversaire', true );
	$domicile    = get_post_meta( $id, 'domicile', true );
	$competition = get_post_meta( $id, 'competition', true );
	$victoire    = $hvb > $adv;
	$sets        = array_map( fn( $s ) => array_map( 'intval', explode( '-', $s ) ), array_filter( explode( ' ', get_post_meta( $id, 'sets', true ) ) ) );
	$jour        = wp_date( 'l j F', strtotime( get_post_meta( $id, 'date', true ) . ' 12:00' ) );

	$titre = ( $competition ? $competition . ' : ' . ( $victoire ? 'victoire' : 'défaite' ) : ( $victoire ? 'Victoire' : 'Défaite' ) )
		. " $hvb-$adv face à $adversaire";

	$cadre = $competition
		? 'en ' . $competition
		: 'pour la ' . hvb_rang( (int) get_post_meta( $id, 'journee', true ) ) . ' journée de Volstar Masculine 2';
	$lieu  = $domicile ? 'à la salle Régionale Maréchal' : 'à l\'extérieur';
	$intro = 'Le Harnes Volley-Ball ' . ( $victoire ? 's\'est imposé' : 's\'est incliné' ) . " $hvb sets à $adv face à $adversaire, ce $jour $lieu, $cadre.";

	$paragraphes = array( '<strong>' . esc_html( $intro ) . '</strong>' );
	$paragraphes[] = esc_html( hvb_resume_match( $hvb, $adv, $sets, (bool) $competition ) );
	if ( $sets ) {
		$paragraphes[] = 'Détail des sets : ' . esc_html( implode( ', ', array_map( fn( $s ) => implode( '-', $s ), $sets ) ) ) . '.';
	}
	$place = $competition ? null : hvb_classement_hvb();
	if ( $place ) {
		$paragraphes[] = sprintf( 'Au classement, Harnes est %s avec %d point%s après %d match%s.', hvb_rang( $place['rang'] ), $place['points'], abs( $place['points'] ) > 1 ? 's' : '', $place['joues'], $place['joues'] > 1 ? 's' : '' );
	}
	$suivant = hvb_prochain_match();
	if ( $suivant ) {
		$heure = get_post_meta( $suivant->ID, 'heure', true );
		$texte = 'Prochain rendez-vous : ' . wp_date( 'l j F', strtotime( get_post_meta( $suivant->ID, 'date', true ) . ' 12:00' ) )
			. ( $heure ? ' à ' . preg_replace( '#^(\d+):00$|^(\d+):(\d+)$#', '$1$2h$3', $heure ) : '' ) . ', '
			. ( get_post_meta( $suivant->ID, 'domicile', true ) ? 'à la salle Maréchal face à ' : 'à l\'extérieur face à ' )
			. get_post_meta( $suivant->ID, 'adversaire', true )
			. ( get_post_meta( $suivant->ID, 'competition', true ) ? ' (' . get_post_meta( $suivant->ID, 'competition', true ) . ')' : '' ) . '.';
		$paragraphes[] = esc_html( $texte ) . ( get_post_meta( $suivant->ID, 'domicile', true )
			? ' <a href="' . esc_url( hvb_lien_billetterie( $suivant->ID ) ) . '">Réservez vos places</a>.'
			: '' );
	}
	$paragraphes[] = '<a href="' . esc_url( home_url( '/calendrier-resultats/' ) ) . '">Tous les résultats et le calendrier</a>';

	$contenu = implode( "\n\n", array_map( fn( $p ) => "<!-- wp:paragraph -->\n<p>$p</p>\n<!-- /wp:paragraph -->", $paragraphes ) );

	$categorie = get_term_by( 'slug', 'volstar-masculine-2', 'category' );
	$categorie = $categorie ? $categorie->term_id : ( wp_insert_term( 'Volstar Masculine 2', 'category', array( 'slug' => 'volstar-masculine-2' ) )['term_id'] ?? 0 );
	$auteurs   = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );

	$article = wp_insert_post( array(
		'post_type'     => 'post',
		'post_status'   => 'publish',
		'post_title'    => $titre,
		'post_content'  => $contenu,
		'post_excerpt'  => $intro,
		'post_category' => $categorie ? array( $categorie ) : array(),
		'post_author'   => $auteurs[0] ?? 1,
	) );
	if ( ! $article || is_wp_error( $article ) ) {
		return 0;
	}
	if ( hvb_photo_id( 'equipe-2026-2027' ) ) {
		set_post_thumbnail( $article, hvb_photo_id( 'equipe-2026-2027' ) );
	}
	update_post_meta( $id, 'article', $article );
	update_post_meta( $article, 'hvb_match', $id );
	return $article;
}
