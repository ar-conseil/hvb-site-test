<?php
/**
 * Contenus propres au club : joueurs de l'équipe première et matchs.
 * Chaque type a une boîte « Infos » dans l'éditeur pour saisir ses champs.
 */

const HVB_POSTES = array( 'Passeur', 'Central', 'Pointu', 'Réceptionneur-attaquant', 'Libéro' );

const HVB_CHAMPS = array(
	'hvb_joueur' => array(
		'numero' => array( 'Numéro', 'number' ),
		'poste'  => array( 'Poste', 'poste' ),
	),
	'hvb_match'  => array(
		'date'        => array( 'Date', 'date' ),
		'heure'       => array( 'Heure (ex. 20:00, vide si inconnue)', 'text' ),
		'journee'     => array( 'Journée', 'number' ),
		'competition' => array( 'Compétition (vide pour le championnat, ex. Coupe de France)', 'text' ),
		'adversaire'  => array( 'Adversaire', 'text' ),
		'domicile'    => array( 'Match à domicile', 'checkbox' ),
		'score_hvb'   => array( 'Sets Harnes (vide si pas joué)', 'text' ),
		'score_adv'   => array( 'Sets adversaire', 'text' ),
		'billetterie' => array( 'Lien billetterie', 'url' ),
		'sets'        => array( 'Détail des sets côté Harnes (ex. 25-20 23-25 25-18 ; rempli automatiquement)', 'text' ),
		'affiche'     => array( 'Affiche du match (adresse de l\'image verticale, optionnelle)', 'url' ),
		'banniere'    => array( 'Bannière du match (adresse de l\'image large, optionnelle)', 'url' ),
	),
);

add_action( 'init', function () {
	register_post_type( 'hvb_joueur', array(
		'labels'       => array(
			'name'          => 'Effectif pro',
			'singular_name' => 'Joueur',
			'add_new_item'  => 'Ajouter un joueur',
			'edit_item'     => 'Modifier le joueur',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-groups',
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
	) );

	register_post_type( 'hvb_match', array(
		'labels'       => array(
			'name'          => 'Matchs',
			'singular_name' => 'Match',
			'add_new_item'  => 'Ajouter un match',
			'edit_item'     => 'Modifier le match',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-calendar-alt',
		'supports'     => array( 'title' ),
	) );

	foreach ( HVB_CHAMPS as $type => $champs ) {
		foreach ( array_keys( $champs ) as $cle ) {
			register_post_meta( $type, $cle, array( 'single' => true, 'type' => 'string', 'show_in_rest' => true ) );
		}
	}
} );

add_action( 'add_meta_boxes', function () {
	foreach ( array_keys( HVB_CHAMPS ) as $type ) {
		add_meta_box( 'hvb_infos', 'Infos', 'hvb_boite_infos', $type, 'normal', 'high' );
	}
} );

function hvb_boite_infos( $post ) {
	wp_nonce_field( 'hvb_infos', 'hvb_infos_nonce' );
	echo '<table class="form-table">';
	foreach ( HVB_CHAMPS[ $post->post_type ] as $cle => list( $label, $type ) ) {
		$valeur = get_post_meta( $post->ID, $cle, true );
		echo '<tr><th><label for="hvb_' . esc_attr( $cle ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'checkbox' === $type ) {
			printf( '<input type="checkbox" id="hvb_%1$s" name="hvb[%1$s]" value="1" %2$s>', esc_attr( $cle ), checked( $valeur, '1', false ) );
		} elseif ( 'poste' === $type ) {
			printf( '<select id="hvb_%1$s" name="hvb[%1$s]">', esc_attr( $cle ) );
			foreach ( HVB_POSTES as $poste ) {
				printf( '<option %s>%s</option>', selected( $valeur, $poste, false ), esc_html( $poste ) );
			}
			echo '</select>';
		} else {
			printf( '<input class="regular-text" type="%1$s" id="hvb_%2$s" name="hvb[%2$s]" value="%3$s">', esc_attr( $type ), esc_attr( $cle ), esc_attr( $valeur ) );
		}
		echo '</td></tr>';
	}
	echo '</table>';
}

add_action( 'save_post', function ( $post_id, $post ) {
	if ( ! isset( HVB_CHAMPS[ $post->post_type ], $_POST['hvb_infos_nonce'] )
		|| ! wp_verify_nonce( $_POST['hvb_infos_nonce'], 'hvb_infos' )
		|| ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$saisie = wp_unslash( $_POST['hvb'] ?? array() );
	foreach ( HVB_CHAMPS[ $post->post_type ] as $cle => list( , $type ) ) {
		$valeur = $saisie[ $cle ] ?? '';
		$valeur = 'url' === $type ? esc_url_raw( $valeur ) : sanitize_text_field( $valeur );
		update_post_meta( $post_id, $cle, $valeur );
	}
}, 10, 2 );

// Colonnes utiles dans la liste des matchs.
add_filter( 'manage_hvb_match_posts_columns', function ( $cols ) {
	return array( 'cb' => $cols['cb'], 'title' => 'Match', 'hvb_date' => 'Date', 'hvb_score' => 'Score' );
} );
add_action( 'manage_hvb_match_posts_custom_column', function ( $col, $id ) {
	if ( 'hvb_date' === $col ) {
		echo esc_html( hvb_date_match( $id ) );
	} elseif ( 'hvb_score' === $col ) {
		echo esc_html( hvb_score( $id ) ?: '—' );
	}
}, 10, 2 );
