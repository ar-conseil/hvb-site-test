<?php
/**
 * Calendrier de l'équipe pro tenu à jour d'après la LNV, comme dans l'appli (fonction serveur « calendrier-lnv »).
 *
 * Toutes les heures (tâche hvb_maj_classement), le site relit la page des matchs DataProject du championnat et
 * recopie dans « Matchs » la date, l'heure et le lieu (domicile ou extérieur) de chaque journée. Le rapprochement
 * se fait par numéro de journée, puisque c'est la date qui change. Les matchs de coupe et les scores ne sont pas
 * touchés, et rien n'est modifié si la page est illisible ou incomplète (moins de 30 matchs du HVB).
 * Les pages, le référencement et le score en direct lisent la date du match à chaque affichage et suivent seuls ;
 * l'article d'annonce d'un match déplacé garde son texte : le journal le signale pour le corriger à la main.
 * Les derniers changements s'affichent en haut de la liste des matchs, dans l'administration.
 */

const HVB_LNV_CALENDRIER = 'https://lnv-web.dataproject.com/CompetitionMatches.aspx?ID=139';

/** Matchs de championnat de Harnes sur la page DataProject, par journée : date (Y-m-d), heure (H:i), domicile. */
function hvb_lnv_calendrier() {
	$reponse = wp_remote_get( HVB_LNV_CALENDRIER, array( 'timeout' => 30, 'user-agent' => 'Mozilla/5.0 (site du Harnes Volley-Ball)' ) );
	if ( is_wp_error( $reponse ) || 200 !== wp_remote_retrieve_response_code( $reponse ) ) {
		return array();
	}
	$html = wp_remote_retrieve_body( $reponse );
	// Numéro de chaque journée (« Journée 14 »), par bloc de la page.
	preg_match_all( '#RADLIST_Legs_ctrl(\d+)_LYR_LegName[\s\S]{0,600}?Journée\s+(\d+)#', $html, $legs );
	$journees = array_combine( $legs[1], array_map( 'intval', $legs[2] ) );
	// Un bloc par match, de son champ « HF_WonSetHome » au suivant.
	preg_match_all( '#RADLIST_Legs_ctrl(\d+)_RADLIST_Matches_ctrl\d+_HF_WonSetHome#', $html, $debuts, PREG_OFFSET_CAPTURE );
	$matchs = array();
	foreach ( $debuts[0] as $i => list( , $position ) ) {
		$bloc    = substr( $html, $position, ( $debuts[0][ $i + 1 ][1] ?? strlen( $html ) ) - $position );
		$equipe  = fn( $cote ) => preg_match( '#_Logo_' . $cote . '"[^>]*TeamLogo_(\d+)\.jpg#', $bloc, $m ) ? (int) $m[1] : 0;
		$dom     = $equipe( 'Home' );
		$journee = $journees[ $debuts[1][ $i ][0] ] ?? 0;
		if ( ( HVB_ID_HARNES !== $dom && HVB_ID_HARNES !== $equipe( 'Guest' ) ) || ! $journee
			|| ! preg_match( '#_LB_DataOra"[^>]*>([^<]*)#', $bloc, $quand )
			|| ! preg_match( '#(\d\d)/(\d\d)/(\d{4})\s*-\s*(\d\d:\d\d)#', $quand[1], $q ) ) {
			continue;
		}
		$matchs[ $journee ] = array( 'date' => "$q[3]-$q[2]-$q[1]", 'heure' => $q[4], 'domicile' => HVB_ID_HARNES === $dom );
	}
	return $matchs;
}

/** « samedi 21/11 à 19h00, extérieur » : pour le journal. */
function hvb_calendrier_lnv_texte( $date, $heure, $domicile ) {
	return wp_date( 'l d/m/Y', strtotime( "$date 12:00" ) ) . ( $heure ? ' à ' . str_replace( ':', 'h', $heure ) : '' ) . ( $domicile ? ', domicile' : ', extérieur' );
}

/** Recopie dans « Matchs » les dates, heures et lieux de la LNV. Renvoie les changements faits (vide si aucun). */
function hvb_calendrier_lnv_maj() {
	$lnv = hvb_lnv_calendrier();
	update_option( 'hvb_calendrier_lnv_lu', array( 'quand' => time(), 'matchs' => count( $lnv ) ), false );
	if ( count( $lnv ) < 30 ) {
		return array(); // Page illisible ou incomplète : on ne touche à rien.
	}
	$changements = array();
	foreach ( hvb_matchs() as $match ) {
		$id      = $match->ID;
		$journee = (int) get_post_meta( $id, 'journee', true );
		if ( get_post_meta( $id, 'competition', true ) || ! isset( $lnv[ $journee ] ) ) {
			continue;
		}
		$avant = array(
			'date'     => get_post_meta( $id, 'date', true ),
			'heure'    => get_post_meta( $id, 'heure', true ),
			'domicile' => (bool) get_post_meta( $id, 'domicile', true ),
		);
		$apres = $lnv[ $journee ];
		if ( $avant === $apres ) {
			continue;
		}
		update_post_meta( $id, 'date', $apres['date'] );
		update_post_meta( $id, 'heure', $apres['heure'] );
		update_post_meta( $id, 'domicile', $apres['domicile'] ? '1' : '' );
		$adversaire = get_post_meta( $id, 'adversaire', true );
		if ( $avant['domicile'] !== $apres['domicile'] ) {
			wp_update_post( array( 'ID' => $id, 'post_title' => $apres['domicile'] ? "Harnes VB – $adversaire" : "$adversaire – Harnes VB" ) );
		}
		$texte = "J$journee $adversaire : " . hvb_calendrier_lnv_texte( ...array_values( $avant ) ) . ' → ' . hvb_calendrier_lnv_texte( ...array_values( $apres ) ) . '.';
		if ( get_post_meta( $id, 'annonce', true ) ) {
			$texte .= ' Article d\'annonce déjà publié : sa date est à corriger à la main.';
		}
		$changements[] = $texte;
	}
	if ( $changements ) {
		$journal = get_option( 'hvb_calendrier_lnv_journal', array() );
		foreach ( $changements as $texte ) {
			array_unshift( $journal, array( time(), $texte ) );
		}
		update_option( 'hvb_calendrier_lnv_journal', array_slice( $journal, 0, 30 ), false );
		do_action( 'wpfc_clear_all_cache' ); // WP Fastest Cache : calendrier et accueil à jour tout de suite.
	}
	return $changements;
}

// Avant la reprise des scores (priorité 20), qui retrouve les matchs LNV par leur date.
add_action( 'hvb_maj_classement', 'hvb_calendrier_lnv_maj', 5 );

// Dernière lecture et derniers changements, en haut de la liste des matchs.
add_action( 'admin_notices', function () {
	$ecran = get_current_screen();
	if ( ! $ecran || 'edit-hvb_match' !== $ecran->id ) {
		return;
	}
	$lu      = get_option( 'hvb_calendrier_lnv_lu' );
	$journal = array_slice( get_option( 'hvb_calendrier_lnv_journal', array() ), 0, 8 );
	echo '<div class="notice notice-info"><p><strong>Dates, heures et lieux des matchs de championnat repris de la LNV toutes les heures</strong> (pas la coupe ni les scores). ';
	if ( $lu ) {
		echo esc_html( 'Dernière lecture : ' . wp_date( 'j F à H\hi', $lu['quand'] ) . ( $lu['matchs'] < 30 ? ', page LNV illisible : calendrier inchangé.' : '.' ) );
	}
	echo '</p>';
	if ( $journal ) {
		echo '<ul style="list-style:disc;margin-left:20px">';
		foreach ( $journal as list( $quand, $texte ) ) {
			echo '<li>' . esc_html( wp_date( 'j F H\hi', $quand ) . ' : ' . $texte ) . '</li>';
		}
		echo '</ul>';
	}
	echo '</div>';
} );
