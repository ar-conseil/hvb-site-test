<?php
/**
 * Fonctions d'affichage partagées par les gabarits.
 */

/**
 * URL d'une photo de la médiathèque, retrouvée par son nom (slug), ex. « equipe-2026-2027 ».
 */
function hvb_photo_id( $nom ) {
	static $cache = array();
	if ( ! array_key_exists( $nom, $cache ) ) {
		$ids            = get_posts( array( 'post_type' => 'attachment', 'name' => $nom, 'posts_per_page' => 1, 'fields' => 'ids', 'post_status' => 'inherit' ) );
		$cache[ $nom ] = $ids ? $ids[0] : 0;
	}
	return $cache[ $nom ];
}

function hvb_photo( $nom, $taille = 'full' ) {
	$id = hvb_photo_id( $nom );
	return $id ? wp_get_attachment_image_url( $id, $taille ) : '';
}

function hvb_matchs( $ordre = 'ASC', $nombre = -1, $meta_query = array() ) {
	return get_posts( array(
		'post_type'      => 'hvb_match',
		'posts_per_page' => $nombre,
		'meta_key'       => 'date',
		'orderby'        => 'meta_value',
		'order'          => $ordre,
		'meta_query'     => $meta_query,
	) );
}

function hvb_dernier_match() {
	$joues = hvb_matchs( 'DESC', 1, array( array( 'key' => 'score_hvb', 'value' => '', 'compare' => '!=' ) ) );
	return $joues[0] ?? null;
}

function hvb_prochain_match() {
	$a_venir = hvb_matchs( 'ASC', 1, array(
		array( 'key' => 'date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ),
		array( 'relation' => 'OR',
			array( 'key' => 'score_hvb', 'compare' => 'NOT EXISTS' ),
			array( 'key' => 'score_hvb', 'value' => '' ),
		),
	) );
	return $a_venir[0] ?? null;
}

function hvb_date_match( $id, $avec_jour = true ) {
	$date  = get_post_meta( $id, 'date', true );
	$heure = get_post_meta( $id, 'heure', true );
	if ( ! $date ) {
		return '';
	}
	$texte = wp_date( $avec_jour ? 'l j F Y' : 'j M', strtotime( $date . ' 12:00' ) );
	return ucfirst( $texte ) . ( $heure ? ' · ' . str_replace( ':', 'h', $heure ) : '' );
}

/** « J3 » en championnat, sinon le nom de la compétition (ex. Coupe de France). */
function hvb_etiquette_match( $id ) {
	$competition = get_post_meta( $id, 'competition', true );
	return $competition ?: 'J' . get_post_meta( $id, 'journee', true );
}

/** Nom de la compétition, pour les textes (championnat par défaut). */
function hvb_competition( $id ) {
	return get_post_meta( $id, 'competition', true ) ?: 'Volstar Masculine 2';
}

/** Page Billetterie avec le match présélectionné s'il est en vente (sinon la page, sur l'abonnement). */
function hvb_lien_billetterie( $id ) {
	$page = hvb_club()['billetterie'];
	return get_post_meta( $id, 'billetterie', true ) ? add_query_arg( 'match', get_post_meta( $id, 'date', true ), $page ) : add_query_arg( 'match', 'abonnement', $page );
}

/** Horodatage ISO du coup d'envoi, pour le compte à rebours. */
function hvb_coup_envoi( $id ) {
	$heure = get_post_meta( $id, 'heure', true ) ?: '20:00';
	return get_post_meta( $id, 'date', true ) . 'T' . $heure . ':00';
}

function hvb_score( $id ) {
	$hvb = get_post_meta( $id, 'score_hvb', true );
	$adv = get_post_meta( $id, 'score_adv', true );
	if ( '' === $hvb ) {
		return '';
	}
	// Match non joué (forfait) : la feuille de match porte « FP » au lieu d'un score.
	if ( ! is_numeric( $hvb ) || ! is_numeric( $adv ) ) {
		return 'Forfait';
	}
	return get_post_meta( $id, 'domicile', true ) ? "$hvb - $adv" : "$adv - $hvb";
}

/** Équipes dans l'ordre domicile / extérieur. */
function hvb_equipes( $id ) {
	$adv = get_post_meta( $id, 'adversaire', true );
	return get_post_meta( $id, 'domicile', true ) ? array( 'Harnes VB', $adv ) : array( $adv, 'Harnes VB' );
}

/** Pastille avec le logo HVB, ou les initiales de l'adversaire. */
function hvb_blason( $equipe ) {
	if ( 'Harnes VB' === $equipe ) {
		return '<img class="blason" src="' . esc_url( HVB_URI . '/assets/img/logo-hvb.png' ) . '" alt="">';
	}
	// Logo du club adverse, repris du classement LNV (voir inc/classement.php).
	foreach ( hvb_classement_lnv()['equipes'] as $club ) {
		if ( 0 === strpos( sanitize_title( $club['nom'] ), sanitize_title( $equipe ) ) || 0 === strpos( sanitize_title( $equipe ), sanitize_title( $club['nom'] ) ) ) {
			$logo = hvb_lnv_logo( $club['id'] );
			if ( $logo ) {
				return '<img class="blason blason--club" src="' . esc_url( $logo ) . '" alt="' . esc_attr( 'Logo ' . $club['nom'] ) . '">';
			}
		}
	}
	$mots     = preg_split( '/[\s-]+/', $equipe );
	$initiales = '';
	foreach ( array_slice( $mots, 0, 2 ) as $mot ) {
		$initiales .= mb_strtoupper( mb_substr( $mot, 0, 1 ) );
	}
	return '<span class="blason blason--texte" aria-hidden="true">' . esc_html( $initiales ) . '</span>';
}

/**
 * Logos des partenaires : première image de chaque fiche des pages partenaires.
 */
function hvb_logos_partenaires() {
	$logos = array();
	foreach ( array( 'partenaires-publics', 'partenaires-prives' ) as $slug ) {
		$page = get_page_by_path( $slug, OBJECT, 'page' );
		if ( ! $page ) {
			continue;
		}
		preg_match_all( '/<article class="partenaire">(?:(?!<\/article>).)*?<img[^>]+src="([^"]+)"[^>]*>(?:(?!<\/article>).)*?<h3 class="partenaire__nom">(.*?)<\/h3>/s', $page->post_content, $m, PREG_SET_ORDER );
		foreach ( $m as $logo ) {
			$logos[] = array( 'src' => $logo[1], 'nom' => wp_strip_all_tags( $logo[2] ), 'lien' => get_permalink( $page ) );
		}
	}
	return $logos;
}

function hvb_icone( $nom ) {
	$chemins = array(
		'facebook'  => 'M14 8h3V4h-3c-2.8 0-4 1.7-4 4.3V10H7v4h3v10h4V14h3l1-4h-4V8.6c0-.4.2-.6.6-.6z',
		'instagram' => 'M12 7.3A4.7 4.7 0 1 0 12 16.7 4.7 4.7 0 0 0 12 7.3zm0 7.7a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm6-7.9a1.1 1.1 0 1 1-2.2 0 1.1 1.1 0 0 1 2.2 0zM12 4c2.2 0 2.4 0 3.3.1 2.2.1 3.2 1.1 3.3 3.3.1.9.1 1.1.1 3.3s0 2.4-.1 3.3c-.1 2.2-1.1 3.2-3.3 3.3-.9.1-1.1.1-3.3.1s-2.4 0-3.3-.1c-2.2-.1-3.2-1.1-3.3-3.3C5.3 13.1 5.3 12.9 5.3 12s0-2.4.1-3.3C5.5 6.5 6.5 5.5 8.7 5.4 9.6 4 9.8 4 12 4zm0-1.7c-2.3 0-2.6 0-3.4.1-3 .1-4.6 1.8-4.8 4.8C3.7 8 3.7 8.3 3.7 12s0 2.6.1 3.4c.1 3 1.8 4.6 4.8 4.8.8 0 1.1.1 3.4.1s2.6 0 3.4-.1c3-.1 4.6-1.8 4.8-4.8 0-.8.1-1.1.1-3.4s0-2.6-.1-3.4c-.1-3-1.8-4.6-4.8-4.8-.8-.1-1.1-.1-3.4-.1z',
		'x'         => 'M17.8 3h3.1l-6.8 7.8 8 10.6h-6.3l-4.9-6.4-5.6 6.4H2.2l7.3-8.3L1.8 3h6.4l4.4 5.9L17.8 3zm-1.1 16.5h1.7L7.4 4.7H5.6l11.1 14.8z',
		'youtube'   => 'M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8zM10 15V9l5.2 3L10 15z',
		'tiktok'    => 'M16.6 5.8A4.3 4.3 0 0 1 15.5 3h-3.1v12.4a2.6 2.6 0 1 1-1.8-2.5V9.8a5.7 5.7 0 1 0 4.9 5.6V9.1a7.3 7.3 0 0 0 4.3 1.4V7.4a4.3 4.3 0 0 1-3.2-1.6z',
		'linkedin'  => 'M6.9 21H3.3V9.2h3.6V21zM5.1 7.6a2.1 2.1 0 1 1 0-4.2 2.1 2.1 0 0 1 0 4.2zM21 21h-3.6v-5.7c0-1.4 0-3.1-1.9-3.1s-2.2 1.5-2.2 3V21H9.7V9.2h3.4v1.6h.1a3.8 3.8 0 0 1 3.4-1.9c3.6 0 4.3 2.4 4.3 5.5V21z',
		'fleche'    => 'M13.2 5.3l-1.4 1.4 4.3 4.3H4v2h12.1l-4.3 4.3 1.4 1.4L20 12z',
		'gauche'    => 'M15.4 7.4L14 6l-6 6 6 6 1.4-1.4L10.8 12z',
		'droite'    => 'M8.6 7.4L10 6l6 6-6 6-1.4-1.4 4.6-4.6z',
		'bas'       => 'M12 16.5l-6-6 1.4-1.4 4.6 4.6 4.6-4.6 1.4 1.4z',
		'billet'    => 'M22 10V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v4a2 2 0 0 1 0 4v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 1 0-4zm-9 7.5h-2v-2h2v2zm0-4.5h-2v-2h2v2zm0-4.5h-2v-2h2v2z',
		'lieu'      => 'M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z',
		'tel'       => 'M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.2 11.4 11.4 0 0 0 3.6.6 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.2.2 2.5.6 3.6a1 1 0 0 1-.3 1z',
		'mail'      => 'M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4-8 5-8-5V6l8 5 8-5v2z',
		'sac'        => 'M18 6h-2a4 4 0 0 0-8 0H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm-6-2a2 2 0 0 1 2 2h-4a2 2 0 0 1 2-2zm6 16H6V8h2v2a1 1 0 0 0 2 0V8h4v2a1 1 0 0 0 2 0V8h2v12z',
		'calendrier' => 'M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 16H5V9h14v11zM7 11h5v5H7z',
		'qr'         => 'M3 11h8V3H3v8zm2-6h4v4H5V5zM3 21h8v-8H3v8zm2-6h4v4H5v-4zM13 3v8h8V3h-8zm6 6h-4V5h4v4zm0 10h2v2h-2zm-6-6h2v2h-2zm2 2h2v2h-2zm-2 2h2v2h-2zm2 2h2v2h-2zm2-2h2v2h-2zm0-4h2v2h-2zm2 2h2v2h-2z',
		'tasse'      => 'M20 3H4v10a4 4 0 0 0 4 4h6a4 4 0 0 0 4-4v-3h2a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm0 5h-2V5h2v3zM4 19h16v2H4z',
		'graphique'  => 'M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z',
		'groupe'     => 'M16 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-8 0a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm0 2c-2.3 0-7 1.2-7 3.5V19h14v-2.5c0-2.3-4.7-3.5-7-3.5zm8 0c-.3 0-.6 0-1 .1 1.2.8 2 2 2 3.4V19h6v-2.5c0-2.3-4.7-3.5-7-3.5z',
		'oeil'       => 'M12 4.5C7 4.5 2.7 7.6 1 12c1.7 4.4 6 7.5 11 7.5s9.3-3.1 11-7.5c-1.7-4.4-6-7.5-11-7.5zM12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
		'etoile'     => 'M12 17.3l6.2 3.7-1.6-7 5.4-4.8-7.2-.6L12 2 9.2 8.6 2 9.2l5.5 4.8-1.7 7z',
		'apple'      => 'M16.4 12.6c0-2.6 2.1-3.8 2.2-3.9-1.2-1.8-3.1-2-3.7-2-1.6-.2-3.1.9-3.9.9-.8 0-2-.9-3.4-.9-1.7 0-3.3 1-4.2 2.6-1.8 3.1-.5 7.8 1.3 10.3.9 1.2 1.9 2.6 3.2 2.6 1.3-.1 1.8-.8 3.3-.8s2 .8 3.4.8c1.4 0 2.3-1.3 3.1-2.5 1-1.4 1.4-2.8 1.4-2.9 0 0-2.7-1-2.7-4.2zM13.9 5c.7-.9 1.2-2 1-3.2-1 0-2.3.7-3 1.6-.7.7-1.2 1.9-1.1 3.1 1.2.1 2.3-.6 3.1-1.5z',
		'play'       => 'M3.6 1.8c-.3.3-.4.7-.4 1.2v18c0 .5.1.9.4 1.2l10-10.2-10-10.2zm11.3 11.5l2.9 2.9-11.5 6.5c-.4.2-.8.3-1.1.2l9.7-9.6zm0-2.6L5.2 1.1c.3-.1.7 0 1.1.2l11.5 6.5-2.9 2.9zm4.1 6.1l-3.2-3.3 3.2-3.2 3.6 2c1 .6 1 1.9 0 2.5l-3.6 2z',
	);
	return '<svg class="icone" viewBox="0 0 24 24" aria-hidden="true"><path d="' . $chemins[ $nom ] . '"/></svg>';
}

/** Nom affiché de chaque réseau. */
const HVB_NOMS_RESEAUX = array(
	'facebook'  => 'Facebook',
	'instagram' => 'Instagram',
	'x'         => 'X',
	'youtube'   => 'YouTube',
	'tiktok'    => 'TikTok',
	'linkedin'  => 'LinkedIn',
);

function hvb_reseaux() {
	$html = '<ul class="reseaux">';
	foreach ( hvb_club()['reseaux'] as $nom => list( $url ) ) {
		$html .= '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" aria-label="' . esc_attr( HVB_NOMS_RESEAUX[ $nom ] ) . '">' . hvb_icone( $nom ) . '</a></li>';
	}
	return $html . '</ul>';
}

/** Rubrique d'une page (Le club, Formation…), affichée au-dessus du titre. */
function hvb_rubrique( $post = null ) {
	$rubriques = array(
		'club'        => 'Le club',
		'pro'         => 'Volstar Masculine 2',
		'amateurs'    => 'Amateurs',
		'formation'   => 'Formation',
		'pourtous'    => 'Volley pour tous',
		'partenaires' => 'Partenaires',
	);
	$cle = get_post_meta( get_post( $post )->ID, 'hvb_rubrique', true );
	return $rubriques[ $cle ] ?? 'Harnes Volley-Ball';
}

/** Bandeau de titre des pages intérieures : photo en mouvement lent, titre centré, fil d'Ariane. */
function hvb_bandeau( $titre, $surtitre = '', $image = '' ) {
	$mots = preg_split( '/\s+/', $titre );
	?>
	<header class="bandeau<?php echo $image ? ' bandeau--image' : ''; ?>">
		<?php if ( $image ) : ?>
			<img class="bandeau__fond" src="<?php echo esc_url( $image ); ?>" alt="">
		<?php endif; ?>
		<div class="conteneur bandeau__texte">
			<nav class="ariane" aria-label="Fil d'Ariane">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Accueil</a>
				<?php if ( $surtitre ) : ?><span><?php echo esc_html( $surtitre ); ?></span><?php endif; ?>
			</nav>
			<h1 class="bandeau__titre">
				<?php foreach ( $mots as $i => $mot ) : ?>
					<span class="bandeau__mot" style="--i: <?php echo (int) $i; ?>"><span><?php echo esc_html( $mot ); ?></span></span>
				<?php endforeach; ?>
			</h1>
			<span class="bandeau__trait" aria-hidden="true"></span>
		</div>
		<a class="bandeau__suite" href="#suite" aria-label="Lire la suite"><?php echo hvb_icone( 'bas' ); // phpcs:ignore ?></a>
	</header>
	<span id="suite"></span>
	<?php
}

/** Liste des joueurs triée par poste puis par numéro. */
function hvb_joueurs() {
	$joueurs = get_posts( array( 'post_type' => 'hvb_joueur', 'posts_per_page' => -1 ) );
	usort( $joueurs, function ( $a, $b ) {
		$pa = array_search( get_post_meta( $a->ID, 'poste', true ), HVB_POSTES, true );
		$pb = array_search( get_post_meta( $b->ID, 'poste', true ), HVB_POSTES, true );
		return $pa <=> $pb ?: (int) get_post_meta( $a->ID, 'numero', true ) <=> (int) get_post_meta( $b->ID, 'numero', true );
	} );
	return $joueurs;
}

function hvb_carte_joueur( $joueur ) {
	$numero = get_post_meta( $joueur->ID, 'numero', true );
	$poste  = get_post_meta( $joueur->ID, 'poste', true );
	$noms   = explode( ' ', $joueur->post_title, 2 );
	?>
	<article class="joueur">
		<div class="joueur__photo">
			<?php
			// Joueur détouré (Media Day, sans voisins ni texte imprimé) s'il existe, sinon la photo d'origine.
			$detoure = "/assets/img/joueurs/joueur-$numero.webp";
			if ( file_exists( get_template_directory() . $detoure ) ) {
				printf( '<img class="joueur__detoure" src="%s" alt="%s" loading="lazy">', esc_url( HVB_URI . $detoure ), esc_attr( $joueur->post_title ) );
			} else {
				echo get_the_post_thumbnail( $joueur, 'hvb-card', array( 'loading' => 'lazy' ) );
			}
			?>
			<span class="joueur__numero"><?php echo esc_html( $numero ); ?></span>
		</div>
		<div class="joueur__infos">
			<h3 class="joueur__nom"><span><?php echo esc_html( $noms[0] ); ?></span> <?php echo esc_html( $noms[1] ?? '' ); ?></h3>
			<p class="joueur__poste"><?php echo esc_html( $poste ); ?></p>
		</div>
	</article>
	<?php
}

/**
 * Met en page le contenu d'une page de texte : chaque titre de niveau 2 ouvre une section
 * pleine largeur (fonds alternés, titre centré). Les photos isolées passent à côté du texte,
 * en alternance gauche / droite ; une section très courte (horaires…) devient un bandeau rouge.
 */
/** Pages de texte juridique : sections simples, listes classiques (ni cases rouges ni bandeaux). */
const HVB_PAGES_LEGALES = array( 'politique-de-confidentialite', 'confidentialite', 'mentions-legales', 'conditions-generales-de-vente', 'droit-de-retractation' );

function hvb_sections( $html ) {
	$blocs  = array();
	$legale = is_page( HVB_PAGES_LEGALES );
	foreach ( preg_split( '/(?=<h2[\s>])/', trim( $html ) ) as $morceau ) {
		if ( '' === trim( wp_strip_all_tags( $morceau, true ) ) && false === strpos( $morceau, '<img' ) ) {
			continue;
		}
		$titre = '';
		if ( preg_match( '#^<h2[^>]*>.*?</h2>#s', $morceau, $m ) ) {
			$titre   = $m[0];
			$morceau = substr( $morceau, strlen( $m[0] ) );
		}

		// Photos isolées (hors galeries et fiches) : affichées à côté du texte.
		$medias = array();
		if ( false === strpos( $morceau, 'wp-block-gallery' ) && false === strpos( $morceau, 'hvb-cards' ) ) {
			preg_match_all( '#<figure class="wp-block-image[^"]*"[^>]*>.*?</figure>#s', $morceau, $figures );
			if ( count( $figures[0] ) >= 1 && count( $figures[0] ) <= 2 ) {
				$medias  = $figures[0];
				$morceau = str_replace( $medias, '', $morceau );
			}
		}

		// Suite d'au moins trois mots-clés en paragraphes (« Équilibre », « Concentration »…) : affichée en liste de pastilles.
		$morceau = preg_replace_callback( '#(?:<p>[^<]{1,40}</p>\s*){3,}#u', function ( $m ) {
			preg_match_all( '#<p>([^<]+)</p>#u', $m[0], $mots );
			return '<ul class="wp-block-list">' . implode( '', array_map( fn( $mot ) => '<li>' . rtrim( trim( $mot ), '.' ) . '</li>', $mots[1] ) ) . '</ul>';
		}, $morceau );

		// Listes : éléments courts en cases « titre », textes longs en liste classique, le reste en cases rouges.
		// Le contenu de chaque case est enveloppé pour que « Libellé : valeur » reste sur une même ligne.
		$morceau = preg_replace_callback( '#<ul class="wp-block-list">(.*?)</ul>#s', function ( $m ) use ( $legale ) {
			preg_match_all( '#<li>(.*?)</li>#s', $m[1], $items );
			$longueur = $items[1] ? max( array_map( fn( $i ) => mb_strlen( wp_strip_all_tags( $i ) ), $items[1] ) ) : 0;
			$classe   = $legale || $longueur > 110 ? ' liste-texte' : ( $longueur <= 45 ? ' liste-courte' : '' );
			$lis      = preg_replace( '#<li>(.*?)</li>#s', '<li><span>$1</span></li>', $m[1] );
			return '<ul class="wp-block-list' . $classe . '">' . $lis . '</ul>';
		}, $morceau );

		$texte_seul = trim( wp_strip_all_tags( $morceau ) );
		$type       = 'clair';
		if ( ! $titre ) {
			$type = 'intro';
		} elseif ( ! $legale && ! $medias && strlen( $texte_seul ) < 90 && false === strpos( $morceau, '<ul' ) && false === strpos( $morceau, '<img' ) && false === strpos( $morceau, 'hvb-cards' ) ) {
			$type = 'accent';
		}
		$blocs[] = compact( 'titre', 'morceau', 'medias', 'texte_seul', 'type' );
	}

	// Horaires et tarif (« MERCREDI 19H-20H30 », « 90 € ») : regroupés en cartes « Infos pratiques ».
	$pratique = fn( $b ) => 'accent' === $b['type'] && preg_match( '/lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche|€|\d+ ?h/i', wp_strip_all_tags( $b['titre'] ) );
	$groupes  = array();
	foreach ( $blocs as $b ) {
		$dernier = count( $groupes ) - 1;
		if ( $pratique( $b ) && $dernier >= 0 && 'infos' === $groupes[ $dernier ]['type'] ) {
			$groupes[ $dernier ]['cartes'][] = $b;
		} elseif ( 'accent' === $b['type'] && ! $pratique( $b ) && $dernier >= 0 && 'accent' === $groupes[ $dernier ]['type'] ) {
			// Titres courts à la suite (« Le classement » puis « Nationale 2 – Poule D ») : un seul bandeau rouge.
			$groupes[ $dernier ]['morceau'] .= '<div class="bloc__suite">' . $b['titre'] . $b['morceau'] . '</div>';
		} elseif ( $pratique( $b ) ) {
			$groupes[] = array( 'type' => 'infos', 'cartes' => array( $b ) );
		} else {
			$groupes[] = $b;
		}
	}

	$sortie    = '';
	$rang      = 0;
	// Équipe suivie sur le site de la FFvolley : classement et résultats avant la galerie (ou en fin de page).
	$resultats = function_exists( 'hvb_bloc_resultats' ) && is_page() ? hvb_bloc_resultats( get_post_field( 'post_name', get_queried_object_id() ) ) : '';
	foreach ( $groupes as $b ) {
		if ( $resultats && 'infos' !== $b['type'] && preg_match( '#^galerie$#i', trim( wp_strip_all_tags( $b['titre'] ) ) ) ) {
			$sortie   .= $resultats;
			$resultats = '';
		}
		if ( 'infos' === $b['type'] ) {
			$sortie .= '<section class="bloc bloc--infos"><div class="bloc__inner"><p class="surtitre">Infos pratiques</p><div class="infos-pratiques">';
			foreach ( $b['cartes'] as $carte ) {
				$intitule = wp_strip_all_tags( $carte['titre'] );
				$icone    = false !== strpos( $intitule, '€' ) ? 'billet' : 'calendrier';
				$sortie  .= '<div class="info-pratique"><span class="info-pratique__icone">' . hvb_icone( $icone ) . '</span>'
					. '<strong class="info-pratique__titre">' . wp_kses( preg_replace( '#^<h2[^>]*>|</h2>$#', '', $carte['titre'] ), array( 'br' => array() ) ) . '</strong>'
					. '<div class="info-pratique__detail">' . $carte['morceau'] . '</div></div>';
			}
			$sortie .= '</div></div></section>';
			continue;
		}
		$type = $b['type'];
		if ( 'clair' === $type && $rang % 2 ) {
			$type = 'gris';
		}
		if ( preg_match( '#^galerie$#i', trim( wp_strip_all_tags( $b['titre'] ) ) ) ) {
			$type .= ' bloc--galerie';
		}

		$sortie .= '<section class="bloc bloc--' . $type . '"><div class="bloc__inner">';
		if ( $b['titre'] ) {
			$sortie .= '<header class="bloc__entete">' . $b['titre'] . '</header>';
		}
		if ( $b['medias'] && $b['texte_seul'] ) {
			$sortie .= '<div class="bloc__grille' . ( $rang % 2 ? ' bloc__grille--inverse' : '' ) . '"><div class="bloc__texte">' . $b['morceau'] . '</div><div class="bloc__media">' . implode( '', $b['medias'] ) . '</div></div>';
		} elseif ( $b['medias'] ) {
			$sortie .= '<div class="bloc__media bloc__media--seul">' . implode( '', $b['medias'] ) . '</div>';
		} else {
			$sortie .= '<div class="bloc__corps">' . $b['morceau'] . '</div>';
		}
		$sortie .= '</div></section>';
		if ( 'accent' !== $b['type'] ) {
			$rang++;
		}
	}
	return $sortie . $resultats;
}

/**
 * Les deux actions que le site doit déclencher : acheter le merch et devenir partenaire.
 * Grandes cartes photo, chacune avec un seul bouton clair.
 */
function hvb_actions_cles() {
	$boutique = hvb_club()['boutique'];
	$cartes   = array(
		array(
			'classe'   => 'merch',
			'photo'    => hvb_photo( 'mediaday-3', 'large' ),
			'alt'      => 'Joueurs du HVB présentant les maillots officiels 2026-2027',
			'surtitre' => 'Boutique officielle',
			'titre'    => 'Porte les couleurs <em>du HVB</em>',
			'texte'    => 'Les maillots officiels 2026-2027, en vente au stand du club à chaque match à domicile.',
			'bouton'   => 'Découvrir la boutique',
			'lien'     => $boutique,
			'externe'  => false,
		),
		array(
			'classe'   => 'partenariat',
			'photo'    => hvb_photo( 'champions2025', 'large' ),
			'alt'      => 'Les joueurs du Harnes Volley-Ball célèbrent le titre de champion de France Elite 2025',
			'surtitre' => 'Entreprises',
			'titre'    => 'Devenez <em>partenaire</em>',
			'texte'    => 'Quatre packs dès 3 000 €, soit 1 740 € après avantage fiscal. Visibilité, salon VIP et réseau du Business Club.',
			'bouton'   => 'Découvrir les packs',
			'lien'     => home_url( '/devenir-partenaire/#packs' ),
			'externe'  => false,
		),
	);
	?>
	<section class="actions-cles" aria-label="Boutique et partenariat">
		<?php foreach ( $cartes as $c ) : ?>
			<a class="action-cle action-cle--<?php echo esc_attr( $c['classe'] ); ?>" href="<?php echo esc_url( $c['lien'] ); ?>"<?php echo $c['externe'] ? ' target="_blank" rel="noopener"' : ''; ?>>
				<img class="action-cle__photo" src="<?php echo esc_url( $c['photo'] ); ?>" alt="<?php echo esc_attr( $c['alt'] ); ?>" loading="lazy">
				<span class="action-cle__texte">
					<span class="surtitre"><?php echo esc_html( $c['surtitre'] ); ?></span>
					<span class="action-cle__titre"><?php echo wp_kses( $c['titre'], array( 'em' => array() ) ); ?></span>
					<span class="action-cle__desc"><?php echo esc_html( $c['texte'] ); ?></span>
					<span class="bouton bouton--rouge action-cle__bouton"><?php echo esc_html( $c['bouton'] ); ?> <?php echo hvb_icone( 'fleche' ); // phpcs:ignore ?></span>
				</span>
			</a>
		<?php endforeach; ?>
	</section>
	<?php
}

/**
 * Typographie française : espace insécable avant « ! ? ; : » et à l'intérieur des guillemets,
 * pour qu'un signe ne se retrouve jamais seul en début de ligne.
 */
function hvb_typo( $html ) {
	$morceaux = preg_split( '/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
	$brut     = false;
	foreach ( $morceaux as $i => $morceau ) {
		if ( '' === $morceau ) {
			continue;
		}
		if ( '<' === $morceau[0] ) {
			$brut = (bool) preg_match( '#^<(script|style|textarea|code|pre)\b#i', $morceau ) || ( $brut && ! preg_match( '#^</(script|style|textarea|code|pre)>#i', $morceau ) );
			continue;
		}
		if ( ! $brut ) {
			$morceau        = preg_replace( '/ ([!?;:»])/u', "\u{202F}$1", $morceau );
			$morceaux[ $i ] = preg_replace( '/« /u', "«\u{202F}", $morceau );
		}
	}
	return implode( '', $morceaux );
}
add_filter( 'the_content', 'hvb_typo', 40 );
add_filter( 'the_title', 'hvb_typo', 40 );

/**
 * Cartes Google Maps chargées seulement au clic : rien n'est envoyé à Google (ni cookie déposé)
 * tant que le visiteur ne demande pas la carte. Lien direct vers Google Maps à côté.
 */
add_filter( 'the_content', function ( $html ) {
	return preg_replace_callback( '#<iframe class="hvb-map" src="([^"]+)"([^>]*)></iframe>#', function ( $m ) {
		$titre = preg_match( '#title="([^"]*)"#', $m[2], $t ) ? $t[1] : 'Plan d\'accès';
		$lieu  = preg_match( '#[?&](?:amp;)?q=([^&"]+)#', $m[1], $q ) ? urldecode( html_entity_decode( $q[1] ) ) : 'Harnes';
		return '<div class="carte-differee" data-src="' . esc_attr( html_entity_decode( $m[1] ) ) . '" data-titre="' . esc_attr( $titre ) . '">'
			. '<button type="button" class="bouton bouton--rouge carte-differee__bouton">' . hvb_icone( 'lieu' ) . ' Afficher la carte</button>'
			. '<a class="carte-differee__lien" href="' . esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $lieu ) ) . '" target="_blank" rel="noopener">Ouvrir dans Google Maps</a>'
			. '<p class="carte-differee__note">La carte Google Maps se charge seulement si vous cliquez.</p></div>';
	}, $html );
}, 50 );

