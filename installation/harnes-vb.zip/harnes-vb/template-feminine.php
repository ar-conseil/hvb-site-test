<?php
/**
 * Template Name: Section féminine
 * Présentation de la section féminine (loisir), avec sa couleur propre : le rose de ses tenues.
 */
get_header();
the_post();

// Contact : la responsable de la section féminine. Le bouton ouvre un e-mail tout prêt (et, sans messagerie
// installée, propose Gmail ou Outlook : voir main.js).
$email   = 'delphinetheo@gmail.com';
$corps   = "Bonjour,\n\n"
	. "Je souhaite rejoindre la section féminine du Harnes Volley-Ball.\n\n"
	. "Prénom et nom :\n"
	. "Téléphone :\n"
	. "Expérience en volley (club, niveau) :\n\n"
	. "Pourriez-vous m'indiquer les créneaux d'entraînement et la possibilité de venir faire un essai ?\n\n"
	. "Merci et à bientôt !";
$contact = 'mailto:' . $email . '?subject=' . rawurlencode( 'Rejoindre la section féminine du HVB' ) . '&body=' . rawurlencode( $corps );
$atouts  = array(
	array( 'etoile', 'Expérience du haut niveau', "D'anciennes joueuses de haut niveau partagent leur savoir-faire sur le terrain." ),
	array( 'groupe', 'Esprit d\'équipe', 'Une équipe soudée, sur le terrain comme en dehors.' ),
	array( 'oeil', 'Pratique loisir', 'Le plaisir de jouer avant tout, dans une ambiance conviviale.' ),
);
?>
<div class="feminine">
	<section class="feminine-ouverture">
		<div class="feminine-ouverture__visuel">
			<img class="feminine-ouverture__photo" src="<?php echo esc_url( hvb_photo( 'feminine-1', 'full' ) ); ?>" alt="L'équipe de la section féminine du HVB en tenue noire et rose, salle Maréchal">
		</div>
		<div class="feminine-ouverture__texte">
			<nav class="ariane" aria-label="Fil d'Ariane">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Accueil</a>
				<span>Amateurs</span>
			</nav>
			<h1 class="feminine-ouverture__titre">Section <em>féminine</em></h1>
			<p class="feminine-ouverture__intro">Le volley loisir au féminin, porté par d'anciennes joueuses de haut niveau.</p>
			<div class="feminine-ouverture__actions">
				<a class="bouton bouton--rose" href="#rejoindre">Nous rejoindre</a>
				<a class="bouton bouton--contour" href="#equipe">Découvrir l'équipe</a>
			</div>
		</div>
	</section>

	<section class="section" id="equipe">
		<div class="conteneur feminine-intro">
			<div class="feminine-intro__texte">
				<p class="surtitre">Amateurs · Loisir</p>
				<h2 class="titre-section">Le volley <em>entre filles</em></h2>
				<p>Au Harnes Volley-Ball, la section féminine réunit des joueuses autour d'une même passion. On y retrouve d'anciennes joueuses de haut niveau, qui mettent leur expérience au service d'une pratique loisir : technique, exigeante et toujours dans la bonne humeur.</p>
				<p>Que vous ayez joué hier ou que vous ayez simplement envie de retrouver le terrain, venez découvrir l'équipe.</p>
			</div>
			<figure class="feminine-intro__photo">
				<img src="<?php echo esc_url( hvb_photo( 'feminine-2', 'large' ) ); ?>" alt="Joueuses de la section féminine du HVB avec des ballons à l'entraînement" loading="lazy">
			</figure>
		</div>
	</section>

	<section class="section feminine-atouts">
		<div class="conteneur">
			<div class="appli__entete">
				<p class="surtitre">Ce qui nous rassemble</p>
				<h2 class="titre-section">Passion, <em>partage</em>, plaisir</h2>
			</div>
			<div class="atouts">
				<?php foreach ( $atouts as list( $icone, $titre, $texte ) ) : ?>
					<article class="atout atout--rose">
						<span class="atout__icone"><?php echo hvb_icone( $icone ); // phpcs:ignore ?></span>
						<h3><?php echo esc_html( $titre ); ?></h3>
						<p><?php echo esc_html( $texte ); ?></p>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="section feminine-galerie" aria-labelledby="galerie-titre">
		<div class="conteneur">
			<div class="appli__entete">
				<p class="surtitre">En images</p>
				<h2 class="titre-section" id="galerie-titre">La section <em>au complet</em></h2>
			</div>
			<div class="feminine-mosaique">
				<figure class="feminine-mosaique__grande">
					<img src="<?php echo esc_url( hvb_photo( 'feminine-1', 'large' ) ); ?>" alt="L'équipe féminine du HVB en tenue noire et rose, salle Maréchal" loading="lazy">
					<figcaption>En tenue de match · Salle Maréchal</figcaption>
				</figure>
				<figure>
					<img src="<?php echo esc_url( hvb_photo( 'feminine-3', 'large' ) ); ?>" alt="La section féminine et ses encadrants à l'entraînement" loading="lazy">
					<figcaption>Avec les encadrants</figcaption>
				</figure>
				<figure>
					<img src="<?php echo esc_url( hvb_photo( 'feminine-2', 'large' ) ); ?>" alt="Les joueuses de la section féminine du HVB avec des ballons" loading="lazy">
					<figcaption>À l'entraînement</figcaption>
				</figure>
			</div>
		</div>
	</section>

	<section class="feminine-appel" id="rejoindre">
		<div class="conteneur feminine-appel__grille">
			<div>
				<p class="surtitre">Envie de nous rejoindre ?</p>
				<h2 class="feminine-appel__titre">Viens jouer <em>avec nous</em></h2>
				<p>Écrivez-nous pour connaître les créneaux d'entraînement et venir faire un essai.</p>
			</div>
			<a class="bouton bouton--blanc" href="<?php echo esc_url( $contact ); ?>"><?php echo hvb_icone( 'mail' ); // phpcs:ignore ?> Contacter la section</a>
		</div>
	</section>
</div>
<?php
get_footer();
