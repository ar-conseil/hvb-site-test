<?php
/**
 * Template Name: Calendrier et résultats
 * Matchs saisis dans « Matchs », groupés par mois.
 */
get_header();
the_post();
hvb_bandeau( get_the_title(), 'Volstar Masculine 2 · 2026-2027', get_the_post_thumbnail_url( null, 'hvb-wide' ) );
?>
<div class="conteneur conteneur--moyen section">
	<div class="contenu"><?php the_content(); ?></div>
	<?php echo do_shortcode( '[hvb_direct]' ); ?>
	<?php
	$mois_courant = '';
	foreach ( hvb_matchs() as $match ) :
		$mois = wp_date( 'F Y', strtotime( get_post_meta( $match->ID, 'date', true ) . ' 12:00' ) );
		if ( $mois !== $mois_courant ) :
			$mois_courant = $mois;
			?>
			<h2 class="titre-mois"><?php echo esc_html( ucfirst( $mois ) ); ?></h2>
		<?php endif; ?>
		<?php
		list( $dom, $ext ) = hvb_equipes( $match->ID );
		$score             = hvb_score( $match->ID );
		$domicile          = get_post_meta( $match->ID, 'domicile', true );
		$lien              = get_post_meta( $match->ID, 'billetterie', true );
		?>
		<div class="ligne-match<?php echo $domicile ? ' ligne-match--domicile' : ''; ?>">
			<div class="ligne-match__date">
				<span<?php echo get_post_meta( $match->ID, 'competition', true ) ? ' class="est-coupe"' : ''; ?>><?php echo esc_html( hvb_etiquette_match( $match->ID ) ); ?></span>
				<?php echo esc_html( hvb_date_match( $match->ID ) ); ?>
			</div>
			<div class="ligne-match__equipes">
				<span class="ligne-match__equipe"><?php echo esc_html( $dom ); ?> <?php echo hvb_blason( $dom ); // phpcs:ignore ?></span>
				<span class="ligne-match__score<?php echo $score ? ( 'Forfait' === $score ? ' ligne-match__score--forfait' : '' ) : ' is-vide'; ?>"><?php echo esc_html( $score ?: 'vs' ); ?></span>
				<span class="ligne-match__equipe"><?php echo hvb_blason( $ext ); // phpcs:ignore ?> <?php echo esc_html( $ext ); ?></span>
			</div>
			<div class="ligne-match__action">
				<?php // L'abonnement ne couvre que le championnat : un match de coupe sans lien n'a pas de bouton. ?>
				<?php if ( $domicile && ! $score && ( $lien || ! get_post_meta( $match->ID, 'competition', true ) ) ) : ?>
					<a class="bouton bouton--rouge bouton--petit" href="<?php echo esc_url( hvb_lien_billetterie( $match->ID ) ); ?>"><?php echo $lien ? 'Billets' : 'Abonnement'; ?></a>
				<?php else : ?>
					<span class="pastille"><?php echo $domicile ? 'Domicile' : 'Extérieur'; ?></span>
				<?php endif; ?>
			</div>
		</div>
	<?php endforeach; ?>
</div>
<?php
get_footer();
