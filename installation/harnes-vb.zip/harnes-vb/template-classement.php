<?php
/**
 * Template Name: Classement
 * Classement de la Volstar Masculine 2, repris automatiquement de la LNV (voir inc/classement.php).
 */
get_header();
the_post();
hvb_bandeau( get_the_title(), 'Volstar Masculine 2 · Saison 2026-2027', get_the_post_thumbnail_url( null, 'hvb-wide' ) );

$hvb = hvb_classement_hvb();
?>
<div class="conteneur section classement-page">
	<?php if ( $hvb ) : ?>
		<div class="hvb-rang">
			<div class="hvb-rang__equipe">
				<img src="<?php echo esc_url( HVB_URI . '/assets/img/logo-hvb.png' ); ?>" alt="" width="72" height="72">
				<div>
					<p class="surtitre">Harnes Volley-Ball</p>
					<p class="hvb-rang__place"><strong><?php echo (int) $hvb['rang']; ?><sup><?php echo 1 === (int) $hvb['rang'] ? 'er' : 'e'; ?></sup></strong> de la Volstar M2</p>
				</div>
			</div>
			<dl class="hvb-rang__chiffres">
				<div><dt>Points</dt><dd><?php echo (int) $hvb['points']; ?></dd></div>
				<div><dt>Joués</dt><dd><?php echo (int) $hvb['joues']; ?></dd></div>
				<div><dt>Victoires</dt><dd><?php echo (int) $hvb['gagnes']; ?></dd></div>
				<div><dt>Sets</dt><dd><?php echo (int) $hvb['sets_g'] . '-' . (int) $hvb['sets_p']; ?></dd></div>
			</dl>
		</div>
	<?php endif; ?>

	<div class="classement-page__tableau">
		<?php echo hvb_tableau_classement(); // phpcs:ignore ?>
	</div>

	<p class="classement-page__source">
		Source : <a href="<?php echo esc_url( HVB_LNV_PAGE ); ?>" target="_blank" rel="noopener">Ligue Nationale de Volley</a>
		<?php if ( hvb_classement_maj() ) : ?> · mis à jour automatiquement le <?php echo esc_html( hvb_classement_maj() ); ?><?php endif; ?>
	</p>
	<div class="classement-page__actions">
		<a class="bouton bouton--rouge" href="<?php echo esc_url( home_url( '/calendrier-resultats/' ) ); ?>"><?php echo hvb_icone( 'calendrier' ); // phpcs:ignore ?> Calendrier et résultats</a>
		<a class="bouton bouton--noir" href="<?php echo esc_url( hvb_club()['billetterie'] ); ?>"><?php echo hvb_icone( 'billet' ); // phpcs:ignore ?> Billetterie</a>
	</div>
</div>
<?php
get_footer();
