<article class="carte-actu">
	<a class="carte-actu__image" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php the_post_thumbnail( 'hvb-wide', array( 'loading' => 'lazy' ) ); ?>
	</a>
	<div class="carte-actu__texte">
		<p class="surtitre"><?php echo esc_html( get_the_category()[0]->name ?? 'Actualité' ); ?> · <?php echo esc_html( get_the_date( 'j F Y' ) ); ?></p>
		<h2 class="carte-actu__titre"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p><?php echo esc_html( get_the_excerpt() ); ?></p>
	</div>
</article>
