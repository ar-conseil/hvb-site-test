<?php
/**
 * Import du contenu dans WordPress.
 * En local : appelé par wordpress/hvb-import.php (?etape=reglages | medias&lot=N | contenu | classement).
 * En ligne : appelé par l'extension installation/hvb-installation, qui définit HVB_EN_LIGNE et HVB_IMPORT_URL
 * (les photos et documents sont alors téléchargés depuis HVB_IMPORT_URL, les anciens contenus vont à la corbeille).
 * Chaque étape peut être relancée sans créer de doublons.
 */

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';

defined( 'HVB_IMPORT' ) || define( 'HVB_IMPORT', '/import' );
defined( 'HVB_EN_LIGNE' ) || define( 'HVB_EN_LIGNE', false );

// Tailles d'images réduites au nécessaire pour accélérer l'import.
add_filter( 'intermediate_image_sizes_advanced', function ( $tailles ) {
	unset( $tailles['medium_large'], $tailles['1536x1536'], $tailles['2048x2048'] );
	return $tailles;
} );
add_filter( 'big_image_size_threshold', '__return_false' );

function hvb_log( $texte ) {
	echo esc_html( $texte ) . "\n";
	flush();
}

function hvb_fichiers_medias() {
	if ( defined( 'HVB_IMPORT_URL' ) ) {
		return json_decode( file_get_contents( HVB_IMPORT . '/manifeste.json' ), true );
	}
	$fichiers = array();
	foreach ( array( 'photos', 'media' ) as $dossier ) {
		foreach ( glob( HVB_IMPORT . "/$dossier/*" ) as $chemin ) {
			$fichiers[] = $chemin;
		}
	}
	sort( $fichiers );
	return $fichiers;
}

/** Copie un fichier source (chemin local, ou chemin relatif téléchargé depuis HVB_IMPORT_URL) vers $tmp. */
function hvb_copier_source( $chemin, $tmp ) {
	if ( ! defined( 'HVB_IMPORT_URL' ) ) {
		return copy( $chemin, $tmp );
	}
	$url     = HVB_IMPORT_URL . '/' . implode( '/', array_map( 'rawurlencode', explode( '/', $chemin ) ) );
	$reponse = wp_remote_get( $url, array( 'timeout' => 60, 'stream' => true, 'filename' => $tmp ) );
	return ! is_wp_error( $reponse ) && 200 === wp_remote_retrieve_response_code( $reponse );
}

/** Supprime une ancienne page ou un ancien article : à la corbeille sur le site en ligne (récupérable), définitivement en local. */
function hvb_retirer( $id ) {
	return HVB_EN_LIGNE ? wp_trash_post( $id ) : wp_delete_post( $id, true );
}

function hvb_id_media( $fichier ) {
	$carte = get_option( 'hvb_import_medias', array() );
	return $carte[ $fichier ] ?? 0;
}

function hvb_url_media( $fichier ) {
	$id = hvb_id_media( $fichier );
	return $id ? wp_get_attachment_url( $id ) : '';
}

/* ---------- Étape 1 : réglages ---------- */
function hvb_etape_reglages() {
	switch_theme( 'harnes-vb' );
	update_option( 'blogname', 'Harnes Volley-Ball' );
	update_option( 'blogdescription', 'La passion du volley pour tous' );
	update_option( 'timezone_string', 'Europe/Paris' );
	update_option( 'date_format', 'j F Y' );
	update_option( 'time_format', 'H\hi' );
	update_option( 'WPLANG', 'fr_FR' );
	update_option( 'blog_public', HVB_EN_LIGNE ? '1' : '0' ); // Site de test : pas d'indexation.
	update_option( 'permalink_structure', '/%postname%/' );
	flush_rewrite_rules();

	foreach ( array( 'hello-world', 'sample-page', 'page-d-exemple', 'bonjour-tout-le-monde' ) as $slug ) {
		foreach ( get_posts( array( 'name' => $slug, 'post_type' => array( 'post', 'page' ), 'post_status' => 'any' ) ) as $p ) {
			hvb_retirer( $p->ID );
		}
	}
	foreach ( get_posts( array( 'post_type' => 'page', 'name' => 'privacy-policy', 'post_status' => 'any' ) ) as $p ) {
		hvb_retirer( $p->ID );
	}
	hvb_log( 'Réglages appliqués.' );
}

/* ---------- Étape 2 : médias, par lots ---------- */
function hvb_etape_medias( $lot, $taille = 25 ) {
	$fichiers = array_slice( hvb_fichiers_medias(), $lot * $taille, $taille );
	$carte    = get_option( 'hvb_import_medias', array() );
	foreach ( $fichiers as $chemin ) {
		$nom = basename( $chemin );
		if ( ! empty( $carte[ $nom ] ) && get_post( $carte[ $nom ] ) ) {
			continue;
		}
		if ( preg_match( '/\.svg$/i', $nom ) ) {
			continue;
		}
		$tmp = wp_tempnam( $nom );
		if ( ! hvb_copier_source( $chemin, $tmp ) ) {
			hvb_log( "ÉCHEC $nom : fichier introuvable" );
			continue;
		}
		$id = media_handle_sideload( array( 'name' => $nom, 'tmp_name' => $tmp ), 0 );
		if ( is_wp_error( $id ) ) {
			hvb_log( "ÉCHEC $nom : " . $id->get_error_message() );
			continue;
		}
		$carte[ $nom ] = $id;
		update_option( 'hvb_import_medias', $carte, false );
		hvb_log( "OK $nom" );
	}
	$total = count( hvb_fichiers_medias() );
	hvb_log( sprintf( 'Lot %d terminé (%d/%d).', $lot, min( ( $lot + 1 ) * $taille, $total ), $total ) );
	if ( ( $lot + 1 ) * $taille >= $total ) {
		hvb_log( 'FIN' );
	}
}

/* ---------- Étape 3 : contenus ---------- */
function hvb_remplacer_images( $contenu ) {
	$contenu = str_replace( '{{theme}}', get_template_directory_uri(), $contenu );
	return preg_replace_callback( '/\{\{img:([^}]+)\}\}/', fn( $m ) => hvb_url_media( $m[1] ) ?: '', $contenu );
}

/** Première vraie photo de la page (on écarte logos, pictos et visuels PNG). */
function hvb_premiere_image( $contenu ) {
	preg_match_all( '/\{\{img:([^}]+)\}\}/', $contenu, $m );
	foreach ( $m[1] as $fichier ) {
		if ( preg_match( '/\.(jpe?g|webp)$/i', $fichier ) && ! preg_match( '/logo|picto|placeholder/i', $fichier ) ) {
			return hvb_id_media( $fichier );
		}
	}
	return $m[1] ? hvb_id_media( $m[1][0] ) : 0;
}

function hvb_enregistrer( $type, $slug, $titre, $contenu = '', $extra = array() ) {
	$existant = get_page_by_path( $slug, OBJECT, $type );
	$donnees  = array_merge( array(
		'post_type'    => $type,
		'post_name'    => $slug,
		'post_title'   => $titre,
		'post_content' => $contenu,
		'post_status'  => 'publish',
	), $extra );
	if ( $existant ) {
		$donnees['ID'] = $existant->ID;
	}
	$id = wp_insert_post( wp_slash( $donnees ) );
	hvb_sans_elementor( $id );
	return $id;
}

/**
 * Sur le site actuel, les pages sont construites avec Elementor : sans ce nettoyage, Elementor afficherait
 * encore l'ancienne mise en page à la place du nouveau contenu (et l'ancien modèle de page resterait actif).
 */
function hvb_sans_elementor( $id ) {
	foreach ( array( '_elementor_edit_mode', '_elementor_data', '_elementor_page_settings', '_elementor_css', '_elementor_template_type', '_elementor_version', '_elementor_pro_version', '_elementor_controls_usage', '_elementor_page_assets' ) as $cle ) {
		delete_post_meta( $id, $cle );
	}
	$modele = get_post_meta( $id, '_wp_page_template', true );
	if ( $modele && 'default' !== $modele && ! file_exists( get_template_directory() . '/' . $modele ) ) {
		update_post_meta( $id, '_wp_page_template', 'default' );
	}
}

/** Documents à télécharger (PDF) : importés une fois, puis réutilisés. */
function hvb_importer_document( $fichier ) {
	$carte = get_option( 'hvb_import_medias', array() );
	if ( empty( $carte[ $fichier ] ) || ! get_post( $carte[ $fichier ] ) ) {
		$tmp = wp_tempnam( $fichier );
		hvb_copier_source( defined( 'HVB_IMPORT_URL' ) ? 'docs/' . $fichier : HVB_IMPORT . '/docs/' . $fichier, $tmp );
		$id = media_handle_sideload( array( 'name' => $fichier, 'tmp_name' => $tmp ), 0, 'Dossier de partenariat HVB 2026-2027' );
		if ( is_wp_error( $id ) ) {
			hvb_log( "ÉCHEC $fichier : " . $id->get_error_message() );
			return '';
		}
		$carte[ $fichier ] = $id;
		update_option( 'hvb_import_medias', $carte, false );
	}
	return wp_get_attachment_url( $carte[ $fichier ] );
}

function hvb_etape_contenu() {
	$source = json_decode( file_get_contents( HVB_IMPORT . '/content.json' ), true );

	// La brochure 2025-2026 du site actuel est remplacée par le dossier de partenariat 2026-2027.
	$dossier = hvb_importer_document( 'dossier-partenariat-hvb-2026-2027.pdf' );
	foreach ( $source['pages'] as &$page ) {
		$page['content'] = str_replace( '{{dossier}}', esc_url( $dossier ), $page['content'] );
		$page['content'] = preg_replace(
			'#<a class="wp-block-button__link wp-element-button" href="[^"]*Plaquette-HVB-2025-2026[^"]*">[^<]*</a>#',
			'<a class="wp-block-button__link wp-element-button" href="' . esc_url( $dossier ) . '" target="_blank" rel="noopener">Téléchargez le dossier de partenariat 2026-2027</a>',
			$page['content']
		);
	}
	unset( $page );

	// Pages reprises du site actuel.
	$pages = array();
	foreach ( $source['pages'] as $page ) {
		$id = hvb_enregistrer( 'page', $page['slug'], $page['title'], hvb_remplacer_images( $page['content'] ) );
		update_post_meta( $id, 'hvb_rubrique', $page['group'] );
		// Pages à mise en page riche (Histoire, Infrastructures) : affichées en pleine largeur.
		update_post_meta( $id, 'hvb_large', empty( $page['riche'] ) ? '' : '1' );
		$image = hvb_premiere_image( $page['content'] );
		if ( $image ) {
			set_post_thumbnail( $id, $image );
		}
		$pages[ $page['slug'] ] = $id;
	}
	// Visuels de bandeau plus parlants que la première image de la page.
	$bandeaux = array(
		'presentation-du-club' => 'equipe-2026-2027.jpg',
		'partenaires-prives'   => 'mediaday-7.jpg',
		'devenir-partenaire'   => 'mediaday-3.jpg',
		'inscription'          => 'mediaday-8.jpg',
		'nationale-2'          => 'IMG_0784.webp',
		'benevoles'            => 'WhatsApp-Image-2025-11-01-a-15.30.43_ba9bd425.jpg',
		'histoire-du-club'     => 'vintage.webp',
		'infrastructures'      => 'salle-marechal-min-scaled-1.jpg',
	);
	foreach ( $bandeaux as $slug => $fichier ) {
		set_post_thumbnail( $pages[ $slug ], hvb_id_media( $fichier ) );
	}

	// Pages nouvelles.
	$pages['accueil'] = hvb_enregistrer( 'page', 'accueil', 'Accueil' );
	$pages['actus']   = hvb_enregistrer( 'page', 'actus', 'Actualités' );

	$pages['effectif'] = hvb_enregistrer( 'page', 'effectif', 'Effectif 2026-2027' );
	update_post_meta( $pages['effectif'], '_wp_page_template', 'template-effectif.php' );
	set_post_thumbnail( $pages['effectif'], hvb_id_media( 'equipe-2026-2027.jpg' ) );
	update_post_meta( $pages['effectif'], 'hvb_rubrique', 'pro' );

	$intro_cal = '<!-- wp:paragraph -->' . "\n" . '<p>Tous les matchs de la Volstar Masculine 2. Les rencontres à domicile se jouent à la Salle Régionale Maréchal, 128 Chemin Valois à Harnes.</p>' . "\n" . '<!-- /wp:paragraph -->';
	$pages['calendrier-resultats'] = hvb_enregistrer( 'page', 'calendrier-resultats', 'Calendrier et résultats', $intro_cal );
	update_post_meta( $pages['calendrier-resultats'], '_wp_page_template', 'template-calendrier.php' );
	set_post_thumbnail( $pages['calendrier-resultats'], hvb_id_media( 'mediaday-5.jpg' ) );
	update_post_meta( $pages['calendrier-resultats'], 'hvb_rubrique', 'pro' );

	// Classement repris automatiquement de la LNV par le thème (inc/classement.php).
	$pages['classement'] = hvb_enregistrer( 'page', 'classement', 'Classement', '' );
	update_post_meta( $pages['classement'], '_wp_page_template', 'template-classement.php' );
	set_post_thumbnail( $pages['classement'], hvb_id_media( 'mediaday-1.jpg' ) );
	update_post_meta( $pages['classement'], 'hvb_rubrique', 'pro' );

	$intro_billets = "<!-- wp:paragraph -->\n<p>Réservez vos places pour les matchs à domicile de la Volstar Masculine 2 ou prenez l'abonnement pour toute la saison. Choisissez un match : la billetterie officielle Billetweb du club s'affiche aussitôt.</p>\n<!-- /wp:paragraph -->";
	$pages['billetterie'] = hvb_enregistrer( 'page', 'billetterie', 'Billetterie', $intro_billets );
	update_post_meta( $pages['billetterie'], '_wp_page_template', 'template-billetterie.php' );
	set_post_thumbnail( $pages['billetterie'], hvb_id_media( 'mediaday-7.jpg' ) );
	update_post_meta( $pages['billetterie'], 'hvb_rubrique', 'pro' );

	$pages['direction'] = hvb_enregistrer( 'page', 'direction', 'Direction', hvb_direction() );
	update_post_meta( $pages['direction'], 'hvb_rubrique', 'club' );

	$pages['section-feminine'] = hvb_enregistrer( 'page', 'section-feminine', 'Section féminine', '', array(
		'post_excerpt' => "La section féminine du Harnes Volley-Ball : du volley loisir porté par d'anciennes joueuses de haut niveau, à la salle Maréchal de Harnes.",
	) );
	update_post_meta( $pages['section-feminine'], '_wp_page_template', 'template-feminine.php' );
	update_post_meta( $pages['section-feminine'], 'hvb_rubrique', 'amateurs' );
	set_post_thumbnail( $pages['section-feminine'], hvb_id_media( 'feminine-1.jpg' ) );

	$pages['boutique'] = hvb_enregistrer( 'page', 'boutique', 'Boutique', '' );
	update_post_meta( $pages['boutique'], '_wp_page_template', 'template-boutique.php' );

	$pages['application'] = hvb_enregistrer( 'page', 'application', "L'appli HVB Partenaires", '' );
	update_post_meta( $pages['application'], '_wp_page_template', 'template-appli.php' );
	update_post_meta( $pages['application'], 'hvb_rubrique', 'partenaires' );

	$pages['contact'] = hvb_enregistrer( 'page', 'contact', 'Contact', hvb_contact() );
	set_post_thumbnail( $pages['contact'], hvb_id_media( 'mediaday-5.jpg' ) );
	update_post_meta( $pages['contact'], 'hvb_rubrique', 'club' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $pages['accueil'] );
	update_option( 'page_for_posts', $pages['actus'] );
	update_option( 'wp_page_for_privacy_policy', $pages['politique-de-confidentialite'] );
	hvb_log( count( $pages ) . ' pages.' );

	// Articles.
	foreach ( $source['posts'] as $post ) {
		$cats = array_map( fn( $nom ) => (int) ( term_exists( $nom, 'category' )['term_id'] ?? wp_insert_term( $nom, 'category' )['term_id'] ), $post['categories'] );
		$id   = hvb_enregistrer( 'post', $post['slug'], $post['title'], hvb_remplacer_images( $post['content'] ), array(
			'post_date'     => $post['date'],
			'post_excerpt'  => $post['excerpt'],
			'post_category' => $cats,
		) );
		if ( $post['thumbnail'] ) {
			set_post_thumbnail( $id, hvb_id_media( $post['thumbnail'] ) );
		}
	}
	// Articles retirés de la source (ex. l'ancien manager général) : supprimés du site aussi.
	$slugs = array_column( $source['posts'], 'slug' );
	foreach ( get_posts( array( 'post_type' => 'post', 'posts_per_page' => -1, 'post_status' => 'any' ) ) as $ancien ) {
		if ( ! in_array( $ancien->post_name, $slugs, true ) ) {
			hvb_retirer( $ancien->ID );
		}
	}
	// Anciennes pages sans équivalent (pages Elite des saisons passées, etc.) : leurs adresses sont redirigées par le thème.
	foreach ( get_posts( array( 'post_type' => 'page', 'posts_per_page' => -1, 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ) ) ) as $ancienne ) {
		if ( ! in_array( $ancienne->ID, $pages, true ) ) {
			hvb_retirer( $ancienne->ID );
		}
	}
	wp_delete_term( get_option( 'default_category' ), 'category' );
	hvb_log( count( $source['posts'] ) . ' articles.' );

	hvb_importer_joueurs();
	hvb_importer_matchs();
	hvb_menus( $pages );
	hvb_log( 'FIN' );
}

function hvb_importer_joueurs() {
	$joueurs = array(
		array( 16, 'Karim Lamri', 'Passeur' ),
		array( 10, 'Sami Sadli', 'Passeur' ),
		array( 15, 'Baptiste Delaroque', 'Central' ),
		array( 17, 'Louis De Jésus', 'Central' ),
		array( 9, 'Facundo Hernández', 'Central' ),
		array( 12, 'Samuel Quéva', 'Pointu' ),
		array( 91, 'Ethan Namboue', 'Pointu' ),
		array( 7, 'Juan Pablo Pereyra', 'Réceptionneur-attaquant' ),
		array( 4, 'Nicolas Maréchal', 'Réceptionneur-attaquant' ),
		array( 22, 'Thomas Lapierre', 'Réceptionneur-attaquant' ),
		array( 6, 'Tristan Sapet', 'Libéro' ),
		array( 60, 'Altan Demiryurek', 'Libéro' ),
	);
	foreach ( $joueurs as list( $numero, $nom, $poste ) ) {
		$id = hvb_enregistrer( 'hvb_joueur', sanitize_title( $nom ), $nom );
		update_post_meta( $id, 'numero', (string) $numero );
		update_post_meta( $id, 'poste', $poste );
		set_post_thumbnail( $id, hvb_id_media( "joueur-$numero.jpg" ) );
	}
	hvb_log( count( $joueurs ) . ' joueurs.' );
}

function hvb_importer_matchs() {
	$calendrier  = json_decode( file_get_contents( HVB_IMPORT . '/calendrier.json' ), true );
	$billetterie = json_decode( file_get_contents( HVB_IMPORT . '/billetterie.json' ), true );
	// Résultats tels que publiés sur la page « Résultats » du site actuel.
	$resultats = array(
		1 => array( 'FP', '3' ),
		2 => array( 'FP', '3' ),
	);
	foreach ( $calendrier['matchs'] as $m ) {
		$titre = $m['domicile'] ? 'Harnes VB – ' . $m['adversaire'] : $m['adversaire'] . ' – Harnes VB';
		$id    = hvb_enregistrer( 'hvb_match', 'j' . $m['journee'], $titre );
		update_post_meta( $id, 'journee', (string) $m['journee'] );
		update_post_meta( $id, 'date', $m['date'] );
		update_post_meta( $id, 'heure', (string) $m['heure'] );
		update_post_meta( $id, 'adversaire', $m['adversaire'] );
		update_post_meta( $id, 'domicile', $m['domicile'] ? '1' : '' );
		update_post_meta( $id, 'score_hvb', $resultats[ $m['journee'] ][0] ?? '' );
		update_post_meta( $id, 'score_adv', $resultats[ $m['journee'] ][1] ?? '' );
		update_post_meta( $id, 'billetterie', $billetterie['matchs'][ $m['date'] ] ?? '' );
	}
	hvb_log( count( $calendrier['matchs'] ) . ' matchs.' );
}

function hvb_direction() {
	$personnes = array(
		array( 'direction-portrait-b.jpg', 'Arnaud Becqueriaux', 'Président' ),
		array( 'direction-portrait-a.jpg', 'Yannick Defrance', 'Directeur administratif et financier' ),
		array( 'direction-antonin-rouzier.jpg', 'Antonin Rouzier', 'Manager général' ),
	);
	$cartes = '';
	foreach ( $personnes as list( $photo, $nom, $role ) ) {
		$cartes .= '<!-- wp:group {"className":"hvb-card","layout":{"type":"default"}} -->' . "\n<div class=\"wp-block-group hvb-card\">"
			. '<!-- wp:image {"sizeSlug":"large"} -->' . "\n" . '<figure class="wp-block-image size-large"><img src="' . esc_url( hvb_url_media( $photo ) ) . '" alt="' . esc_attr( $nom ) . '"/></figure>' . "\n<!-- /wp:image -->\n\n"
			. '<!-- wp:heading {"level":3} -->' . "\n<h3 class=\"wp-block-heading\">" . esc_html( $nom ) . "</h3>\n<!-- /wp:heading -->\n\n"
			. '<!-- wp:heading {"level":3} -->' . "\n<h3 class=\"wp-block-heading\">" . esc_html( $role ) . "</h3>\n<!-- /wp:heading -->"
			. "</div>\n<!-- /wp:group -->\n\n";
	}
	return "<!-- wp:paragraph -->\n<p>L'équipe dirigeante du Harnes Volley-Ball pour la saison 2026-2027.</p>\n<!-- /wp:paragraph -->\n\n"
		. '<!-- wp:group {"className":"hvb-cards hvb-direction","layout":{"type":"default"}} -->' . "\n<div class=\"wp-block-group hvb-cards hvb-direction\">$cartes</div>\n<!-- /wp:group -->";
}

function hvb_contact() {
	$club = hvb_club();
	return "<!-- wp:paragraph -->\n<p>Un renseignement, une inscription, un partenariat ? Écrivez-nous ou passez nous voir à la salle.</p>\n<!-- /wp:paragraph -->\n\n"
		. "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Nous joindre</h2>\n<!-- /wp:heading -->\n\n"
		. "<!-- wp:html -->\n" . hvb_cartes_contact( $club ) . "\n<!-- /wp:html -->\n\n"
		. "<!-- wp:html -->\n<iframe class=\"hvb-map\" src=\"https://maps.google.com/maps?t=m&amp;output=embed&amp;iwloc=near&amp;z=15&amp;q=128+Chemin+Valois+HARNES+FRANCE\" loading=\"lazy\" title=\"Plan d'accès à la Salle Régionale Maréchal\"></iframe>\n<!-- /wp:html -->";
}

/** Cartes Adresse / Téléphone / E-mail : chacune cliquable (itinéraire, appel, e-mail). */
function hvb_cartes_contact( $club ) {
	$cartes = array(
		array( 'lieu', 'Adresse', $club['salle'], $club['adresse'], 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $club['salle'] . ' ' . $club['adresse'] ), 'Itinéraire' ),
		array( 'tel', 'Téléphone', $club['telephone'], 'Appelez le club', 'tel:' . str_replace( ' ', '', $club['telephone'] ), 'Appeler' ),
		array( 'mail', 'E-mail', $club['email'], 'Écrivez-nous', 'mailto:' . $club['email'], 'Écrire' ),
	);
	$html = '<div class="contact-cartes">';
	foreach ( $cartes as list( $icone, $libelle, $valeur, $detail, $lien, $action ) ) {
		$html .= '<a class="contact-carte" href="' . esc_url( $lien ) . '"' . ( 'lieu' === $icone ? ' target="_blank" rel="noopener"' : '' ) . '>'
			. '<span class="contact-carte__icone">' . hvb_icone( $icone ) . '</span>'
			. '<span class="contact-carte__libelle">' . esc_html( $libelle ) . '</span>'
			. '<strong class="contact-carte__valeur">' . esc_html( $valeur ) . '</strong>'
			. '<span class="contact-carte__detail">' . esc_html( $detail ) . '</span>'
			. '<span class="contact-carte__action">' . esc_html( $action ) . ' ' . hvb_icone( 'fleche' ) . '</span></a>';
	}
	return $html . '</div>';
}

function hvb_menus( $pages ) {
	$structure = array(
		array( 'Le club', 'presentation-du-club', array( 'presentation-du-club', 'histoire-du-club', 'direction', 'staff-technique', 'benevoles', 'infrastructures', 'inscription' ) ),
		array( 'Volstar M2', 'effectif', array( 'effectif', 'calendrier-resultats', 'classement', 'billetterie' ) ),
		array( 'Amateurs', 'nationale-2', array( 'nationale-2', 'pre-nationale', 'departementale-4', 'departementale-5', 'section-feminine' ) ),
		array( 'Formation', 'ecole-de-volley', array( 'baby-volley', 'ecole-de-volley', 'categorie-m13', 'categorie-m15', 'stages' ) ),
		array( 'Volley pour tous', 'volley-loisir', array( 'volley-loisir', 'volley-sante' ) ),
		array( 'Actus', 'actus', array() ),
		array( 'Partenaires', 'partenaires-prives', array( 'devenir-partenaire', 'partenaires-publics', 'partenaires-prives' ) ),
		array( "L'appli", 'application', array() ),
		array( 'Contact', 'contact', array() ),
	);
	$menu = wp_get_nav_menu_object( 'Menu principal' );
	if ( $menu ) {
		wp_delete_nav_menu( $menu->term_id );
	}
	$menu_id = wp_create_nav_menu( 'Menu principal' );
	foreach ( $structure as list( $titre, $cible, $enfants ) ) {
		$parent = wp_update_nav_menu_item( $menu_id, 0, array(
			// L'équipe première et les partenaires sont mis en avant (rouge, plus gros) dans le menu.
			'menu-item-classes'   => array( 'Volstar M2' => 'menu-volstar menu-vedette', 'Partenaires' => 'menu-partenaires menu-vedette' )[ $titre ] ?? '',
			'menu-item-title'     => $titre,
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $pages[ $cible ],
			'menu-item-type'      => 'post_type',
			'menu-item-status'    => 'publish',
		) );
		foreach ( $enfants as $enfant ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $pages[ $enfant ],
				'menu-item-type'      => 'post_type',
				'menu-item-parent-id' => $parent,
				'menu-item-classes'   => 'section-feminine' === $enfant ? 'menu-feminine' : '',
				'menu-item-status'    => 'publish',
			) );
		}
	}

	$pied = wp_get_nav_menu_object( 'Pied de page' );
	if ( $pied ) {
		wp_delete_nav_menu( $pied->term_id );
	}
	$pied_id = wp_create_nav_menu( 'Pied de page' );
	foreach ( array( 'presentation-du-club', 'effectif', 'calendrier-resultats', 'billetterie', 'inscription', 'devenir-partenaire', 'boutique', 'application', 'actus', 'infrastructures', 'contact' ) as $slug ) {
		wp_update_nav_menu_item( $pied_id, 0, array(
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $pages[ $slug ],
			'menu-item-type'      => 'post_type',
			'menu-item-status'    => 'publish',
		) );
	}
	set_theme_mod( 'nav_menu_locations', array( 'principal' => $menu_id, 'pied' => $pied_id ) );
	hvb_log( 'Menus créés.' );
}
