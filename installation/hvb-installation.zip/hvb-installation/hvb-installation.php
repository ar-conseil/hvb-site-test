<?php
/**
 * Plugin Name: HVB – Installation du nouveau site
 * Description: Installe le nouveau site du Harnes Volley-Ball (contenus, photos, menus, classements) sur ce WordPress. À utiliser une fois après avoir installé le thème « Harnes Volley-Ball », puis à supprimer.
 * Version: 1.0.0
 * Author: Harnes Volley-Ball
 * Requires PHP: 7.4
 */

defined( 'ABSPATH' ) || exit;

define( 'HVB_EN_LIGNE', true );
define( 'HVB_IMPORT', __DIR__ . '/donnees' );
// Photos et documents : téléchargés pendant l'installation (évite la limite de taille des fichiers envoyés).
defined( 'HVB_IMPORT_URL' ) || define( 'HVB_IMPORT_URL', 'https://ar-conseil.github.io/hvb-site-test/installation' );

/**
 * Extensions de l'ancien site désactivées à la fin (pas supprimées : elles restent réactivables).
 * Le thème gère lui-même le référencement (Yoast ferait doublon), et le contenu est écrit en blocs (éditeur classique inutile).
 * WP Fastest Cache servirait encore les pages de l'ancien site : son cache est vidé avant désactivation.
 */
const HVB_ANCIENNES_EXTENSIONS = array( 'elementor', 'elementor-pro', 'royal-elementor-addons', 'timeline-widget-addon-for-elementor', 'unlimited-elements-for-elementor', 'trx_addons', 'trx_updater', 'the-events-calendar', 'wordpress-seo', 'contact-form-7', 'classic-editor', 'wp-fastest-cache', 'elementor-one', 'elementor-mcp-composer' );

add_action( 'admin_menu', function () {
	add_management_page( 'Installer le nouveau site', 'Nouveau site HVB', 'manage_options', 'hvb-installation', 'hvb_installation_page' );
} );

function hvb_installation_page() {
	$theme = wp_get_theme( 'harnes-vb' );
	?>
	<div class="wrap">
		<h1>Installer le nouveau site du Harnes Volley-Ball</h1>
		<?php if ( ! $theme->exists() ) : ?>
			<div class="notice notice-error"><p>Installez d'abord le thème <strong>Harnes Volley-Ball</strong> (Apparence → Thèmes → Ajouter → Téléverser un thème), puis revenez ici.</p></div>
		<?php else : ?>
			<p>L'installation remplace le site actuel : thème, pages, articles, menus et page d'accueil. Elle prend quelques minutes ; laissez cette page ouverte jusqu'au message « Installation terminée ».</p>
			<ul style="list-style:disc;padding-left:20px">
				<li>Les anciennes pages et anciens articles sans équivalent vont à la <strong>corbeille</strong> (récupérables).</li>
				<li>Les extensions de l'ancien site (Elementor, Yoast, The Events Calendar, Contact Form 7…) sont <strong>désactivées</strong>, pas supprimées.</li>
				<li>Les comptes utilisateurs, la médiathèque et les e-mails ne sont pas touchés.</li>
			</ul>
			<p><label><input type="checkbox" id="hvb-sauvegarde"> J'ai fait une sauvegarde complète du site actuel.</label></p>
			<p><button class="button button-primary button-hero" id="hvb-lancer" disabled>Lancer l'installation</button></p>
			<pre id="hvb-journal" style="display:none;max-height:420px;overflow:auto;background:#111;color:#e6e6e6;padding:16px;border-radius:6px;white-space:pre-wrap"></pre>
			<script>
			( function () {
				const caseSauvegarde = document.getElementById( 'hvb-sauvegarde' );
				const bouton = document.getElementById( 'hvb-lancer' );
				const journal = document.getElementById( 'hvb-journal' );
				caseSauvegarde.addEventListener( 'change', () => { bouton.disabled = ! caseSauvegarde.checked; } );
				const ecrire = ( texte ) => { journal.textContent += texte + '\n'; journal.scrollTop = journal.scrollHeight; };
				async function etape( nom, lot ) {
					for ( let essai = 1; essai <= 3; essai++ ) {
						const corps = new URLSearchParams( { action: 'hvb_installation', etape: nom, lot: lot || 0, _ajax_nonce: '<?php echo esc_js( wp_create_nonce( 'hvb_installation' ) ); ?>' } );
						try {
							const reponse = await fetch( ajaxurl, { method: 'POST', body: corps, credentials: 'same-origin' } );
							const texte = await reponse.text();
							if ( reponse.ok ) { return texte; }
							ecrire( `Erreur ${ reponse.status } (essai ${ essai }/3)` );
						} catch ( e ) {
							ecrire( `Erreur réseau (essai ${ essai }/3)` );
						}
					}
					throw new Error( 'Étape ' + nom + ' impossible' );
				}
				bouton.addEventListener( 'click', async () => {
					bouton.disabled = true; caseSauvegarde.disabled = true; journal.style.display = 'block';
					try {
						ecrire( '— Réglages' ); ecrire( await etape( 'reglages' ) );
						ecrire( '— Photos et documents' );
						for ( let lot = 0; ; lot++ ) {
							const texte = await etape( 'medias', lot );
							ecrire( texte );
							if ( texte.includes( 'FIN' ) ) { break; }
						}
						ecrire( '— Pages, articles et menus' ); ecrire( await etape( 'contenu' ) );
						ecrire( '— Classements (LNV et FFvolley)' ); ecrire( await etape( 'classement' ) );
						ecrire( '— Finalisation' ); ecrire( await etape( 'finalisation' ) );
						ecrire( '\nInstallation terminée. Ouvrez le site pour vérifier, puis supprimez cette extension (Extensions).' );
					} catch ( e ) {
						ecrire( '\n' + e.message + ' : relancez l\'installation (les étapes déjà faites ne sont pas refaites).' );
						bouton.disabled = false;
					}
				} );
			} )();
			</script>
		<?php endif; ?>
	</div>
	<?php
}

add_action( 'wp_ajax_hvb_installation', function () {
	check_ajax_referer( 'hvb_installation' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Accès refusé', 403 );
	}
	@set_time_limit( 300 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	require_once __DIR__ . '/donnees/import.php';
	$etape = sanitize_key( $_POST['etape'] ?? '' );
	ob_start();
	if ( 'reglages' === $etape ) {
		hvb_etape_reglages();
	} elseif ( 'medias' === $etape ) {
		hvb_etape_medias( (int) ( $_POST['lot'] ?? 0 ), 6 );
	} elseif ( 'contenu' === $etape ) {
		hvb_etape_contenu();
	} elseif ( 'classement' === $etape ) {
		hvb_log( hvb_lnv_mettre_a_jour() ? 'Classement LNV à jour.' : 'LNV injoignable : le classement se mettra à jour plus tard.' );
		hvb_log( 'Résultats FFvolley : ' . hvb_ffvb_mettre_a_jour() . ' équipe(s) à jour.' );
	} elseif ( 'finalisation' === $etape ) {
		hvb_installation_finaliser();
	}
	echo html_entity_decode( ob_get_clean(), ENT_QUOTES, 'UTF-8' );
	wp_die();
} );

/** Désactive les extensions de l'ancien site et régénère les adresses. */
function hvb_installation_finaliser() {
	if ( isset( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) ) {
		$GLOBALS['wp_fastest_cache']->deleteCache( true );
		hvb_log( 'Cache de WP Fastest Cache vidé.' );
	}
	do_action( 'wpfc_clear_all_cache', true );
	$a_desactiver = array();
	foreach ( (array) get_option( 'active_plugins', array() ) as $extension ) {
		if ( in_array( dirname( $extension ), HVB_ANCIENNES_EXTENSIONS, true ) ) {
			$a_desactiver[] = $extension;
		}
	}
	deactivate_plugins( $a_desactiver );
	hvb_log( $a_desactiver ? 'Extensions désactivées : ' . implode( ', ', array_map( 'dirname', $a_desactiver ) ) . '.' : 'Aucune ancienne extension active.' );
	flush_rewrite_rules();
	hvb_log( 'Adresses régénérées.' );
}
