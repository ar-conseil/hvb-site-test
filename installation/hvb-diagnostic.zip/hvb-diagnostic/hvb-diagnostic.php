<?php
/**
 * Plugin Name: HVB – Diagnostic
 * Description: Affiche l'erreur PHP d'une page du site aux administrateurs connectés (ajouter ?hvb_diag=1 à l'adresse). À supprimer après usage.
 * Version: 1.0.0
 */
defined( 'ABSPATH' ) || exit;

if ( isset( $_GET['hvb_diag'] ) ) {
	add_action( 'init', function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		@ini_set( 'display_errors', '1' );
		error_reporting( E_ALL );
		register_shutdown_function( function () {
			$e = error_get_last();
			if ( $e && in_array( $e['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true ) ) {
				echo "\n\nHVB_DIAG_ERREUR " . esc_html( $e['message'] . ' @ ' . $e['file'] . ':' . $e['line'] );
			}
			echo "\n\nHVB_DIAG_FIN PHP " . PHP_VERSION . ' mémoire ' . round( memory_get_peak_usage() / 1048576 ) . ' Mo / ' . ini_get( 'memory_limit' );
		} );
		add_filter( 'wp_die_handler', fn() => function ( $message ) {
			echo 'HVB_DIAG_WPDIE ' . esc_html( wp_strip_all_tags( is_string( $message ) ? $message : print_r( $message, true ) ) );
			exit;
		} );
		add_filter( 'template_include', function ( $modele ) {
			try {
				include $modele;
			} catch ( Throwable $t ) {
				echo "\n\nHVB_DIAG_EXCEPTION " . esc_html( get_class( $t ) . ': ' . $t->getMessage() . ' @ ' . $t->getFile() . ':' . $t->getLine() . "\n" . $t->getTraceAsString() );
			}
			exit;
		}, PHP_INT_MAX );
	}, 0 );
}
